/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import LandingPage from "./components/LandingPage";
import AuthPage from "./components/AuthPage";
import Navigation, { NavTab } from "./components/Navigation";

// Import modules
import Dashboard from "./components/Dashboard";
import Profile from "./components/Profile";
import SkillTracker from "./components/SkillTracker";
import ProjectPortfolio from "./components/ProjectPortfolio";
import ResearchSection from "./components/ResearchSection";
import ScholarshipFinder from "./components/ScholarshipFinder";
import UniversityFinder from "./components/UniversityFinder";
import DreamGoals from "./components/DreamGoals";
import RoadmapView from "./components/RoadmapView";
import ProductivityHub from "./components/ProductivityHub";
import DocumentGen from "./components/DocumentGen";
import AdminPanel from "./components/AdminPanel";
import Settings from "./components/Settings";
import AcademicStudio from "./components/AcademicStudio";

// Import types and data
import { UserProfile, UserRole, DreamGoal, Scholarship, University } from "./types";
import { initialScholarships } from "./data/scholarships";
import { initialUniversities } from "./data/universities";
import { Bell, X, Info } from "lucide-react";

export default function App() {
  const [view, setView] = useState<"landing" | "auth" | "app">("landing");
  const [activeTab, setActiveTab] = useState<NavTab>("dashboard");
  
  // Custom initial profiles for realistic instant feedback
  const [profile, setProfile] = useState<UserProfile>({
    id: "stu_101",
    name: "Aria Chen",
    role: UserRole.Student,
    academic: {
      university: "National Technological Institute",
      department: "Electronic & Systems Engineering",
      currentSemester: "Semester 5",
      expectedGraduationYear: 2027,
      cgpa: 3.84,
      gpaHistory: [
        { semester: "Semester 1", gpa: 3.75 },
        { semester: "Semester 2", gpa: 3.82 },
        { semester: "Semester 3", gpa: 3.90 },
        { semester: "Semester 4", gpa: 3.88 },
        { semester: "Semester 5", gpa: 3.84 }
      ]
    },
    languages: {
      ielts: 7.5,
      toefl: 110,
      gre: 322,
      gmat: 710
    },
    research: {
      interests: ["Quantized Edge hardware accelerators", "Mixed-Signal microprocessor design", "Bare-metal priority schedulers"],
      publications: [
        { id: "pub_1", title: "Intelligent Task priority distribution on Cortex M4 Nodes", conferenceOrJournal: "IEEE Embedded Systems Letters", year: 22 },
        { id: "pub_2", title: "Microstrip Parasitical Resistance Mitigation", conferenceOrJournal: "ACM Electronics Transactions", year: 25 }
      ],
      experience: "Current lab associate at the High Performance Microprocessor Design Group under Dr. Harold Gries. Contributing testing scripts for STM32 board layouts."
    },
    projects: [
      { id: "p1", title: "Dynamic Task Priority Scheduler", description: "Configured STM32 bare-metal registers and prioritized nested interrupt vector traps.", githubLink: "https://github.com/aria/stm32-scheduler", type: "academic" },
      { id: "p2", title: "KiCad Microcontroller Shield", description: "Designed a 4-layer trace layout routing power nodes with minimal parasitic capacitance.", githubLink: "https://github.com/aria/kicad-shield", type: "personal" }
    ],
    skills: [
      { name: "Embedded Firmware Development", level: "Expert", category: "hardware", progress: 95 },
      { name: "PCB Trace Design (Altium/KiCad)", level: "Advanced", category: "hardware", progress: 85 },
      { name: "Signal Analysis (LTSpice)", level: "Intermediate", category: "hardware", progress: 55 },
      { name: "PyTorch Deep Learning models", level: "Intermediate", category: "software", progress: 60 },
      { name: "Technical Statement Composition", level: "Advanced", category: "professional", progress: 75 }
    ],
    experiences: [
      { id: "exp1", title: "Microprocessor Intern", organization: "Intel Labs", duration: "June - August 2025", description: "Wrote compiler test benches and benchmarked cache-line performance thresholds.", type: "internship" }
    ],
    careerInterests: ["MS Abroad", "PhD Abroad", "Corporate Jobs"]
  });

  // Master databases loaded from static assets
  const [scholarships, setScholarships] = useState<Scholarship[]>(initialScholarships);
  const [universities, setUniversities] = useState<University[]>(initialUniversities);

  // Initial student targets
  const [goals, setGoals] = useState<DreamGoal[]>([
    {
      id: "goal_mit",
      title: "PhD in Electrical Engineering",
      targetInstitution: "Massachusetts Institute of Technology (MIT)",
      readinessScore: 82,
      probabilityScore: 78,
      missingRequirements: ["Lock cumulative CGPA above 3.86", "Secure three co-signed Faculty recommendations letters", "Complete Quantitative GRE minimum 168"],
      skillGaps: ["Advanced Verilog compiler mapping logic missing", "SPICE RF signal simulation experience lacking"],
      researchGaps: ["Unaddressed literature review logs regarding quantum clock synchronization"],
      estimatedTime: "12 Months Remaining",
      personalizedRoadmap: `---
### 🛠️ STRATEGIC PhD ADVISORS TASK CHART (MIT EECS TRANSITION)

#### Phase 1: Academic Metric Lock (Weeks 1 - 8)
*   Deploy custom testing models across advanced VLSI layouts.
*   Retake physical GRE assessments to push Quantitative benchmarks above 168 threshold bounds.

#### Phase 2: Structural Statement Synthesis (Weeks 9 - 16)
*   Structure Statement of Purpose drafts outlining low-power edge quantization.
*   Incentivize Dr. Harold Gries and associated lab mentors to co-sign letters of endorsement.`
    },
    {
      id: "goal_tesla",
      title: "Tesla Embedded Firmware Engineer",
      targetInstitution: "Tesla Motors Inc.",
      readinessScore: 0,
      probabilityScore: 0,
      missingRequirements: ["Identify missing microchip qualifications"],
      skillGaps: ["System testing limits audits"],
      researchGaps: [],
      estimatedTime: "",
      personalizedRoadmap: ""
    }
  ]);

  // Notifications systems
  const [notificationCount, setNotificationCount] = useState(2);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notificationsList, setNotificationsList] = useState([
    { id: 1, title: "SOP Document ready to finalize", text: "Your Fulbright foreign student fellowship statement was generated.", date: "Today" },
    { id: 2, title: "CGPA eligibility updated", text: "Your admissions eligibility to ETH Zurich is now 92% green.", date: "Yesterday" }
  ]);

  // Handle AI goal diagnosis updates
  const handleDiagnoseGoal = (goalId: string, parsedData: any) => {
    setGoals(goals.map(g => {
      if (g.id === goalId) {
        return {
          ...g,
          readinessScore: parsedData.readinessScore || 75,
          probabilityScore: parsedData.probabilityScore || 70,
          missingRequirements: parsedData.missingRequirements || ["Complete Quantitative GRE exam benchmarks"],
          skillGaps: parsedData.skillGaps || ["PCB layout parasitic capacitance calculations lacking"],
          researchGaps: parsedData.researchGaps || [],
          estimatedTime: parsedData.estimatedTime || "6 Months",
          personalizedRoadmap: parsedData.personalizedRoadmap || "Proceed with active software compiler task blocks."
        };
      }
      return g;
    }));

    // Trigger notification
    const alertId = Date.now();
    setNotificationsList([
      { id: alertId, title: `AI Audit finished for ${goals.find(g => g.id === goalId)?.title || "Target"}`, text: "Check your trajectory indices metrics.", date: "Just Now" },
      ...notificationsList
    ]);
    setNotificationCount(prev => prev + 1);
  };

  const handleAddGoal = (newGoal: DreamGoal) => {
    setGoals([...goals, newGoal]);
  };

  // Shared triggers: Clicking Generate SOP inside Scholarships Finder redirects to Document Studio
  const [targetSopSch, setTargetSopSch] = useState("");
  const triggerSopGenerationFlow = (docType: string, schName: string) => {
    setTargetSopSch(schName);
    setActiveTab("settings"); // Redirection logic to Config tabs where they can try compiling SOP
    // To ensure they land directly on documentation, let's map settings tabs or redirect to standard Tab:
    // In our NavTab definition, let's see which tab represents standard doc generation. We have settings.
    // Let's redirect to 'settings' and load visualizers.
  };

  // Layout View Switcher
  const renderTabContent = () => {
    switch (activeTab) {
      case "dashboard":
        return (
          <Dashboard 
            profile={profile} 
            goals={goals} 
            scholarships={scholarships} 
            universities={universities} 
            onChangeTab={(id) => {
              if (id === "scholarships" || id === "universities") {
                setActiveTab(id);
              }
            }}
          />
        );
      case "profile":
        return <Profile profile={profile} onSave={(p) => setProfile(p)} />;
      case "academic-studio":
        return (
          <AcademicStudio 
            profile={profile} 
            onUpdateCgpa={(newCgpa) => {
              setProfile(current => {
                if (current.academic.cgpa === newCgpa) return current;
                return {
                  ...current,
                  academic: {
                    ...current.academic,
                    cgpa: newCgpa
                  }
                };
              });
            }}
          />
        );
      case "skills":
        return <SkillTracker profile={profile} onUpdateProfile={(updatedProfile) => setProfile(updatedProfile)} />;
      case "projects":
        return <ProjectPortfolio profile={profile} onSaveProfile={(p) => setProfile(p)} />;
      case "research":
        return <ResearchSection profile={profile} />;
      case "scholarships":
        return (
          <ScholarshipFinder 
            profile={profile} 
            scholarships={scholarships} 
            onTriggerDocDraft={(type, name) => {
              setTargetSopSch(name);
              setActiveTab("settings"); // redirect
            }}
          />
        );
      case "universities":
        return <UniversityFinder profile={profile} universities={universities} />;
      case "dream-goals":
        return (
          <DreamGoals 
            profile={profile} 
            goals={goals} 
            onDiagnoseGoal={handleDiagnoseGoal} 
            onAddGoal={handleAddGoal} 
          />
        );
      case "roadmap":
        return <RoadmapView profile={profile} />;
      case "reports":
        return <ProductivityHub profile={profile} />;
      case "admin":
        return (
          <AdminPanel 
            scholarships={scholarships} 
            universities={universities} 
            onAddScholarship={(n) => setScholarships([n, ...scholarships])}
            onAddUniversity={(u) => setUniversities([u, ...universities])}
          />
        );
      case "settings":
        // For settings tab, we integrate doc generation AND standard configs beautifully
        return (
          <div className="space-y-12">
            <DocumentGen profile={profile} initialScholarshipName={targetSopSch} />
            <Settings profile={profile} onChangeRole={(r) => setProfile({ ...profile, role: r })} />
          </div>
        );
      default:
        return <div className="text-xs font-mono text-slate-500">Selected workspace panel under construction.</div>;
    }
  };

  return (
    <div className="min-h-screen bg-[#020408] text-slate-200 font-sans antialiased overflow-x-hidden selection:bg-cyan-500 selection:text-slate-950 relative">
      <div className="absolute right-0 top-0 w-96 h-96 bg-cyan-500/5 blur-[100px] rounded-full pointer-events-none z-0" />
      <div className="absolute left-1/4 bottom-10 w-96 h-96 bg-blue-500/5 blur-[120px] rounded-full pointer-events-none z-0" />
      
      {view === "landing" && (
        <LandingPage 
          onGetStarted={() => setView("auth")} 
          onLogin={() => setView("auth")} 
        />
      )}

      {view === "auth" && (
        <AuthPage 
          onAuthSuccess={(name, email, role) => {
            setProfile(prev => ({ ...prev, name, email, role }));
            setView("app");
            setActiveTab("dashboard");
          }} 
          onBackToLanding={() => setView("landing")}
        />
      )}

      {view === "app" && (
        <div className="flex flex-col md:flex-row min-h-screen">
          
          {/* Main Navigation Sidebar Layout */}
          <Navigation 
            currentTab={activeTab} 
            onChangeTab={setActiveTab} 
            userRole={profile.role} 
            userName={profile.name} 
            onLogout={() => {
              setView("landing");
              setProfile(prev => ({ ...prev, name: "Aria Chen" }));
            }}
            notificationCount={notificationCount}
            onOpenNotifications={() => setShowNotifications(true)}
          />

          {/* Core App Main Frame */}
          <main className="flex-1 p-4 md:p-8 overflow-y-auto max-w-[1920px]">
            <div className="max-w-6xl mx-auto space-y-8 min-h-[calc(100vh-8rem)] flex flex-col justify-between">
              <div className="space-y-8 flex-1">
                {renderTabContent()}
              </div>
              <footer className="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 font-mono">
                <div>
                  <span>© 2026 FutureOS Portal &bull; Scholar Workstation Environment</span>
                </div>
                <div>
                  <span>Developed by <span className="text-cyan-400 font-semibold">Munem Shahriar Onim</span></span>
                </div>
              </footer>
            </div>
          </main>

        </div>
      )}

      {/* Notifications Drawer Modal */}
      {showNotifications && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-sm">
          <div className="w-full max-w-md h-full bg-slate-950 border-l border-slate-900 p-6 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center border-b border-slate-950 pb-4 mb-4">
                <span className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                  <Bell className="w-4 h-4 text-indigo-400" />
                  <span>Incoming telemetry reports</span>
                </span>
                <button 
                  onClick={() => {
                    setShowNotifications(false);
                    setNotificationCount(0);
                  }}
                  className="text-slate-500 hover:text-white p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3">
                {notificationsList.map((notif) => (
                  <div key={notif.id} className="p-3.5 rounded-xl border border-slate-900 bg-slate-900/10 flex items-start space-x-3 text-xs leading-relaxed">
                    <Info className="w-4 h-4 text-indigo-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="block text-white font-semibold">{notif.title}</span>
                      <p className="text-slate-450 mt-1">{notif.text}</p>
                      <span className="text-[10px] text-slate-600 font-mono block mt-2">{notif.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                setNotificationsList([]);
                setNotificationCount(0);
              }}
              className="w-full bg-slate-900 hover:bg-slate-850 py-2.5 rounded-xl text-slate-450 hover:text-slate-200 font-mono text-[10px] uppercase font-bold text-center border border-slate-800 transition-colors"
            >
              Flush All Reports
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
