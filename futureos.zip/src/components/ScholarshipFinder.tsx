/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Scholarship, UserProfile } from "../types";
import { 
  GraduationCap, Globe2, Sparkles, Filter, 
  MapPin, Award, CheckCircle, AlertTriangle, ArrowUpRight 
} from "lucide-react";

interface ScholarshipFinderProps {
  profile: UserProfile;
  scholarships: Scholarship[];
  onTriggerDocDraft: (docType: string, scholarshipName: string) => void;
}

export default function ScholarshipFinder({ 
  profile, 
  scholarships,
  onTriggerDocDraft
}: ScholarshipFinderProps) {
  const [filterCountry, setFilterCountry] = useState("all");
  const [filterDegree, setFilterDegree] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  
  // Clean country extraction
  const countries = ["all", ...new Set(scholarships.map(s => s.country))];

  // Filters logic
  const filteredScholarships = scholarships.filter(s => {
    const matchCountry = filterCountry === "all" || s.country === filterCountry;
    
    let matchDegree = true;
    if (filterDegree !== "all") {
      matchDegree = s.degreeLevel.toLowerCase().includes(filterDegree.toLowerCase());
    }

    const matchesSearch = searchTerm.trim() === "" ||
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.funding.toLowerCase().includes(searchTerm.toLowerCase());

    return matchCountry && matchDegree && matchesSearch;
  });

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5 font-display">
            <GraduationCap className="w-6 h-6 text-cyan-400 text-glow-cyan" />
            <span>Structured Scholarships Catalog</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1.5 font-sans leading-relaxed">
            Global university funding program directories verified against your CGPA of **{profile.academic?.cgpa || "0.0"}** and IELTS of **{profile.languages?.ielts || "0.0"}**.
          </p>
        </div>

        {/* Global Match stats banner */}
        <div className="flex gap-4 p-3.5 rounded-2xl border border-white/5 bg-white/4 backdrop-blur-2xl font-mono text-[10px] text-slate-400">
          <div>
            <span className="block text-slate-500 font-bold">SCHOLARSHIPS DB</span>
            <span className="text-white font-black">{scholarships.length} Cataloged</span>
          </div>
          <div className="border-r border-white/5" />
          <div>
            <span className="block text-slate-500 font-bold">READY TO MATCH</span>
            <span className="text-cyan-400 font-black text-glow-cyan">
              {scholarships.filter(s => (profile.academic?.cgpa || 0) >= s.minCgpa).length} Programs
            </span>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="p-4 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl flex flex-col md:flex-row md:items-center gap-4 text-xs">
        
        <div className="flex items-center space-x-2 text-slate-400 font-mono font-bold tracking-wider">
          <Filter className="w-4 h-4 text-cyan-500" />
          <span>CATALOG FILTERS</span>
        </div>

        <div className="flex flex-wrap gap-4 flex-grow">
          {/* Country filter */}
          <div className="flex items-center space-x-2">
            <span className="text-slate-500 font-mono font-medium">DESTINATION:</span>
            <select
              value={filterCountry}
              onChange={(e) => setFilterCountry(e.target.value)}
              className="bg-[#020408] border border-white/5 rounded-xl px-3 py-1.5 text-slate-350 focus:outline-none focus:border-cyan-500/50 cursor-pointer text-xs font-mono font-semibold"
            >
              {countries.map(c => (
                <option key={c} value={c}>
                  {c === "all" ? "All Locations" : c}
                </option>
              ))}
            </select>
          </div>

          {/* Degree level filter */}
          <div className="flex items-center space-x-2">
            <span className="text-slate-500 font-mono font-medium">DEGREE:</span>
            <select
              value={filterDegree}
              onChange={(e) => setFilterDegree(e.target.value)}
              className="bg-[#020408] border border-white/5 rounded-xl px-3 py-1.5 text-slate-350 focus:outline-none focus:border-cyan-500/50 cursor-pointer text-xs font-mono font-semibold"
            >
              <option value="all">All Degrees</option>
              <option value="master">Master's Program</option>
              <option value="phd">PhD Program</option>
            </select>
          </div>

          {/* Keyword search input filter */}
          <div className="flex items-center space-x-2 md:ml-auto">
            <span className="text-slate-500 font-mono font-medium">SEARCH:</span>
            <input
              type="text"
              placeholder="Search by keywords..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-[#020408] border border-white/5 focus:border-cyan-500/50 rounded-xl px-3.5 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none font-mono animate-fadeIn"
            />
          </div>
        </div>

      </div>

      {/* Scholarships Grid List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredScholarships.map((s) => {
          const userGpa = profile.academic?.cgpa || 0.0;
          const userIelts = profile.languages?.ielts || 0.0;

          const qualifiesGpa = userGpa >= s.minCgpa;
          const qualifiesIelts = userIelts >= s.ieltsRequirement;
          const fullyEligible = qualifiesGpa && qualifiesIelts;

          return (
            <div key={s.id} className="p-6 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl flex flex-col justify-between space-y-4 hover:border-white/20 transition-all hover:bg-white/6 group">
              
              {/* Header block */}
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest">{s.country}</span>
                  <span className={`px-2.5 py-0.5 rounded-lg text-[9px] font-mono font-bold border ${
                    fullyEligible 
                      ? "text-cyan-400 bg-cyan-950/20 border-cyan-500/30" 
                      : "text-amber-500 bg-amber-950/15 border-amber-900/30"
                  }`}>
                    {fullyEligible ? "Fully Qualified" : "Missing requisites"}
                  </span>
                </div>

                <h3 className="text-white text-base font-extrabold mt-3 leading-snug group-hover:text-cyan-300 transition-colors font-display">{s.name}</h3>
                <span className="text-slate-450 text-[11px] block mt-1.5 font-sans font-medium">{s.degreeLevel} • {s.funding}</span>
              </div>

              {/* Requirements Specifications and user matches status */}
              <div className="grid grid-cols-2 gap-4 border-y border-white/5 py-4 font-mono text-[10px]">
                
                {/* GPA limits checks */}
                <div className="space-y-1">
                  <span className="block text-slate-500 font-bold">CGPA REQUIREMENT</span>
                  <div className="flex items-center space-x-1.5">
                    <span className="text-slate-200 font-black">{s.minCgpa} Min</span>
                    {qualifiesGpa ? (
                      <CheckCircle className="w-3.5 h-3.5 text-cyan-400 text-glow-cyan" />
                    ) : (
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                    )}
                  </div>
                  <span className="text-slate-500 block">Your record: {userGpa}</span>
                </div>

                {/* IELTS checking */}
                <div className="space-y-1">
                  <span className="block text-slate-500 font-bold">IELTS TARGETS</span>
                  <div className="flex items-center space-x-1.5">
                    <span className="text-slate-200 font-black">{s.ieltsRequirement} Min</span>
                    {qualifiesIelts ? (
                      <CheckCircle className="w-3.5 h-3.5 text-cyan-400 text-glow-cyan" />
                    ) : (
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                    )}
                  </div>
                  <span className="text-slate-500 block">Your score: {userIelts || "N/A"}</span>
                </div>

              </div>

              {/* Deadline & Official elements */}
              <div className="flex items-center justify-between text-xs">
                <div className="font-mono text-[10px] text-slate-450 leading-relaxed">
                  <span className="block text-[8px] font-bold text-slate-500">DEADLINE EXPIRY</span>
                  <span className="font-semibold text-slate-300">{s.deadline}</span>
                </div>

                {/* Action buttons list */}
                <div className="flex space-x-2">
                  <a
                    href={s.officialWebsite}
                    target="_blank"
                    rel="noopener noreferrer"
                    referrerPolicy="no-referrer"
                    className="p-2 hover:bg-white/8 rounded-xl text-slate-400 border border-white/5 text-[10px] transition-all font-mono font-bold flex items-center space-x-1 cursor-pointer"
                  >
                    <span>Website</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-slate-500" />
                  </a>
                  <button
                    onClick={() => onTriggerDocDraft("sop", s.name)}
                    className="cursor-pointer bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 border border-transparent p-2 px-3 rounded-xl text-white text-[10px] font-mono transition-all font-bold flex items-center space-x-1.5 shadow-[0_0_12px_rgba(6,182,212,0.3)]"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-white animate-pulse" />
                    <span>Generate SOP</span>
                  </button>
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
}
