/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { UserProfile, Project, Skill, Experience, UserRole, ExperienceType } from "../types";
import { 
  User, GraduationCap, Globe2, BookOpen, 
  Plus, Trash2, Save, Code, Zap, Award 
} from "lucide-react";

interface ProfileProps {
  profile: UserProfile;
  onSave: (updatedProfile: UserProfile) => void;
}

export default function Profile({ profile, onSave }: ProfileProps) {
  const [activeSubTab, setActiveSubTab] = useState<"general" | "research" | "skills" | "experiences">("general");
  
  // Local states to handle profile edits
  const [name, setName] = useState(profile.name);
  const [uni, setUni] = useState(profile.academic?.university || "");
  const [dept, setDept] = useState(profile.academic?.department || "");
  const [semester, setSemester] = useState(profile.academic?.currentSemester || "");
  const [gradYear, setGradYear] = useState(profile.academic?.expectedGraduationYear || 2027);
  const [cgpa, setCgpa] = useState(profile.academic?.cgpa || 3.5);

  // Languages testing targets
  const [ielts, setIelts] = useState(profile.languages?.ielts || 7.0);
  const [toefl, setToefl] = useState(profile.languages?.toefl || 100);
  const [gre, setGre] = useState(profile.languages?.gre || 315);
  const [gmat, setGmat] = useState(profile.languages?.gmat || 650);

  // Research text
  const [researchExp, setResearchExp] = useState(profile.research?.experience || "");
  
  // Lists of records
  const [projects, setProjects] = useState<Project[]>(profile.projects || []);
  const [skills, setSkills] = useState<Skill[]>(profile.skills || []);
  const [experiences, setExperiences] = useState<Experience[]>(profile.experiences || []);
  const [careerInterests, setCareerInterests] = useState<string[]>(profile.careerInterests || []);

  // Temporary inputs for appending to lists
  const [newProjTitle, setNewProjTitle] = useState("");
  const [newProjDesc, setNewProjDesc] = useState("");
  const [newProjLink, setNewProjLink] = useState("");
  const [newProjType, setNewProjType] = useState<"academic" | "personal">("academic");

  const [newSkillName, setNewSkillName] = useState("");
  const [newSkillLevel, setNewSkillLevel] = useState<"Beginner" | "Intermediate" | "Advanced" | "Expert">("Intermediate");
  const [newSkillCat, setNewSkillCat] = useState<"software" | "hardware" | "professional">("software");

  const [newExpTitle, setNewExpTitle] = useState("");
  const [newExpOrg, setNewExpOrg] = useState("");
  const [newExpDur, setNewExpDur] = useState("");
  const [newExpDesc, setNewExpDesc] = useState("");
  const [newExpType, setNewExpType] = useState<ExperienceType>("internship");

  // Handle career interest toggles
  const careerOptions = ["MS Abroad", "PhD Abroad", "Government Jobs", "Corporate Jobs", "MBA", "Entrepreneurship"];
  const handleToggleInterest = (interest: string) => {
    if (careerInterests.includes(interest)) {
      setCareerInterests(careerInterests.filter(i => i !== interest));
    } else {
      setCareerInterests([...careerInterests, interest]);
    }
  };

  // Add Item actions
  const addProject = () => {
    if (!newProjTitle) return;
    const item: Project = {
      id: "p_" + Date.now(),
      title: newProjTitle,
      description: newProjDesc,
      githubLink: newProjLink,
      type: newProjType
    };
    setProjects([...projects, item]);
    setNewProjTitle("");
    setNewProjDesc("");
    setNewProjLink("");
  };

  const addSkill = () => {
    if (!newSkillName) return;
    const progressMap = { "Beginner": 25, "Intermediate": 50, "Advanced": 75, "Expert": 95 };
    const item: Skill = {
      name: newSkillName,
      level: newSkillLevel,
      category: newSkillCat,
      progress: progressMap[newSkillLevel]
    };
    
    // Replace duplicate skills
    const filtered = skills.filter(s => s.name.toLowerCase() !== newSkillName.toLowerCase());
    setSkills([...filtered, item]);
    setNewSkillName("");
  };

  const addExperience = () => {
    if (!newExpTitle) return;
    const item: Experience = {
      id: "e_" + Date.now(),
      title: newExpTitle,
      organization: newExpOrg,
      duration: newExpDur,
      description: newExpDesc,
      type: newExpType
    };
    setExperiences([...experiences, item]);
    setNewExpTitle("");
    setNewExpOrg("");
    setNewExpDur("");
    setNewExpDesc("");
  };

  const handleGlobalSubmit = () => {
    const updated: UserProfile = {
      ...profile,
      name,
      academic: {
        ...profile.academic,
        university: uni,
        department: dept,
        currentSemester: semester,
        expectedGraduationYear: Number(gradYear),
        cgpa: Number(cgpa)
      },
      languages: {
        ielts: Number(ielts),
        toefl: Number(toefl),
        gre: Number(gre),
        gmat: Number(gmat)
      },
      research: {
        ...profile.research,
        experience: researchExp
      },
      projects,
      skills,
      experiences,
      careerInterests
    };
    onSave(updated);
  };

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex items-center justify-between border-b border-slate-900 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <User className="w-5 h-5 text-indigo-400" />
            <span>Operational Credentials & Profile</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Configure your university metrics, skills list, and target career interests.</p>
        </div>
        <button 
          onClick={handleGlobalSubmit}
          className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-4 py-2 rounded-xl shadow-lg shadow-indigo-650/15 flex items-center space-x-2 transition-colors"
        >
          <Save className="w-4 h-4" />
          <span>Save Profile Changes</span>
        </button>
      </div>

      {/* Pane Subtab Buttons */}
      <div className="flex border-b border-slate-900/60 p-1 bg-slate-950/40 rounded-xl max-w-lg">
        {[
          { id: "general", label: "Academic Info", icon: GraduationCap },
          { id: "research", label: "Projects & Papers", icon: BookOpen },
          { id: "skills", label: "Skill Accelerator", icon: Code },
          { id: "experiences", label: "Campus Experience", icon: Zap }
        ].map(sub => (
          <button
            key={sub.id}
            onClick={() => setActiveSubTab(sub.id as any)}
            className={`flex-1 flex items-center justify-center space-x-2 py-2 rounded-lg text-[10px] font-mono uppercase tracking-wider font-semibold transition-all ${
              activeSubTab === sub.id 
                ? "bg-slate-900 text-indigo-400 border border-slate-800" 
                : "text-slate-500 hover:text-slate-350"
            }`}
          >
            <span>{sub.label}</span>
          </button>
        ))}
      </div>

      {/* TABS GRID VIEW */}
      <div className="grid grid-cols-1 gap-6">

        {/* 1. GENERAL ACADEMICS & LANGUAGES */}
        {activeSubTab === "general" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Academic Forms panel */}
            <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 space-y-4">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-2 flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-indigo-400" />
                <span>University Context</span>
              </h3>
              
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">STUDENT PROFILE NAME</label>
                <input 
                  type="text" 
                  value={name} 
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">INSTITUTION / UNIVERSITY</label>
                <input 
                  type="text" 
                  value={uni} 
                  onChange={(e) => setUni(e.target.value)}
                  placeholder="e.g. Stanford University"
                  className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">DEPARTMENT</label>
                  <input 
                    type="text" 
                    value={dept} 
                    onChange={(e) => setDept(e.target.value)}
                    placeholder="e.g. Electrical Engineering"
                    className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">CURRENT SEMESTER</label>
                  <input 
                    type="text" 
                    value={semester} 
                    onChange={(e) => setSemester(e.target.value)}
                    placeholder="e.g. Semester 5"
                    className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">EXPECTED GRAD YEAR</label>
                  <input 
                    type="number" 
                    value={gradYear} 
                    onChange={(e) => setGradYear(Number(e.target.value))}
                    className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">CURRENT CGPA (4.0 SCALE)</label>
                  <input 
                    type="number" 
                    step="0.01" 
                    max="4.0"
                    placeholder="e.g. 3.82"
                    value={cgpa} 
                    onChange={(e) => setCgpa(Number(e.target.value))}
                    className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Language testing forms */}
            <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 space-y-4">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-2 flex items-center gap-2">
                <Globe2 className="w-4 h-4 text-emerald-400" />
                <span>Language & Standardized Tests</span>
              </h3>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">IELTS SCORE</label>
                  <input 
                    type="number" 
                    step="0.5" 
                    value={ielts} 
                    onChange={(e) => setIelts(Number(e.target.value))}
                    placeholder="e.g. 7.5"
                    className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">TOEFL SCORE</label>
                  <input 
                    type="number" 
                    value={toefl} 
                    onChange={(e) => setToefl(Number(e.target.value))}
                    placeholder="e.g. 105"
                    className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">GRE EXAM SCORE</label>
                  <input 
                    type="number" 
                    value={gre} 
                    onChange={(e) => setGre(Number(e.target.value))}
                    placeholder="e.g. 320"
                    className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">GMAT SCORE</label>
                  <input 
                    type="number" 
                    value={gmat} 
                    onChange={(e) => setGmat(Number(e.target.value))}
                    placeholder="e.g. 680"
                    className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Career Interests choice */}
              <div className="pt-4 border-t border-slate-900">
                <span className="block text-[10px] font-mono text-slate-400 uppercase mb-3">Target Career Interests (Active Tags)</span>
                <div className="flex flex-wrap gap-2">
                  {careerOptions.map(opt => {
                    const active = careerInterests.includes(opt);
                    return (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => handleToggleInterest(opt)}
                        className={`px-3 py-1.5 rounded-lg text-xs transition-all ${
                          active 
                            ? "bg-indigo-600/25 text-indigo-300 border border-indigo-500/40 font-semibold" 
                            : "bg-slate-950/70 text-slate-500 border border-slate-900"
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>

            </div>

          </div>
        )}

        {/* 2. PROJECTS & RESEARCH PAPERS */}
        {activeSubTab === "research" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* List active projects and add new projects panel */}
            <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 space-y-4">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-2">
                Personal & Academic Projects
              </h3>

              {projects.length === 0 ? (
                <p className="text-xs text-slate-400">No projects added yet.</p>
              ) : (
                <div className="space-y-3 max-h-[16rem] overflow-y-auto pr-1">
                  {projects.map((p) => (
                    <div key={p.id} className="p-3 rounded-xl border border-slate-900 bg-slate-950/40 relative flex justify-between items-start">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-white text-xs font-bold">{p.title}</span>
                          <span className="text-[8px] px-1.5 py-0.5 bg-slate-900 text-slate-500 border border-slate-800 rounded uppercase font-mono">{p.type}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1">{p.description}</p>
                        {p.githubLink && (
                          <span className="text-[9px] text-indigo-400 font-mono block mt-1.5 truncate">{p.githubLink}</span>
                        )}
                      </div>
                      <button 
                        onClick={() => setProjects(projects.filter(item => item.id !== p.id))}
                        className="text-slate-500 hover:text-red-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Add Project Form */}
              <div className="p-3.5 rounded-xl border border-slate-900 bg-slate-950/40 space-y-3.5">
                <span className="block text-[10px] font-mono text-slate-400 uppercase tracking-widest">Append new academic project</span>
                <input 
                  type="text" 
                  placeholder="Project Title (e.g. FreeRTOS Smart Grid Controller)"
                  value={newProjTitle}
                  onChange={(e) => setNewProjTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none"
                />
                <textarea 
                  placeholder="Description of methodology and controller code size..."
                  value={newProjDesc}
                  onChange={(e) => setNewProjDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-lg px-3 py-1.5 text-xs text-white h-16 resize-none focus:outline-none"
                />
                <input 
                  type="text" 
                  placeholder="GitHub Repository URL (Optional)"
                  value={newProjLink}
                  onChange={(e) => setNewProjLink(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none"
                />
                <div className="flex justify-between items-center gap-3">
                  <div className="flex bg-slate-950 border border-slate-855 rounded-lg p-0.5 text-[9px] font-mono">
                    <button 
                      type="button" 
                      onClick={() => setNewProjType("academic")} 
                      className={`px-2.5 py-1 rounded ${newProjType === "academic" ? "bg-indigo-600/20 text-indigo-300" : "text-slate-500"}`}
                    >
                      Academic
                    </button>
                    <button 
                      type="button" 
                      onClick={() => setNewProjType("personal")} 
                      className={`px-2.5 py-1 rounded ${newProjType === "personal" ? "bg-indigo-600/20 text-indigo-300" : "text-slate-500"}`}
                    >
                      Personal
                    </button>
                  </div>
                  <button 
                    type="button" 
                    onClick={addProject}
                    className="p-1.5 bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-900 px-3 rounded-lg text-[10px] font-mono uppercase font-bold flex items-center space-x-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Project</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Research publications summary and experience */}
            <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 space-y-4">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-2">
                Research Summary & Lab Experience
              </h3>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">LAB EXPERIENCE DESCRIPTION</label>
                <textarea 
                  value={researchExp} 
                  onChange={(e) => setResearchExp(e.target.value)}
                  placeholder="Describe your research experience, lab roles, and faculty advisors..."
                  className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs text-white h-[20rem] focus:outline-none"
                />
              </div>
            </div>

          </div>
        )}

        {/* 3. SKILL ACCELERATOR */}
        {activeSubTab === "skills" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* List current skills */}
            <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 space-y-4">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-2 flex items-center justify-between">
                <span>My Active Skills Catalog</span>
                <span className="text-[9px] text-slate-500 font-mono">{skills.length} Loaded</span>
              </h3>

              {skills.length === 0 ? (
                <p className="text-xs text-slate-400">List remains clear. Create target skills below.</p>
              ) : (
                <div className="grid grid-cols-1 gap-2 max-h-[22rem] overflow-y-auto pr-1">
                  {skills.map((s, idx) => (
                    <div key={idx} className="p-2.5 rounded-xl border border-slate-900 bg-slate-950/40 flex items-center justify-between">
                      <div className="flex-grow">
                        <div className="flex items-center space-x-2">
                          <span className="text-white text-xs font-bold">{s.name}</span>
                          <span className="text-[8px] bg-slate-900 text-indigo-400 border border-slate-800 font-mono px-1 rounded uppercase">{s.category}</span>
                        </div>
                        <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden my-1 pl-0.5">
                          <div className="bg-indigo-500 h-1" style={{ width: `${s.progress}%` }} />
                        </div>
                        <span className="text-[9px] text-slate-400 font-mono uppercase tracking-wider">{s.level} ({s.progress}%)</span>
                      </div>
                      <button 
                        onClick={() => setSkills(skills.filter(i => i.name !== s.name))}
                        className="text-slate-500 hover:text-red-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Add skill interface */}
            <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 space-y-4 flex flex-col justify-between">
              <div className="space-y-4">
                <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-2">
                  Accelerate New Competency
                </h3>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">SKILL PROTOCOL NAME</label>
                  <input 
                    type="text" 
                    placeholder="e.g. PCB Design, KiCad, PyTorch, Simulink"
                    value={newSkillName}
                    onChange={(e) => setNewSkillName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-850 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400">COMPETENCY CATEGORY</label>
                    <select 
                      value={newSkillCat}
                      onChange={(e) => setNewSkillCat(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none"
                    >
                      <option value="software">Software (AI/Models)</option>
                      <option value="hardware">Hardware (ARM/PCB)</option>
                      <option value="professional">Professional (SOP/Leadership)</option>
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400">PROFICIENCY DENSITY</label>
                    <select 
                      value={newSkillLevel}
                      onChange={(e) => setNewSkillLevel(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none"
                    >
                      <option value="Beginner">Beginner (Class Level)</option>
                      <option value="Intermediate">Intermediate (Project Use)</option>
                      <option value="Advanced">Advanced (Autonomous)</option>
                      <option value="Expert">Expert (Lab Leader)</option>
                    </select>
                  </div>
                </div>
              </div>

              <button 
                type="button" 
                onClick={addSkill}
                className="w-full mt-6 bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-900 py-2.5 rounded-xl text-xs font-mono uppercase font-bold flex items-center justify-center space-x-1"
              >
                <Plus className="w-4 h-4" />
                <span>Inject Competency Records</span>
              </button>
            </div>

          </div>
        )}

        {/* 4. EXPERIENCES (INTERNSHIP, CAMPUS ROLES) */}
        {activeSubTab === "experiences" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* List active experiences panel */}
            <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 space-y-4">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-2">
                Campus Activities & Job Records
              </h3>

              {experiences.length === 0 ? (
                <p className="text-xs text-slate-400">No active work records currently logged.</p>
              ) : (
                <div className="space-y-3 max-h-[22rem] overflow-y-auto pr-1">
                  {experiences.map((exp) => (
                    <div key={exp.id} className="p-3 rounded-xl border border-slate-900 bg-slate-950/40 flex justify-between items-start">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-white text-xs font-bold">{exp.title}</span>
                          <span className="text-[8px] bg-slate-900 text-indigo-400 border border-slate-800 font-mono px-1 rounded uppercase">{exp.type}</span>
                        </div>
                        <span className="block text-[10px] text-slate-500 font-mono mt-1 font-semibold">{exp.organization} • {exp.duration}</span>
                        <p className="text-[11px] text-slate-400 mt-1">{exp.description}</p>
                      </div>
                      <button 
                        onClick={() => setExperiences(experiences.filter(i => i.id !== exp.id))}
                        className="text-slate-500 hover:text-red-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Add active experience form panel */}
            <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 space-y-4">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-2">
                Log New Experience Block
              </h3>

              <div className="space-y-3.5">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400">ROLE TITLE</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Embedded HW Intern"
                      value={newExpTitle}
                      onChange={(e) => setNewExpTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400">ORGANIZATION</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Tesla Labs"
                      value={newExpOrg}
                      onChange={(e) => setNewExpOrg(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400">DURATION / TIMESCALE</label>
                    <input 
                      type="text" 
                      placeholder="e.g. June - Aug 2025"
                      value={newExpDur}
                      onChange={(e) => setNewExpDur(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400">EXPERIENCE CATEGORY</label>
                    <select 
                      value={newExpType}
                      onChange={(e) => setNewExpType(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1.5 text-xs text-slate-350 focus:outline-none"
                    >
                      <option value="internship">Internship</option>
                      <option value="volunteering">Volunteering</option>
                      <option value="leadership">Leadership Role</option>
                      <option value="club">Student Club Org</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">BULLET POINTS DESCRIPTION</label>
                  <textarea 
                    placeholder="Briefly state key targets achieved, hardware debugging configured..."
                    value={newExpDesc}
                    onChange={(e) => setNewExpDesc(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg px-3 py-1.5 text-xs text-white h-20 resize-none focus:outline-none"
                  />
                </div>

                <button 
                  type="button" 
                  onClick={addExperience}
                  className="w-full bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-900 py-2 rounded-xl text-[10px] font-mono uppercase font-bold flex items-center justify-center space-x-1"
                >
                  <Plus className="w-4 h-4" />
                  <span>Log Activity Block</span>
                </button>
              </div>
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
