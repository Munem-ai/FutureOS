/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { ShieldCheck, Mail, Lock, User, Sparkles, KeyRound, AlertCircle } from "lucide-react";
import { UserRole } from "../types";

interface AuthPageProps {
  onAuthSuccess: (name: string, email: string, role: UserRole) => void;
  onBackToLanding: () => void;
}

export default function AuthPage({ onAuthSuccess, onBackToLanding }: AuthPageProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [isForgot, setIsForgot] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState<UserRole>(UserRole.Student);
  const [error, setError] = useState("");
  const [infoMessage, setInfoMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setInfoMessage("");

    if (!email) {
      setError("Please specify a valid email address.");
      return;
    }

    if (isForgot) {
      setInfoMessage(`We have dispatched a password recovery instruction to ${email}. Please check your inbox within 10 minutes.`);
      return;
    }

    if (!password || password.length < 5) {
      setError("Password metrics must meet at least 5 character benchmarks.");
      return;
    }

    if (!isLogin && !name) {
      setError("Please specify your legal student/faculty name.");
      return;
    }

    // Success Authentication Trigger
    const resolvedName = isLogin ? (email.split("@")[0].toUpperCase() || "Alex") : name;
    onAuthSuccess(resolvedName, email, role);
  };

  const handleGoogleMock = () => {
    onAuthSuccess("Onim Shahriar", "munemshahriaronim@gmail.com", UserRole.Student);
  };

  const handleQuickLogin = (selectedRole: UserRole) => {
    const roleEmails = {
      [UserRole.Student]: "student@futureos.net",
      [UserRole.Mentor]: "advisor.chen@stanford.edu",
      [UserRole.Admin]: "admin.os@security.futureos.net",
    };
    onAuthSuccess(
      selectedRole === UserRole.Student ? "Alex Chen" : selectedRole === UserRole.Mentor ? "Dr. Lillian Chen" : "System Root",
      roleEmails[selectedRole],
      selectedRole
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center px-6 py-12 relative selection:bg-indigo-500/30">
      
      {/* Background Blurs */}
      <div className="absolute top-[20%] left-[20%] w-[350px] h-[350px] bg-indigo-900/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[20%] right-[20%] w-[350px] h-[350px] bg-cyan-950/15 rounded-full blur-[100px] pointer-events-none" />

      <div className="w-full max-w-md z-10">
        
        {/* Brand Banner */}
        <div className="text-center mb-8">
          <div onClick={onBackToLanding} className="inline-flex items-center space-x-2.5 cursor-pointer hover:opacity-90">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center shadow-lg">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <span className="text-2xl font-bold tracking-tight text-white font-sans">FutureOS</span>
          </div>
          <p className="text-xs text-slate-500 font-mono mt-2 uppercase tracking-widest">Secure Credentials Entry</p>
        </div>

        {/* Auth Panel Card */}
        <div className="rounded-2xl border border-slate-900 bg-slate-900/40 backdrop-blur-md p-6 md:p-8 shadow-2xl">
          
          {isForgot ? (
            <div>
              <h2 className="text-xl font-bold text-white mb-2">Reset Password</h2>
              <p className="text-slate-400 text-xs mb-6">Specify your institutional subscription email to get reset links.</p>
            </div>
          ) : (
            <div>
              <h2 className="text-xl font-bold text-white mb-2">
                {isLogin ? "Authenticate Account" : "Instantiate Identity"}
              </h2>
              <p className="text-slate-400 text-xs mb-6">
                {isLogin ? "Provide your encrypted password token to log in." : "Build your student portfolio profile."}
              </p>
            </div>
          )}

          {error && (
            <div className="mb-4 p-3 bg-red-950/40 border border-red-900/50 rounded-xl flex items-start space-x-2.5 text-red-200 text-xs">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {infoMessage && (
            <div className="mb-4 p-3 bg-indigo-950/40 border border-indigo-900/50 rounded-xl flex items-start space-x-2.5 text-indigo-200 text-xs">
              <Sparkles className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
              <span>{infoMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {!isLogin && !isForgot && (
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-400 font-mono">FULL NAME</label>
                <div className="relative">
                  <User className="absolute left-3 w-4 h-4 top-3 text-slate-500" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Alex Chen"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none transition-colors"
                  />
                </div>
              </div>
            )}

            {!isForgot && (
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-400 font-mono">ASSIGNED SYSTEM ROLE</label>
                <div className="grid grid-cols-3 gap-2 p-1 bg-slate-950 rounded-xl border border-slate-850">
                  {Object.values(UserRole).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRole(r)}
                      className={`py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                        role === r
                          ? "bg-indigo-600/20 text-indigo-300 border border-indigo-500/30"
                          : "text-slate-500 hover:text-slate-350 border border-transparent"
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400 font-mono">SUPPORT EMAIL</label>
              <div className="relative">
                <Mail className="absolute left-3 w-4 h-4 top-3 text-slate-500" />
                <input
                  type="email"
                  required
                  placeholder="name@university.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none transition-colors"
                />
              </div>
            </div>

            {!isForgot && (
              <div className="space-y-1.5">
                <div className="flex justify-between">
                  <label className="text-xs font-medium text-slate-400 font-mono">ACCESS KEY</label>
                  {isLogin && (
                    <button
                      type="button"
                      onClick={() => setIsForgot(true)}
                      className="text-[11px] font-medium text-indigo-400 hover:text-indigo-350 transition-colors"
                    >
                      Reset Key?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 w-4 h-4 top-3 text-slate-500" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none transition-colors"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 py-3 rounded-xl font-semibold text-white transition-all text-sm shadow-md mt-6"
            >
              {isForgot ? "Trigger Recovery Code" : isLogin ? "Decrypt & Sign In" : "Initialize Account"}
            </button>
          </form>

          {/* Google OAuth simulation option */}
          {!isForgot && (
            <div className="mt-6">
              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-slate-800"></div>
                <span className="flex-shrink mx-4 text-[10px] text-slate-500 font-mono uppercase">Secure SSO</span>
                <div className="flex-grow border-t border-slate-800"></div>
              </div>

              <button
                type="button"
                onClick={handleGoogleMock}
                className="w-full mt-3 bg-slate-950 hover:bg-slate-900 border border-slate-850 py-2.5 rounded-xl text-xs font-medium text-slate-300 hover:text-white transition-all flex items-center justify-center space-x-2.5"
              >
                <div className="w-4 h-4 bg-white rounded-full flex items-center justify-center text-[10px] text-slate-950 font-bold font-mono">G</div>
                <span>Authenticate with Google Account</span>
              </button>
            </div>
          )}

          {/* Toggle Login or Sign up options */}
          <div className="mt-6 text-center text-xs">
            {isForgot ? (
              <button
                onClick={() => setIsForgot(false)}
                className="text-slate-400 hover:text-white transition-colors"
              >
                Back to Authentication
              </button>
            ) : (
              <p className="text-slate-400">
                {isLogin ? "No active subscription? " : "Already initialized? "}
                <button
                  type="button"
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-indigo-400 hover:text-indigo-350 font-semibold underline underline-offset-2"
                >
                  {isLogin ? "Create Student OS Identity" : "Log In Key"}
                </button>
              </p>
            )}
          </div>

        </div>

        {/* Quick Testing Accounts Sandbox */}
        <div className="mt-6 p-4 rounded-xl border border-dashed border-slate-800 bg-slate-950/45 text-center">
          <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-2.5">
            Architect & Tester Fast Sandbox access
          </p>
          <div className="flex flex-wrap gap-2 justify-center">
            <button
              onClick={() => handleQuickLogin(UserRole.Student)}
              className="px-2.5 py-1 rounded bg-indigo-950/35 border border-indigo-900/50 hover:border-indigo-400 text-[10px] font-mono text-indigo-300 font-medium transition-colors"
            >
              [ Student Mock login ]
            </button>
            <button
              onClick={() => handleQuickLogin(UserRole.Mentor)}
              className="px-2.5 py-1 rounded bg-cyan-950/35 border border-cyan-900/50 hover:border-cyan-400 text-[10px] font-mono text-cyan-300 font-medium transition-colors"
            >
              [ Mentor Mock login ]
            </button>
            <button
              onClick={() => handleQuickLogin(UserRole.Admin)}
              className="px-2.5 py-1 rounded bg-rose-950/35 border border-rose-900/50 hover:border-rose-400 text-[10px] font-mono text-rose-300 font-medium transition-colors"
            >
              [ Admin Mock login ]
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
