/**
 * @license
 * SPDX-License-Identifier: Apache-3.5
 */

import React, { useState } from "react";
import { UserProfile, RoadmapMilestone } from "../types";
import { 
  Compass, Plus, Trash2, CheckSquare, 
  Square, Calendar, ChevronRight, AlertCircle, Sparkles 
} from "lucide-react";

interface RoadmapViewProps {
  profile: UserProfile;
}

export default function RoadmapView({ profile }: RoadmapViewProps) {
  const [filterLevel, setFilterLevel] = useState<"daily" | "weekly" | "semester" | "graduation">("daily");
  
  // Local checklists database
  const [items, setItems] = useState<RoadmapMilestone[]>([
    { id: "rm_1", level: "daily", title: "Review writing templates for IELTS Task 2 academic briefs", completed: false, associatedGoal: "Scholarships" },
    { id: "rm_2", level: "daily", title: "Profile STM32 low-power wake vectors clocks cycles", completed: true, associatedGoal: "Corporate Jobs" },
    { id: "rm_3", level: "weekly", title: "Complete literature bibliography summaries from IEEE transactions drafts", completed: false, associatedGoal: "MIT PhD" },
    { id: "rm_4", level: "weekly", title: "Validate high frequency microstrip trace parasitic impedance simulations", completed: false, associatedGoal: "Tesla Engineer" },
    { id: "rm_5", level: "semester", title: "Lock minimum cumulative CGPA above 3.82 before final semester assessments", completed: false, associatedGoal: "GPA Index" },
    { id: "rm_6", level: "graduation", title: "Submit three co-authored papers to ACM/IEEE conferences", completed: false, associatedGoal: "PhD Abroad" }
  ]);

  // Form input to append a milestone
  const [newTitle, setNewTitle] = useState("");
  const [newGoal, setNewGoal] = useState("");

  const handleToggleComplete = (id: string) => {
    setItems(items.map(item => {
      if (item.id === id) {
        return { ...item, completed: !item.completed };
      }
      return item;
    }));
  };

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;

    const newItem: RoadmapMilestone = {
      id: "rm_" + Date.now(),
      level: filterLevel,
      title: newTitle,
      completed: false,
      associatedGoal: newGoal || "General Guidance"
    };

    setItems([...items, newItem]);
    setNewTitle("");
    setNewGoal("");
  };

  const filteredItems = items.filter(item => item.level === filterLevel);

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-900 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <Compass className="w-5 h-5 text-indigo-400 animate-spin-slow" />
            <span>Structured Roadmaps & Action Milestones</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Audit daily checklists mapped directly onto your academic milestones and target goals.</p>
        </div>

        {/* Global check levels counts */}
        <div className="flex bg-slate-950 p-1 border border-slate-900 rounded-xl">
          {[
            { id: "daily", label: "Daily" },
            { id: "weekly", label: "Weekly" },
            { id: "semester", label: "Semester" },
            { id: "graduation", label: "Grad Plan" }
          ].map(lvl => (
            <button
              key={lvl.id}
              onClick={() => setFilterLevel(lvl.id as any)}
              className={`px-3.5 py-1.5 rounded-lg text-[10px] font-mono uppercase tracking-wider font-semibold transition-all ${
                filterLevel === lvl.id 
                  ? "bg-slate-900 text-indigo-400 border border-slate-800" 
                  : "text-slate-500 hover:text-slate-350"
              }`}
            >
              {lvl.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid splits layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Left Column: Log a new checklist item */}
        <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 h-fit space-y-4">
          <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-1.5">
            Log New Milestone Task
          </h3>

          <form onSubmit={handleAddItem} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-400">MILESTONE DESCRIPTION</label>
              <textarea
                required
                placeholder="Declare concrete, measurable academic targets (e.g., complete 5 code review sheets)..."
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 h-24 resize-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-400">ASSOCIATED GOAL TETHER</label>
              <input 
                type="text"
                placeholder="e.g. Stanford MS"
                value={newGoal}
                onChange={(e) => setNewGoal(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-650 hover:bg-indigo-600 border border-indigo-900/60 py-2.5 rounded-xl text-white text-xs font-semibold font-mono uppercase tracking-wider flex justify-center items-center space-x-1.5 shadow"
            >
              <Plus className="w-4 h-4 text-indigo-300" />
              <span>Append task block</span>
            </button>
          </form>
        </div>

        {/* Right Columns: Checklist list output */}
        <div className="lg:col-span-2 space-y-4">
          
          <div className="p-4 rounded-xl bg-slate-900/20 border border-slate-900">
            <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 uppercase tracking-wider border-b border-slate-900 pb-2 mb-3">
              <span>Classified task checklist ({filterLevel})</span>
              <span className="text-indigo-400">{filteredItems.filter(i => i.completed).length} / {filteredItems.length} COMPLETED</span>
            </div>

            {filteredItems.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-500 font-mono">
                No goals or roadmap milestones mapped to this timescale profile.
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredItems.map(item => (
                  <div 
                    key={item.id} 
                    className="p-3.5 rounded-xl border border-slate-900 bg-slate-950/40 hover:bg-slate-900/10 flex items-center justify-between transition-colors cursor-pointer"
                    onClick={() => handleToggleComplete(item.id)}
                  >
                    <div className="flex items-start space-x-3.5 flex-grow pr-4">
                      <button 
                        type="button" 
                        className="text-indigo-400 mt-0.5 flex-shrink-0"
                      >
                        {item.completed ? (
                          <CheckSquare className="w-4.5 h-4.5 text-indigo-400" />
                        ) : (
                          <Square className="w-4.5 h-4.5 text-slate-700 hover:text-slate-500" />
                        )}
                      </button>

                      <div>
                        <span className={`text-xs text-slate-200 transition-all font-sans leading-relaxed ${item.completed ? "line-through text-slate-450 decoration-indigo-500/40" : ""}`}>
                          {item.title}
                        </span>
                        
                        <div className="flex items-center space-x-2 mt-2 font-mono text-[9px] text-slate-500">
                          <span className="px-1.5 py-0.5 bg-slate-900 rounded font-semibold uppercase tracking-wider">{item.associatedGoal}</span>
                          <span>•</span>
                          <span>Scale: {item.level}</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setItems(items.filter(i => i.id !== item.id));
                      }}
                      className="text-slate-600 hover:text-red-400 p-1 flex-shrink-0"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick AI tips banner */}
          <div className="p-4 rounded-xl border border-indigo-950 bg-indigo-950/5 flex items-start space-x-3">
            <Sparkles className="w-5 h-5 text-indigo-400 mt-0.5 animate-pulse flex-shrink-0" />
            <div>
              <span className="block text-white text-xs font-bold font-mono">ADVISOR PRODUCTIVITY SPARK</span>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                Aim to maintain a **75% completed check rate** weekly. Dynamic scheduling limits cognitive friction, smoothing your transition into competitive academic research labs.
              </p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
