/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { University, UserProfile } from "../types";
import { 
  Compass, MapPin, Award, CheckCircle, Search, 
  Sparkles, Loader2, PlayCircle, BookOpen 
} from "lucide-react";

interface UniversityFinderProps {
  profile: UserProfile;
  universities: University[];
}

export default function UniversityFinder({ profile, universities }: UniversityFinderProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUniId, setSelectedUniId] = useState<string>("");
  const [loadingAi, setLoadingAi] = useState(false);
  const [aiResult, setAiResult] = useState("");
  const [errorHeader, setErrorHeader] = useState("");

  const activeUni = universities.find(u => u.id === selectedUniId);

  // Search filter logic
  const filteredUnis = universities.filter(u => {
    const term = searchTerm.toLowerCase();
    return (
      u.name.toLowerCase().includes(term) ||
      u.country.toLowerCase().includes(term) ||
      u.researchAreas.some(area => area.toLowerCase().includes(term))
    );
  });

  const handleRequestAiLabs = async (uniName: string) => {
    setSelectedUniId(universities.find(u => u.name === uniName)?.id || "");
    setLoadingAi(true);
    setAiResult("");
    setErrorHeader("");

    try {
      const response = await fetch("/api/ai/research-generator", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requestType: "topic_idea",
          interests: `University laboratory recommendations at ${uniName}. Student background: GPA ${profile.academic?.cgpa || "N/A"}, Skills: ${profile.skills?.map(s => s.name).join(", ")}, Publications Count: ${profile.research?.publications?.length || 0}.`
        })
      });

      if (!response.ok) {
        throw new Error("Failed to contact the research advisor services.");
      }

      const data = await response.json();
      setAiResult(data.content);
    } catch (err: any) {
      console.error(err);
      setErrorHeader("Operational boundary. Presenting fallback recommendation mapping.");
      setAiResult(`### AI LABORATORY MATCHES AT ${uniName.toUpperCase()}
Based on your background and skills:

*   **1. Embedded Systems Optimization Lab:**  
    *Target PI:* Lead researchers in computing.  
    *Alignment:* Your custom hardware experiences align with upcoming MCU performance profiling.
*   **2. Machine Learning Security Research Cohort:**  
    *Target PI:* Lead researchers in security models.  
    *Alignment:* Pushing hardware validation scripts into active networks.
*   **3. Emerging Neuromorphic Architectures:**  
    *Target PI:* Computing architecture faculties.  
    *Alignment:* Modeling mixed-signal microchips and circuit boards.`);
    } finally {
      setLoadingAi(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Info block */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2 font-display">
            <Compass className="w-5 h-5 text-cyan-400 text-glow-cyan" />
            <span>Ivy Institutions Database</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Explore graduate admission minimums, standardized target indices, and active research zones.</p>
        </div>

        {/* Global stats info */}
        <div className="flex items-center space-x-3 bg-white/4 px-3.5 py-1.5 border border-white/5 rounded-2xl">
          <span className="text-[9px] font-mono text-slate-500 uppercase font-black">ACTIVE ADMISSIONS</span>
          <span className="text-xs font-bold text-cyan-400 text-glow-cyan font-mono">{universities.length} Institutions Logged</span>
        </div>
      </div>

      {/* Main split dashboard layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Search & Universitiy List */}
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3.5 w-4 h-4 top-3.5 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search by name, country, or keyword..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#020408] border border-white/5 focus:border-cyan-500 rounded-2xl pl-10 pr-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none transition-all"
            />
          </div>

          <div className="space-y-2 max-h-[30rem] overflow-y-auto pr-1 scrollbar-thin">
            {filteredUnis.map(u => {
              const eligible = (profile.academic?.cgpa || 0) >= u.gpaRequirement;
              return (
                <button
                  key={u.id}
                  onClick={() => {
                    setSelectedUniId(u.id);
                    setAiResult("");
                  }}
                  className={`w-full text-left p-4 rounded-2xl border text-xs flex justify-between items-center transition-all cursor-pointer ${
                    selectedUniId === u.id 
                      ? "bg-white/10 border-cyan-500 text-white shadow-[0_0_15px_rgba(6,182,212,0.15)]"
                      : "bg-white/4 border-white/5 text-slate-300 hover:border-white/10 hover:bg-white/6"
                  }`}
                >
                  <div>
                    <span className="block font-bold">Rank #{u.ranking} • {u.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono block mt-1">{u.country}</span>
                  </div>
                  {eligible ? (
                    <CheckCircle className="w-4.5 h-4.5 text-cyan-400 text-glow-cyan" />
                  ) : (
                    <span className="text-[9px] text-slate-550 font-mono font-bold">GPA {u.gpaRequirement}</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Columns: Detailed visual profile & AI recommend map */}
        <div className="lg:col-span-2 space-y-6">
          
          {activeUni ? (
            <div className="space-y-6 animate-fadeIn">
              
              {/* Profile Header Grid */}
              <div className="p-6 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase tracking-widest">Global Rank #{activeUni.ranking}</span>
                    <h2 className="text-white text-lg font-extrabold mt-1.5 font-display">{activeUni.name}</h2>
                    <p className="text-slate-400 text-xs mt-1 font-medium">Location: {activeUni.country}</p>
                  </div>

                  <button
                    onClick={() => handleRequestAiLabs(activeUni.name)}
                    disabled={loadingAi}
                    className="cursor-pointer bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white px-3.5 py-2.5 rounded-xl border border-transparent focus:outline-none transition-all flex items-center space-x-1.5 text-[10px] font-mono font-bold uppercase shadow-[0_0_10px_rgba(6,182,212,0.3)] animate-pulse"
                  >
                    {loadingAi ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Matching Labs...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5 text-white" />
                        <span>Suggest Labs</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Requirements check matrix */}
                <div className="grid grid-cols-3 gap-4 border-t border-white/5 mt-5 pt-4 text-xs font-mono">
                  <div>
                    <span className="block text-slate-500 text-[10px] font-bold">GPA REQUIREMENT</span>
                    <span className="text-white font-black block mt-1">{activeUni.gpaRequirement} (Avg)</span>
                  </div>
                  <div>
                    <span className="block text-slate-500 text-[10px] font-bold">IELTS TARGETS</span>
                    <span className="text-white font-black block mt-1">{activeUni.ieltsRequirement}</span>
                  </div>
                  <div>
                    <span className="block text-slate-500 text-[10px] font-bold">QUANT GRE MEAN</span>
                    <span className="text-white font-black block mt-1">{activeUni.greRequirement}</span>
                  </div>
                </div>
              </div>

              {/* Research areas & funding profiles */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div className="p-5 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl">
                  <span className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                    <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Target Research Fields</span>
                  </span>
                  <div className="flex flex-wrap gap-1.5 mt-2.5">
                    {activeUni.researchAreas.map((area, index) => (
                      <span key={index} className="px-2.5 py-1 rounded-lg bg-[#020408] text-slate-300 text-xs border border-white/5 font-semibold">
                        {area}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="p-5 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl flex flex-col justify-between">
                  <div>
                    <span className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mb-2">Faculty & Funding Streams</span>
                    <p className="text-xs text-slate-300 leading-relaxed mt-2.5 font-sans font-medium">{activeUni.fundingOptions}</p>
                  </div>
                  {activeUni.facultyProfiles && (
                    <div className="mt-3.5 pt-3 border-t border-white/5 font-mono text-[9px] text-slate-500 font-semibold">
                      <span>Faculties: {activeUni.facultyProfiles.join(", ")}</span>
                    </div>
                  )}
                </div>

              </div>

              {/* Lab match results rendering */}
              {(loadingAi || aiResult) && (
                <div className="p-6 rounded-3xl border border-cyan-500/20 bg-gradient-to-br from-indigo-500/10 to-cyan-500/10 backdrop-blur-2xl relative overflow-hidden box-glow-cyan">
                  <span className="absolute top-4 right-4 text-[9px] bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 font-bold rounded-lg font-mono p-1">AI Recommendation Mapping</span>
                  
                  {loadingAi ? (
                    <div className="flex flex-col items-center justify-center py-10 space-y-3.5 animate-pulse">
                      <Loader2 className="w-7 h-7 animate-spin text-cyan-500 text-glow-cyan" />
                      <span className="text-xs text-slate-500 font-mono font-bold">Querying system models for matching faculties...</span>
                    </div>
                  ) : (
                    <div className="prose prose-xs prose-invert text-xs text-slate-200 font-sans mt-4 leading-relaxed whitespace-pre-wrap">
                      {errorHeader && <p className="text-amber-500 font-mono text-[10px] mb-2">{errorHeader}</p>}
                      {aiResult}
                    </div>
                  )}
                </div>
              )}

            </div>
          ) : (
            <div className="p-12 rounded-3xl border border-dashed border-white/10 bg-white/4 backdrop-blur-2xl flex flex-col justify-center items-center text-center">
              <Compass className="w-12 h-12 text-cyan-500 mb-4 animate-pulse" />
              <h3 className="text-white font-bold text-sm font-display">No University Selected</h3>
              <p className="text-slate-400 text-xs mt-1.5 max-w-sm leading-relaxed">Select an Ivy target on the left to review metrics or search specific research domains.</p>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
