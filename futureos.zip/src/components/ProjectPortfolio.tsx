/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { UserProfile, Project } from "../types";
import { FolderGit2, Plus, Trash2, ArrowUpRight, Github, Code } from "lucide-react";

interface ProjectPortfolioProps {
  profile: UserProfile;
  onSaveProfile: (updatedProfile: UserProfile) => void;
}

export default function ProjectPortfolio({ profile, onSaveProfile }: ProjectPortfolioProps) {
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newLink, setNewLink] = useState("");
  const [newType, setNewType] = useState<"academic" | "personal">("academic");

  const handleAddProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;

    const newProject: Project = {
      id: "proj_" + Date.now(),
      title: newTitle,
      description: newDesc,
      githubLink: newLink,
      type: newType
    };

    const updatedProfile = {
      ...profile,
      projects: [...(profile.projects || []), newProject]
    };
    onSaveProfile(updatedProfile);
    setNewTitle("");
    setNewDesc("");
    setNewLink("");
  };

  const handleRemoveProject = (id: string) => {
    const updatedProfile = {
      ...profile,
      projects: (profile.projects || []).filter(p => p.id !== id)
    };
    onSaveProfile(updatedProfile);
  };

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-900 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <FolderGit2 className="w-5 h-5 text-indigo-400" />
            <span>Project Portfolio & Engineering Repos</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Showcase hardware layouts, software applications, and academic compiler repositories.</p>
        </div>

        {/* Aggregate badge */}
        <div className="p-2.5 bg-slate-900/40 border border-slate-900 rounded-xl font-mono text-[10px]">
          <span className="block text-slate-500">TOTAL PROJECTS</span>
          <span className="text-white font-bold">{profile.projects?.length || 0} Listed</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Left Column: Log project form */}
        <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 h-fit space-y-4">
          <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-1.5 flex items-center gap-2">
            <Code className="w-4 h-4 text-indigo-400" />
            <span>Catalog New Project Row</span>
          </h3>

          <form onSubmit={handleAddProject} className="space-y-3.5">
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-400">PROJECT TITLE</label>
              <input 
                type="text" required
                placeholder="e.g. PCB Smart Controller"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-400">DESCRIPTION & PROTOCOLS</label>
              <textarea 
                placeholder="Methodology, memory limits, and signal simulation..."
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-xs text-white h-24 resize-none focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-400">REPOSITORY / GITHUB URL</label>
              <input 
                type="text"
                placeholder="e.g. https://github.com/aria/kicad-mcu"
                value={newLink}
                onChange={(e) => setNewLink(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-400 uppercase">Project classification</label>
              <div className="flex bg-slate-950 border border-slate-850 rounded-xl p-1 text-[10px] font-mono">
                <button
                  type="button"
                  onClick={() => setNewType("academic")}
                  className={`flex-1 py-1 rounded text-center transition-all ${
                    newType === "academic" ? "bg-indigo-600/25 text-indigo-300" : "text-slate-500 hover:text-slate-350"
                  }`}
                >
                  Academic / Research
                </button>
                <button
                  type="button"
                  onClick={() => setNewType("personal")}
                  className={`flex-1 py-1 rounded text-center transition-all ${
                    newType === "personal" ? "bg-indigo-600/25 text-indigo-300" : "text-slate-500 hover:text-slate-350"
                  }`}
                >
                  Personal / Hobby
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 py-2.5 rounded-xl text-white font-mono text-xs font-bold uppercase tracking-wider flex justify-center items-center space-x-1.5 shadow"
            >
              <Plus className="w-4 h-4 text-indigo-300" />
              <span>Catalog Project</span>
            </button>
          </form>
        </div>

        {/* Right Columns: Portfolio layout list */}
        <div className="lg:col-span-2 space-y-4">
          <span className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider">Active Portfolio Stack</span>

          {!profile.projects || profile.projects.length === 0 ? (
            <div className="p-12 text-center rounded-2xl border border-dashed border-slate-850 bg-slate-900/10">
              <span className="text-xs text-slate-500 font-mono block">No custom projects coded yet.</span>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {profile.projects.map(p => (
                <div key={p.id} className="p-4 rounded-xl border border-slate-900 bg-slate-950/40 hover:bg-slate-900/10 transition-colors relative flex flex-col justify-between space-y-4">
                  <div>
                    <div className="flex justify-between items-start">
                      <span className="text-[10px] font-mono text-indigo-400 uppercase tracking-widest">{p.type} Portfolio</span>
                      <button 
                        onClick={() => handleRemoveProject(p.id)}
                        className="text-slate-600 hover:text-red-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <h4 className="text-white text-xs font-bold mt-2">{p.title}</h4>
                    <p className="text-[11px] text-slate-400 leading-relaxed mt-2.5">{p.description}</p>
                  </div>

                  {p.githubLink && (
                    <div className="pt-3 border-t border-slate-900 flex justify-between items-center text-[10px] font-mono">
                      <span className="text-slate-500 truncate max-w-[10rem]">{p.githubLink}</span>
                      <a 
                        href={p.githubLink} 
                        target="_blank" 
                        referrerPolicy="no-referrer"
                        className="text-indigo-400 hover:text-white flex items-center space-x-1"
                      >
                        <Github className="w-3.5 h-3.5 text-slate-450" />
                        <span>Source</span>
                        <ArrowUpRight className="w-3.5 h-3.5 text-slate-550" />
                      </a>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
