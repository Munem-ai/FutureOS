/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Skill, UserProfile } from "../types";
import { 
  Award, Code, Cpu, MessageSquare, 
  Plus, CheckCircle2, Navigation2, BookOpen, Clock, 
  Search, Sliders, ChevronDown, ChevronUp, History, Sparkles, Trash2, Hourglass
} from "lucide-react";

interface SkillTrackerProps {
  profile: UserProfile;
  onUpdateProfile?: (updatedProfile: UserProfile) => void;
}

interface StudyEvent {
  id: string;
  skillName: string;
  topic: string;
  duration: number; // minutes
  date: string;
  summary: string;
}

export default function SkillTracker({ profile, onUpdateProfile }: SkillTrackerProps) {
  // Local state for searches and new additions
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSkillName, setSelectedSkillName] = useState<string>(
    profile.skills[0]?.name || "Embedded Firmware Development"
  );
  
  // Collapse controller for adding new skills form
  const [showAddForm, setShowAddForm] = useState(false);
  const [newSkillName, setNewSkillName] = useState("");
  const [newSkillCategory, setNewSkillCategory] = useState<"software" | "hardware" | "professional">("software");
  const [newSkillLevel, setNewSkillLevel] = useState<"Beginner" | "Intermediate" | "Advanced" | "Expert">("Intermediate");
  const [newSkillProgress, setNewSkillProgress] = useState<number>(30);
  const [formError, setFormError] = useState("");

  // Activity log tracking
  const [studyLogs, setStudyLogs] = useState<StudyEvent[]>([
    {
      id: "log_1",
      skillName: "Embedded Firmware Development",
      topic: "DMA Buffer Triggers Configuration",
      duration: 90,
      date: "2026-06-07",
      summary: "Implemented nested ping-pong buffers for smooth SPI telemetry streaming into flash memory."
    },
    {
      id: "log_2",
      skillName: "PCB Trace Design (Altium/KiCad)",
      topic: "Impedance calculations for SPI bus",
      duration: 60,
      date: "2026-06-06",
      summary: "Calibrated microstrip trace width to 4.5mils over ground reference to reach ~50 Ohm match target."
    }
  ]);

  // Form states for log study session
  const [logTopic, setLogTopic] = useState("");
  const [logDuration, setLogDuration] = useState<number>(60);
  const [logSummary, setLogSummary] = useState("");

  const activeSkill = profile.skills.find(s => s.name === selectedSkillName) || profile.skills[0];

  // Colors and Icons mapping for Categories
  const categoryIcons = {
    software: Code,
    hardware: Cpu,
    professional: MessageSquare
  };

  const levelColors = {
    Beginner: "text-blue-400 bg-blue-950/20 border-blue-900/40",
    Intermediate: "text-amber-400 bg-amber-950/20 border-amber-900/40",
    Advanced: "text-indigo-400 bg-indigo-950/20 border-indigo-900/40",
    Expert: "text-emerald-400 bg-emerald-950/20 border-emerald-900/40"
  };

  // Search filter
  const filteredSkills = profile.skills.filter(s => {
    const term = searchQuery.toLowerCase();
    return (
      s.name.toLowerCase().includes(term) ||
      s.category.toLowerCase().includes(term) ||
      s.level.toLowerCase().includes(term)
    );
  });

  // Save changes helper
  const triggerProfileUpdate = (updatedSkills: Skill[]) => {
    if (onUpdateProfile) {
      onUpdateProfile({
        ...profile,
        skills: updatedSkills
      });
    }
  };

  // Handles adding customized user inputs for skills they are learning
  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");

    if (!newSkillName.trim()) {
      setFormError("Skill name represents a required criteria.");
      return;
    }

    const exists = profile.skills.some(
      s => s.name.toLowerCase().trim() === newSkillName.toLowerCase().trim()
    );
    if (exists) {
      setFormError("This technical competency is already in your active profile.");
      return;
    }

    const createdSkill: Skill = {
      name: newSkillName.trim(),
      category: newSkillCategory,
      level: newSkillLevel,
      progress: Math.min(100, Math.max(0, newSkillProgress))
    };

    const updatedSkills = [...profile.skills, createdSkill];
    triggerProfileUpdate(updatedSkills);

    // Reset inputs
    setSelectedSkillName(createdSkill.name);
    setNewSkillName("");
    setNewSkillProgress(40);
    setShowAddForm(false);
  };

  // Delete a skill from profile
  const handleDeleteSkill = (skillToDelete: string) => {
    const updatedSkills = profile.skills.filter(s => s.name !== skillToDelete);
    triggerProfileUpdate(updatedSkills);
    if (selectedSkillName === skillToDelete && updatedSkills.length > 0) {
      setSelectedSkillName(updatedSkills[0].name);
    }
  };

  // Adjust skill progress percentage slider
  const handleProgressSliderChange = (newVal: number) => {
    const updatedSkills = profile.skills.map(s => {
      if (s.name === activeSkill.name) {
        // Automatically project level based on slider progress thresholds
        let calculatedLevel = s.level;
        if (newVal >= 90) calculatedLevel = "Expert";
        else if (newVal >= 70) calculatedLevel = "Advanced";
        else if (newVal >= 40) calculatedLevel = "Intermediate";
        else calculatedLevel = "Beginner";

        return { ...s, progress: newVal, level: calculatedLevel };
      }
      return s;
    });
    triggerProfileUpdate(updatedSkills);
  };

  // Boost progress by 5% and append a study log
  const handleQuickSessionBoost = () => {
    if (!activeSkill) return;
    const currentProgress = activeSkill.progress;
    const nextProgress = Math.min(100, currentProgress + 5);

    // Update progress
    handleProgressSliderChange(nextProgress);

    // Auto log interactive activity events
    const generatedLog: StudyEvent = {
      id: "quick_log_" + Date.now(),
      skillName: activeSkill.name,
      topic: "Interactive Sprint Session Completed",
      duration: 30,
      date: new Date().toISOString().split("T")[0],
      summary: `Automated micro-sprint. Progress accumulated from ${currentProgress}% to ${nextProgress}%. Checked literature references.`
    };
    setStudyLogs([generatedLog, ...studyLogs]);
  };

  // Logging formal study log sheets manually
  const handleSubmitStudyLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!logTopic.trim() || !activeSkill) return;

    const newLog: StudyEvent = {
      id: "log_" + Date.now(),
      skillName: activeSkill.name,
      topic: logTopic.trim(),
      duration: logDuration,
      date: new Date().toISOString().split("T")[0],
      summary: logSummary ? logSummary.trim() : "Reviewed documentation and compiled testing sheets."
    };

    setStudyLogs([newLog, ...studyLogs]);

    // Boost progress according to hours logged: +5% for 60 minutes
    const progressBoost = Math.max(2, Math.min(15, Math.round(logDuration / 12)));
    const targetProgress = Math.min(100, activeSkill.progress + progressBoost);
    handleProgressSliderChange(targetProgress);

    // Reset log prompts
    setLogTopic("");
    setLogSummary("");
  };

  // Generate customized academic roadmap directions dynamically based on active skill attributes
  const getSkillRoadmapDetails = (name: string, level: string) => {
    const isHardware = name.toLowerCase().includes("pcb") || name.toLowerCase().includes("stm") || name.toLowerCase().includes("embedded") || name.toLowerCase().includes("hardware") || name.toLowerCase().includes("circuit") || name.toLowerCase().includes("signal");
    const isAi = name.toLowerCase().includes("learning") || name.toLowerCase().includes("pytorch") || name.toLowerCase().includes("tensorflow") || name.toLowerCase().includes("python") || name.toLowerCase().includes("model") || name.toLowerCase().includes("classification") || name.toLowerCase().includes("network");

    if (isHardware) {
      return {
        estimatedCompletion: "12-14 Weeks to Next Tier",
        phases: [
          { title: "Standard Circuit Impedance Rules", desc: "Understanding schematic split decoupling networks, power layer grids, noise signals margins, and single-ended impedance parameters." },
          { title: "Bare-Metal Interface Protocols (SPI/I2C/UART)", desc: "Trigger configurations of DMA registers, nested vector interrupt controller (NVIC) traps, and high precision ADC clock cycles." },
          { title: "Real-Time FreeRTOS Tasks scheduling", desc: "Cooperative vs pre-emptive multi-threading, context-switching latency metrics, and debugging trace tasks via STM32 Analyzer." }
        ]
      };
    } else if (isAi) {
      return {
        estimatedCompletion: "8-10 Weeks to Next Tier",
        phases: [
          { title: "Neural Pruning & Quantization Theories", desc: "Study tensor node-graph weight distributions, parameter coordinate mappings, roundoff thresholds, and fractional errors calculations." },
          { title: "PyTorch QAT Loops Construction", desc: "Inject programmatic dynamic quant-stubs modules directly into neural training setups to simulate fractional bit bounds." },
          { title: "MCU Compiler Target Executions", desc: "Convert PyTorch graphs into standalone C arrays, configure flatbuffer allocators, and deploy inferences with zero RTOS dependencies." }
        ]
      };
    } else {
      return {
        estimatedCompletion: "6 Weeks to Next Tier",
        phases: [
          { title: "Technical Rhetoric Framing Analysis", desc: "Critically audit successful Statements of Purpose (SOP), letters of intent, and published peer peer-reviews." },
          { title: "Interactive Colloquiums & Panel Presentations", desc: "Structure academic visuals laying out methodology pipelines and field cross-examination questions smoothly." },
          { title: "IEEE Writing and Academic Layout Guidelines", desc: "Commit to active voice narratives, rigorous mathematical variables descriptions, and exact structured citations formatting." }
        ]
      };
    }
  };

  const roadmapDetails = activeSkill ? getSkillRoadmapDetails(activeSkill.name, activeSkill.level) : null;

  return (
    <div className="space-y-6">
      
      {/* 1. Header & Stats Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5 font-display">
            <Award className="w-6 h-6 text-cyan-400 text-glow-cyan" />
            <span>Master Skill Accelerator Dashboard</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed font-sans">
            Log and audit hardware layouts, machine learning pipelines, and professional credentials required for Ivy academic admission gates.
          </p>
        </div>

        {/* Global summary count */}
        <div className="flex items-center space-x-6 p-4 rounded-2xl border border-white/5 bg-white/4 backdrop-blur-2xl font-mono text-[10px] text-slate-400 shadow-lg">
          <div>
            <span className="block text-slate-500 font-bold">TOTAL SKILLS</span>
            <span className="text-white font-black">{profile.skills.length} Active</span>
          </div>
          <div className="border-r border-white/5 h-6 animate-pulse" />
          <div>
            <span className="block text-slate-500 font-bold">ADVANCED / EXPERT</span>
            <span className="text-cyan-400 font-black text-glow-cyan">
              {profile.skills.filter(s => s.level === "Expert" || s.level === "Advanced").length} Subjects
            </span>
          </div>
        </div>
      </div>

      {/* 2. Compact Search & Add Collapsible Bar */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          
          {/* Integrated Search box input */}
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search skill criteria..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#020408] border border-white/5 focus:border-cyan-500/50 rounded-xl pl-9.5 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-all font-mono"
            />
          </div>

          {/* Trigger to toggle Add new Skill input */}
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="w-full sm:w-auto cursor-pointer flex items-center justify-center space-x-2 bg-white/4 hover:bg-white/8 border border-white/10 text-xs font-mono font-bold px-4 py-2.5 rounded-xl text-cyan-400 hover:text-white transition-all shadow-[0_0_12px_rgba(255,255,255,0.02)]"
          >
            {showAddForm ? (
              <>
                <ChevronUp className="w-4 h-4 text-cyan-500" />
                <span>Collapse Form</span>
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 text-cyan-500" />
                <span>Track New Competency</span>
              </>
            )}
          </button>
        </div>

        {/* Collapsible form to track and log what they are learning */}
        {showAddForm && (
          <form 
            onSubmit={handleAddSkill} 
            className="p-5 rounded-3xl border border-cyan-500/25 bg-gradient-to-r from-[#020408] to-cyan-950/10 space-y-4 animate-fadeIn"
          >
            <div className="flex justify-between items-center border-b border-white/5 pb-2">
              <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse text-glow-cyan" />
                <span>Establish Learning Target</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">Will synch to admissions dashboard indices</span>
            </div>

            {formError && (
              <p className="text-[10px] font-mono text-pink-500">{formError}</p>
            )}

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
              
              {/* Skill name input */}
              <div className="space-y-1.5 md:col-span-2">
                <label className="text-[9px] text-slate-500 font-bold block">COMPETENCY SUBJECT NAME</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. PyTorch Deep Learning Models, Verilog VLSI"
                  value={newSkillName}
                  onChange={(e) => setNewSkillName(e.target.value)}
                  className="w-full bg-[#020408] border border-white/5 focus:border-cyan-500 rounded-xl px-3 py-2 text-white focus:outline-none placeholder-slate-600 font-sans"
                />
              </div>

              {/* Category selector */}
              <div className="space-y-1.5">
                <label className="text-[9px] text-slate-500 font-bold block">CATEGORY</label>
                <select
                  value={newSkillCategory}
                  onChange={(e) => setNewSkillCategory(e.target.value as any)}
                  className="w-full bg-[#020408] border border-white/5 rounded-xl px-3 py-2 text-slate-350 focus:outline-none cursor-pointer"
                >
                  <option value="software">Software Engineering</option>
                  <option value="hardware">Hardware / Systems</option>
                  <option value="professional">Professional / Soft Skills</option>
                </select>
              </div>

              {/* Initial level selection */}
              <div className="space-y-1.5">
                <label className="text-[9px] text-slate-500 font-bold block">CURRENT LEVEL</label>
                <select
                  value={newSkillLevel}
                  onChange={(e) => setNewSkillLevel(e.target.value as any)}
                  className="w-full bg-[#020408] border border-white/5 rounded-xl px-3 py-2 text-slate-350 focus:outline-none cursor-pointer"
                >
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                  <option value="Expert">Expert</option>
                </select>
              </div>

            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
              <div className="flex items-center space-x-3 w-full sm:w-auto font-mono text-xs">
                <span className="text-[9px] text-slate-500 font-bold uppercase whitespace-nowrap">STARTING PROGRESS:</span>
                <span className="text-cyan-400 font-black shrink-0 w-8">{newSkillProgress}%</span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={newSkillProgress}
                  onChange={(e) => setNewSkillProgress(parseInt(e.target.value))}
                  className="w-40 bg-white/5 h-1.5 rounded-lg appearance-none cursor-pointer accent-cyan-500 outline-none"
                />
              </div>

              <button
                type="submit"
                className="cursor-pointer w-full sm:w-auto bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 px-5 py-2.5 rounded-xl text-white font-mono text-[10px] font-bold uppercase tracking-wider flex items-center justify-center space-x-1.5 shadow-[0_0_12px_rgba(6,182,212,0.3)]"
              >
                <Plus className="w-4 h-4 text-white" />
                <span>Initialize Skills Tracker</span>
              </button>
            </div>
          </form>
        )}
      </div>

      {/* 3. Main Dashboard Double Split Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* Left column (col-span-4): Skill Card Selection listings */}
        <div className="lg:col-span-5 space-y-4">
          <span className="block text-[10px] font-mono text-slate-500 uppercase tracking-widest font-bold">ACTIVE SKILL PORTFOLIO</span>
          
          <div className="space-y-2.5 max-h-[30rem] overflow-y-auto pr-1 scrollbar-thin">
            {filteredSkills.length === 0 ? (
              <div className="p-8 text-center rounded-2xl border border-dashed border-white/5 bg-white/4">
                <span className="text-xs text-slate-550 font-mono block">No logged skills matching keyword.</span>
              </div>
            ) : (
              filteredSkills.map((s, idx) => {
                const IconComp = categoryIcons[s.category] || Code;
                const isSelected = selectedSkillName === s.name;
                return (
                  <div
                    key={idx}
                    className={`p-4 rounded-2xl border transition-all flex flex-col justify-between group relative overflow-hidden ${
                      isSelected 
                        ? "bg-white/10 border-cyan-500 text-white shadow-[0_0_15px_rgba(6,182,212,0.1)]"
                        : "bg-white/4 border-white/5 text-slate-350 hover:border-white/10 hover:bg-white/6"
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      {/* Technical trigger selection wrapper */}
                      <button
                        onClick={() => setSelectedSkillName(s.name)}
                        className="flex items-center space-x-3 text-left focus:outline-none flex-grow mr-2 cursor-pointer"
                      >
                        <div className="w-8 h-8 rounded-xl bg-[#020408] border border-white/5 flex items-center justify-center group-hover:bg-cyan-500/10 transition-colors">
                          <IconComp className={`w-3.5 h-3.5 ${isSelected ? "text-cyan-400 text-glow-cyan" : "text-slate-500 group-hover:text-cyan-400 transition-colors"}`} />
                        </div>
                        <div>
                          <span className="text-xs font-bold block text-slate-200">{s.name}</span>
                          <span className="text-[8px] text-slate-500 mt-0.5 tracking-widest uppercase font-mono">{s.category}</span>
                        </div>
                      </button>

                      <div className="flex items-center space-x-1.5 shrink-0">
                        <span className={`px-1.5 py-0.5 rounded-md text-[8px] border font-mono uppercase font-bold ${levelColors[s.level]}`}>
                          {s.level}
                        </span>
                        
                        {/* Delete skill item option */}
                        <button
                          onClick={() => handleDeleteSkill(s.name)}
                          title="Remove competency"
                          className="p-1 rounded text-slate-600 hover:text-pink-500 hover:bg-pink-950/20 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Progress tracking bar visually with progress transitions */}
                    <div className="w-full mt-4 flex items-center justify-between gap-3 text-[10px] font-mono">
                      <div className="flex-grow bg-[#020408] h-1.5 rounded-full overflow-hidden border border-white/4">
                        <div 
                          className="bg-gradient-to-r from-cyan-500 to-blue-500 h-1.5 transition-all duration-500 shadow-[0_0_10px_rgba(6,182,212,0.6)]" 
                          style={{ width: `${s.progress}%` }} 
                        />
                      </div>
                      <span className="text-slate-400 font-bold flex-shrink-0">{s.progress}%</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right column (col-span-8): Selected Skill Audit Workbench */}
        <div className="lg:col-span-7 space-y-6">

          {activeSkill ? (
            <div className="space-y-6 animate-fadeIn">

              {/* Selected Skill Audit Header block */}
              <div className="p-5.5 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl relative overflow-hidden group">
                <div className="absolute -right-12 -top-12 w-32 h-32 bg-cyan-500/5 blur-2xl rounded-full pointer-events-none group-hover:bg-cyan-500/10 transition-colors" />

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/5">
                  <div>
                    <span className="text-[9px] font-mono font-bold text-cyan-400 uppercase tracking-widest">{activeSkill.category} Accelerator Tracker</span>
                    <h2 className="text-white text-lg font-bold mt-1 font-display tracking-tight text-glow-cyan">{activeSkill.name}</h2>
                  </div>
                  <span className={`px-2.5 py-1 text-[10px] border rounded-lg font-bold font-mono uppercase self-start sm:self-auto ${levelColors[activeSkill.level]}`}>
                    {activeSkill.level} LEVEL APPROVED
                  </span>
                </div>

                {/* SLIDES FOR TRACKING CURRENT PROGRESS */}
                <div className="py-5 border-b border-white/5 space-y-3">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400 font-bold flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-cyan-500" />
                      <span>Adjust Current Progress Threshold</span>
                    </span>
                    <span className="text-cyan-400 font-black text-glow-cyan text-sm">{activeSkill.progress}% Complete</span>
                  </div>
                  
                  {/* Real responsive progress manual update */}
                  <div className="flex items-center space-x-4">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={activeSkill.progress}
                      onChange={(e) => handleProgressSliderChange(parseInt(e.target.value))}
                      className="flex-1 bg-white/5 h-2 rounded-lg appearance-none cursor-pointer accent-cyan-500 outline-none border border-white/5"
                    />
                    
                    {/* Quick increment trigger */}
                    <button
                      onClick={handleQuickSessionBoost}
                      className="cursor-pointer font-mono text-[9px] font-black bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 px-3 py-1.5 rounded-lg uppercase tracking-wider flex items-center space-x-1 shrink-0"
                      title="Accumulate +5% from quick studies logs"
                    >
                      <Sparkles className="w-3 h-3 text-cyan-400 animate-pulse" />
                      <span>+5% Study Boost</span>
                    </button>
                  </div>
                </div>

                {/* Sub info boxes */}
                <div className="grid grid-cols-2 gap-4 pt-4 text-xs font-mono">
                  <div className="flex items-center space-x-3 bg-[#020408]/40 p-3 rounded-xl border border-white/5">
                    <Clock className="w-4 h-4 text-cyan-400" />
                    <div>
                      <span className="block text-[8px] text-slate-500">ESTIMATED INTERVALS</span>
                      <span className="text-slate-200 font-bold">{roadmapDetails?.estimatedCompletion}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 bg-[#020408]/40 p-3 rounded-xl border border-white/5">
                    <Award className="w-4 h-4 text-emerald-400 animate-pulse" />
                    <div>
                      <span className="block text-[8px] text-slate-500">ALIGNED MILESTONES</span>
                      <span className="text-slate-200 font-bold">PhD Admission Ready</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* STUDY SESSION LOGGER FRAME - DIRECT USER INPUT & TRACKING */}
              <div className="p-5.5 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl space-y-4">
                <div className="flex justify-between items-center border-b border-white/5 pb-2">
                  <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
                    <History className="w-4 h-4 text-cyan-400" />
                    <span>Log Active Learning Session</span>
                  </h3>
                  <span className="text-[10px] text-cyan-500 font-mono font-medium flex items-center gap-1.5">
                    <Hourglass className="w-3 h-3 text-cyan-400 animate-spin" />
                    Completes milestones
                  </span>
                </div>

                <form onSubmit={handleSubmitStudyLog} className="space-y-3.5 text-xs font-mono">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    
                    {/* Log action title */}
                    <div className="space-y-1.5 sm:col-span-2">
                      <label className="text-[8px] text-slate-500 font-bold block">STUDIED MODULE / TOPIC</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Configured interrupt vectors registers, read QAT chapter"
                        value={logTopic}
                        onChange={(e) => setLogTopic(e.target.value)}
                        className="w-full bg-[#020408] border border-white/5 focus:border-cyan-500 rounded-xl px-3 py-2 text-white focus:outline-none placeholder-slate-650 font-normal "
                      />
                    </div>

                    {/* Studied duration */}
                    <div className="space-y-1.5">
                      <label className="text-[8px] text-slate-500 font-bold block">DURATION (MINUTES)</label>
                      <select
                        value={logDuration}
                        onChange={(e) => setLogDuration(parseInt(e.target.value))}
                        className="w-full bg-[#020408] border border-white/5 rounded-xl px-3 py-2 text-slate-350 focus:outline-none cursor-pointer"
                      >
                        <option value="15">15 Minutes</option>
                        <option value="30">30 Minutes</option>
                        <option value="45">45 Minutes</option>
                        <option value="60">1 Hour</option>
                        <option value="120">2 Hours</option>
                        <option value="180">3 Hours</option>
                      </select>
                    </div>

                  </div>

                  {/* Log summary context */}
                  <div className="space-y-1.5">
                    <label className="text-[8px] text-slate-500 font-bold block">SESSION REFLECTION SUMMARY (SPECIFIC FORMULAS OR CITATIONS)</label>
                    <textarea
                      placeholder="Detail specific roadblocks bypassed, physical MCU measurements recorded, or files drafted..."
                      value={logSummary}
                      onChange={(e) => setLogSummary(e.target.value)}
                      className="w-full bg-[#020408] border border-white/5 focus:border-cyan-500 rounded-xl px-3 py-2 text-white h-16 resize-none focus:outline-none placeholder-slate-650 font-normal font-sans"
                    />
                  </div>

                  <button
                    type="submit"
                    className="cursor-pointer w-full bg-white/4 hover:bg-cyan-500/15 border border-white/10 hover:border-cyan-500/30 py-2 rounded-xl text-center text-slate-200 hover:text-cyan-400 font-mono text-[10px] font-bold uppercase transition-all flex items-center justify-center space-x-1.5 shadow-[0_0_10px_rgba(0,0,0,0.5)]"
                  >
                    <Plus className="w-4 h-4 text-cyan-400" />
                    <span>Append Session to Sprints Timeline</span>
                  </button>
                </form>

                {/* Sprints Timeline */}
                <div className="pt-4 border-t border-white/5">
                  <span className="block text-[8px] font-mono text-slate-550 font-black uppercase tracking-widest mb-3.5">COMPLETED ACTIVITY RECORD</span>
                  
                  <div className="space-y-4 max-h-48 overflow-y-auto pr-1">
                    {studyLogs
                      .filter(log => log.skillName === activeSkill.name)
                      .map((log) => (
                        <div key={log.id} className="relative pl-5 border-l border-white/5 last:border-0 pb-1.5 text-xs">
                          {/* visual timeline indicator */}
                          <div className="absolute -left-1.5 top-0.5 w-3 h-3 rounded-full bg-cyan-950 border border-cyan-500 animate-pulse" />
                          
                          <div className="flex justify-between items-start">
                            <span className="font-bold text-slate-200">{log.topic}</span>
                            <span className="text-[8px] font-mono text-slate-500 tracking-wide font-medium">{log.date} • {log.duration} mins</span>
                          </div>
                          <p className="text-[10px] text-slate-550 leading-relaxed mt-1 font-sans font-medium">{log.summary}</p>
                        </div>
                      ))}

                    {studyLogs.filter(log => log.skillName === activeSkill.name).length === 0 && (
                      <span className="text-[10px] text-slate-500 font-mono block italic text-center">No recorded activity logs for this subject.</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Visualized Learning Roadmap checklist */}
              <div className="p-5.5 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl space-y-4">
                <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
                  <Navigation2 className="w-4 h-4 text-cyan-400 rotate-90" />
                  <span>Personalized Academic Milestones Timeline</span>
                </h3>

                <div className="space-y-5 pt-3">
                  {roadmapDetails?.phases.map((phase, idx) => (
                    <div key={idx} className="relative pl-7 border-l-2 border-dashed border-white/5 last:border-0 pb-2">
                      {/* Node circle */}
                      <span className="absolute -left-2.5 top-0 w-[18px] h-[18px] rounded-full bg-[#020408] border border-cyan-500/50 flex items-center justify-center text-[8px] font-mono font-bold text-cyan-400 text-glow-cyan shadow-sm animate-pulse">
                        {idx + 1}
                      </span>
                      
                      <h4 className="text-slate-200 text-xs font-bold leading-none">{phase.title}</h4>
                      <p className="text-[11px] text-slate-450 leading-relaxed mt-2 font-medium">{phase.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          ) : (
            <div className="p-12 rounded-3xl border border-dashed border-white/10 bg-white/4 backdrop-blur-2xl text-center text-slate-500">
              <span className="text-xs font-mono block">No active subject selected. Select a subject to manage or edit competencies.</span>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
