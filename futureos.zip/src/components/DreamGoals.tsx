/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { DreamGoal, UserProfile } from "../types";
import { 
  Target, Sparkles, AlertCircle, ArrowUpRight, 
  MapPin, Clock, BrainCircuit, Play, Loader2, RefreshCw, Plus 
} from "lucide-react";

interface DreamGoalsProps {
  profile: UserProfile;
  goals: DreamGoal[];
  onDiagnoseGoal: (goalId: string, parsedData: any) => void;
  onAddGoal: (newGoal: DreamGoal) => void;
}

export default function DreamGoals({ 
  profile, 
  goals, 
  onDiagnoseGoal, 
  onAddGoal 
}: DreamGoalsProps) {
  const [selectedGoalId, setSelectedGoalId] = useState<string>(goals[0]?.id || "");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const activeGoal = goals.find(g => g.id === selectedGoalId) || goals[0];

  const handleDiagnose = async () => {
    if (!activeGoal) return;
    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/ai/career-advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profile,
          goalTitle: activeGoal.title,
          targetInstitution: activeGoal.targetInstitution
        })
      });

      if (!response.ok) {
        throw new Error("Unable to contact backend AI analysis engine.");
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      // Update goal in parent state
      onDiagnoseGoal(activeGoal.id, data);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Transient server bottleneck. Using simulated fallback diagnostics.");
    } finally {
      setLoading(false);
    }
  };

  // Custom static goal templates to add rapidly
  const goalTemplates = [
    { title: "MIT PhD in EECS", targetInstitution: "Massachusetts Institute of Technology" },
    { title: "Stanford MS in CS", targetInstitution: "Stanford University" },
    { title: "ETH Zurich Robotics Scholarship", targetInstitution: "ETH Zurich" },
    { title: "Erasmus Mundus Joint Masters", targetInstitution: "European Commission" },
    { title: "Fulbright Scholar-elect", targetInstitution: "US State Department" },
    { title: "DAAD EPOS German Scholar", targetInstitution: "DAAD Germany" },
    { title: "MEXT Japan Research Scholar", targetInstitution: "MEXT Japan" },
    { title: "Tesla Embedded Firmware Engineer", targetInstitution: "Tesla Motors Inc." },
    { title: "Google Senior Hardware Engineer", targetInstitution: "Google LLC" }
  ];

  const handleAddTemplate = (tpl: typeof goalTemplates[0]) => {
    const isDup = goals.some(g => g.title.toLowerCase() === tpl.title.toLowerCase());
    if (isDup) {
      setError(`Your system dashboard is already tracking ${tpl.title}.`);
      return;
    }

    const newGoal: DreamGoal = {
      id: "g_" + Date.now(),
      title: tpl.title,
      targetInstitution: tpl.targetInstitution,
      readinessScore: 0,
      probabilityScore: 0,
      missingRequirements: ["Diagnose to calculate requirements"],
      skillGaps: ["Pending AI audit scan"],
      researchGaps: ["Pending academic literature sweep"],
      estimatedTime: "Calculated post-diagnose",
      personalizedRoadmap: ""
    };
    onAddGoal(newGoal);
    setSelectedGoalId(newGoal.id);
  };

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2 font-display">
            <Target className="w-5 h-5 text-cyan-400 text-glow-cyan" />
            <span>Dream Goal Trajectory System</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Specify your dream destinations (MIT, Tesla, Erasmus) and invoke AI diagnostics sweeps.</p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={handleDiagnose}
            disabled={loading || !activeGoal}
            className="cursor-pointer bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:from-slate-800 disabled:to-slate-900 disabled:text-slate-550 text-white font-mono font-bold text-xs px-5 py-3 rounded-2xl shadow-[0_0_20px_rgba(6,182,212,0.4)] flex items-center space-x-2.5 transition-all"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-white" />
                <span>Scanning Diagnostics...</span>
              </>
            ) : (
              <>
                <BrainCircuit className="w-4 h-4" />
                <span>Run AI Diagnostic Analysis</span>
              </>
            )}
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-950/20 border border-red-500/20 rounded-2xl flex items-center space-x-3 text-red-200 text-xs">
          <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main split grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Left column: Goals targets tracker list */}
        <div className="space-y-5">
          <div className="p-5 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl">
            <span className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mb-3">Monitoring Targets</span>
            
            <div className="space-y-2">
              {goals.map((g) => {
                const isSelected = g.id === selectedGoalId;
                return (
                  <button
                    key={g.id}
                    onClick={() => setSelectedGoalId(g.id)}
                    className={`w-full text-left p-3.5 rounded-2xl border text-xs flex justify-between items-center transition-all cursor-pointer ${
                      isSelected
                        ? "bg-white/10 border-cyan-500 text-white shadow-[0_0_15px_rgba(6,182,212,0.15)]"
                        : "bg-white/4 border-white/5 text-slate-300 hover:border-white/10 hover:bg-white/6"
                    }`}
                  >
                    <div>
                      <span className="block font-bold">{g.title}</span>
                      <span className="text-[10px] text-slate-450 font-mono italic block mt-0.5">{g.targetInstitution}</span>
                    </div>
                    {g.readinessScore > 0 ? (
                      <span className="px-2 py-0.5 rounded-lg bg-cyan-950/20 text-cyan-400 border border-cyan-500/30 font-mono text-[9px] font-bold">
                        {g.readinessScore}% Match
                      </span>
                    ) : (
                      <span className="text-[9px] text-slate-500 font-mono">No analysis</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick inject goal profiles */}
          <div className="p-5 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl space-y-4">
            <span className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest border-b border-white/5 pb-2 flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Elite Target Templates</span>
            </span>

            <div className="grid grid-cols-1 gap-2 max-h-[14rem] overflow-y-auto pr-1">
              {goalTemplates.map((t, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAddTemplate(t)}
                  className="p-3 border border-white/5 bg-white/4 text-slate-300 hover:text-white hover:border-cyan-500/40 hover:bg-white/8 text-left rounded-2xl text-xs transition-all flex justify-between items-center cursor-pointer"
                >
                  <div className="overflow-hidden">
                    <span className="block font-bold truncate max-w-[12rem]">{t.title}</span>
                    <span className="block text-[9px] text-slate-500 truncate max-w-[12rem]">{t.targetInstitution}</span>
                  </div>
                  <Plus className="w-4 h-4 text-slate-400" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Columns: AI Diagnostics Outputs */}
        <div className="lg:col-span-2 space-y-6">
          
          {activeGoal ? (
            activeGoal.readinessScore > 0 ? (
              // Active detailed diagnosis
              <div className="space-y-6 animate-fadeIn">
                
                {/* Score Indicators Bento Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-5 rounded-3xl bg-cyan-950/20 border border-cyan-500/20 shadow-md flex flex-col justify-between box-glow-cyan">
                    <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase">Readiness Metric Match</span>
                    <h3 className="text-4xl font-extrabold text-white mt-1.5 font-display text-glow-cyan">{activeGoal.readinessScore}%</h3>
                    <p className="text-[10px] text-slate-350 leading-relaxed mt-2.5 font-sans">Overall alignment across GPA benchmarks & hardware skills.</p>
                  </div>

                  <div className="p-5 rounded-3xl bg-blue-950/20 border border-blue-500/20 shadow-md flex flex-col justify-between">
                    <span className="text-[10px] font-mono font-bold text-blue-400 uppercase">Success Probability</span>
                    <h3 className="text-4xl font-extrabold text-white mt-1.5 font-display text-glow-blue">{activeGoal.probabilityScore}%</h3>
                    <p className="text-[10px] text-slate-350 leading-relaxed mt-2.5 font-sans">Predicted feasibility under competitive candidate pools.</p>
                  </div>

                  <div className="p-5 rounded-3xl bg-white/4 border border-white/5 shadow-md flex flex-col justify-between">
                    <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">Advisors Timescale</span>
                    <h3 className="text-3xl font-extrabold text-slate-200 mt-1.5 font-display">{activeGoal.estimatedTime}</h3>
                    <p className="text-[10px] text-slate-350 leading-relaxed mt-2.5 font-sans">Recommended study duration remaining to qualify fully.</p>
                  </div>
                </div>

                {/* Requirements, Skill Gaps & Research Gaps Lists */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  <div className="p-5 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl">
                    <span className="block text-[10px] font-mono font-bold text-slate-300 uppercase tracking-widest mb-2 border-b border-white/5 pb-2 flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-cyan-400 text-glow-cyan" />
                      <span>Formal Gaps & Pre-requisites</span>
                    </span>
                    <ul className="space-y-2 text-xs text-slate-300 mt-3 list-disc list-inside leading-relaxed">
                      {activeGoal.missingRequirements.map((r, i) => (
                        <li key={i} className="leading-relaxed font-medium">{r}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-5 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl">
                    <span className="block text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-widest mb-2 border-b border-white/5 pb-2 flex items-center gap-2">
                      <BrainCircuit className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Target Competency Gaps</span>
                    </span>
                    <ul className="space-y-2 text-xs text-slate-300 mt-3 list-disc list-inside leading-relaxed">
                      {activeGoal.skillGaps.map((g, i) => (
                        <li key={i} className="leading-relaxed font-medium">{g}</li>
                      ))}
                      {activeGoal.researchGaps.map((r, i) => (
                        <li key={i} className="leading-relaxed italic text-emerald-400/85">{r}</li>
                      ))}
                    </ul>
                  </div>

                </div>

                {/* AI Personalized Roadmap details */}
                <div className="p-6 rounded-3xl border border-white/10 bg-gradient-to-br from-indigo-500/10 to-cyan-500/10 backdrop-blur-2xl relative overflow-hidden box-glow-cyan group">
                  <div className="absolute -right-16 -top-16 w-40 h-40 bg-cyan-500/5 blur-[50px] rounded-full group-hover:bg-cyan-500/10 transition-colors" />
                  <span className="absolute top-4 right-4 text-[9px] bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 rounded-lg font-mono font-bold p-1">Operational Sprints Map</span>
                  
                  <div className="prose prose-invert prose-xs text-xs text-slate-200 leading-relaxed font-sans mt-4 whitespace-pre-wrap">
                    {activeGoal.personalizedRoadmap}
                  </div>
                </div>

              </div>
            ) : (
              // Initial state: diagnosis pending
              <div className="p-12 rounded-3xl border border-dashed border-white/10 bg-white/4 backdrop-blur-2xl flex flex-col justify-center items-center text-center animate-fadeIn">
                <BrainCircuit className="w-12 h-12 text-cyan-500 mb-4 animate-pulse text-glow-cyan" />
                <h3 className="text-white font-bold text-base font-display">Run System Diagnosis Scan</h3>
                <p className="text-slate-400 text-xs mt-2 max-w-md leading-relaxed">
                  Execute standard university credentials evaluation matching **{activeGoal.title}** expectations. The platform will call the private Gemini model securely on your behalf.
                </p>

                <button
                  type="button"
                  onClick={handleDiagnose}
                  disabled={loading}
                  className="cursor-pointer mt-6 font-mono text-xs font-bold text-cyan-400 hover:text-white bg-[#020408] border border-white/10 hover:border-cyan-400 py-3.5 px-6 rounded-2xl transition-all flex items-center space-x-2 shadow-sm"
                >
                  <Play className="w-4 h-4 text-cyan-400 text-glow-cyan" />
                  <span>Execute Diagnostic Sequence</span>
                </button>
              </div>
            )
          ) : (
            <p className="text-xs text-slate-500">Configure or select a goal target in the system metrics.</p>
          )}

        </div>

      </div>

    </div>
  );
}
