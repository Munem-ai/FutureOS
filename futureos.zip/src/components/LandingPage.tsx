/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Cpu, Award, GraduationCap, MapPin, Compass, ShieldAlert, Sparkles, LogIn, ArrowRight } from "lucide-react";

interface LandingPageProps {
  onGetStarted: () => void;
  onLogin: () => void;
}

export default function LandingPage({ onGetStarted, onLogin }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-indigo-500/30 selection:text-indigo-200">
      
      {/* Decorative Blur Gradients */}
      <div className="absolute top-0 left-0 w-full overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-[30%] -left-[10%] w-[50%] h-[60%] rounded-full bg-indigo-900/20 blur-[120px]" />
        <div className="absolute top-[20%] -right-[10%] w-[40%] h-[50%] rounded-full bg-cyan-900/10 blur-[100px]" />
      </div>

      {/* Header */}
      <header className="border-b border-slate-900 bg-slate-950/60 backdrop-blur-md sticky top-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Cpu className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-indigo-200 to-indigo-400 bg-clip-text text-transparent">FutureOS</span>
              <span className="ml-1.5 text-[9px] bg-indigo-950 text-indigo-400 border border-indigo-900/60 px-1.5 py-0.5 rounded-full font-mono uppercase font-semibold">Beta</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              onClick={onLogin} 
              className="text-sm font-medium text-slate-400 hover:text-white transition-colors bg-slate-900/50 hover:bg-slate-900 px-4 py-2 rounded-lg border border-slate-800"
            >
              Log In
            </button>
            <button 
              onClick={onGetStarted} 
              className="text-sm font-medium bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white px-5 py-2 rounded-lg shadow-lg shadow-indigo-650/15 hover:shadow-indigo-650/25 transition-all flex items-center space-x-2"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-grow z-10 relative max-w-7xl mx-auto px-6 py-12 md:py-20 flex flex-col items-center text-center">
        
        {/* Sparkles Notice Badge */}
        <div className="inline-flex items-center space-x-2 bg-indigo-950/40 border border-indigo-900/60 px-3.5 py-1.5 rounded-full mb-8 shadow-sm">
          <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
          <span className="text-xs font-mono font-medium text-indigo-300">Next-Gen Academic & Career Operating System</span>
        </div>

        {/* Big Heading */}
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white max-w-4xl leading-tight">
          Accelerate Your Life, Research & Scholarship Goals with{" "}
          <span className="bg-gradient-to-r from-indigo-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent">
            AI-Engineered Wisdom
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-slate-400 text-lg md:text-xl max-w-2xl mt-6 leading-relaxed">
          The all-in-one personalized SaaS platform for university students. Plan your GPAs, track custom hardware & software skills, map your publications, and unlock elite scholarships.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-4 mt-10">
          <button 
            onClick={onGetStarted} 
            className="w-full sm:w-auto text-base font-semibold bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3.5 rounded-xl shadow-xl shadow-indigo-550/25 transition-all flex items-center justify-center space-x-2"
          >
            <span>Launch Your Dashboard</span>
            <ArrowRight className="w-5 h-5" />
          </button>
          <a 
            href="#features" 
            className="w-full sm:w-auto text-sm font-medium text-slate-400 hover:text-white px-6 py-3.5 rounded-xl bg-slate-900/30 hover:bg-slate-900/60 border border-slate-800/80 transition-all"
          >
            Explore System Modules
          </a>
        </div>

        {/* Immersive Dashboard Mockup Preview Grid */}
        <div id="preview" className="w-full mt-16 rounded-2xl border border-slate-800/80 bg-slate-950/40 p-3 shadow-2xl relative">
          <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/5 to-transparent blur-md -z-10 rounded-2xl" />
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-6 md:p-8 text-left grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div className="border border-slate-800/60 bg-slate-950/60 p-5 rounded-xl">
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-mono text-indigo-400 tracking-wider">AI RECOMMENDATIONS</span>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              </div>
              <h3 className="text-white font-semibold text-base mb-2">MIT Graduate Readiness</h3>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden my-3">
                <div className="bg-gradient-to-r from-indigo-500 to-cyan-500 h-2 rounded-full" style={{ width: "78%" }} />
              </div>
              <p className="text-xs text-slate-400 mt-2">78% Match. Gap identified in 1 hardware skill and peer-reviewed IEEE publications.</p>
            </div>

            <div className="border border-slate-800/60 bg-slate-950/60 p-5 rounded-xl">
              <div className="flex justify-between items-center mb-3">
                <span className="text-xs font-mono text-cyan-400 tracking-wider">SCHOLARSHIP TRACKER</span>
                <span className="text-xs text-emerald-400 font-mono font-bold">Fully Funded</span>
              </div>
              <h3 className="text-white font-semibold text-base">Erasmus Mundus Scheme</h3>
              <p className="text-xs text-slate-400 mt-1.5">Matches current 3.82 CGPA & 7.5 IELTS profiles. SOP requested.</p>
              <div className="mt-4 flex gap-2">
                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">2 Letters Req.</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">IELTS 6.5 Min</span>
              </div>
            </div>

            <div className="border border-slate-800/60 bg-slate-950/60 p-5 rounded-xl">
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-mono text-pink-400 tracking-wider">PRODUCTIVITY METER</span>
                <span className="text-xs text-slate-500">This Week</span>
              </div>
              <h3 className="text-white font-semibold text-base mb-1">Weekly Target Log</h3>
              <p className="text-xs text-slate-400">32 Hours Accumulated: 12h Research, 15h Embedded Coding, 5h Paper Drafts.</p>
              <div className="flex gap-2.5 mt-3">
                <div className="flex-1 h-1.5 bg-indigo-500 rounded-full" />
                <div className="flex-1 h-1.5 bg-cyan-400 rounded-full" />
                <div className="flex-1 h-1.5 bg-pink-500 rounded-full" />
                <div className="flex-1 h-1.5 bg-slate-800 rounded-full" />
              </div>
            </div>

          </div>
        </div>

        {/* Feature Grid Section */}
        <section id="features" className="w-full mt-24 py-12 border-t border-slate-900 text-left">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            
            <div className="p-6 rounded-2xl border border-slate-900 bg-slate-900/20 backdrop-blur-sm">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center mb-4">
                <Compass className="w-5 h-5 text-indigo-400" />
              </div>
              <h4 className="text-white font-semibold text-lg">AI Goal Advising</h4>
              <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                Connect target programs (DAAD, Stanford, Chevening) to analyze specific skill gaps, estimated timeline, requirements, and custom task sprints.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-900 bg-slate-900/20 backdrop-blur-sm">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mb-4">
                <Award className="w-5 h-5 text-cyan-400" />
              </div>
              <h4 className="text-white font-semibold text-lg">Detailed Databases</h4>
              <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                Real-time, interactive catalogs of worldwide top scholarships and elite universities. Tailored filter matches based on your GPAs and tests.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-900 bg-slate-900/20 backdrop-blur-sm">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mb-4">
                <GraduationCap className="w-5 h-5 text-emerald-400" />
              </div>
              <h4 className="text-white font-semibold text-lg">Research Studio</h4>
              <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                Write notes, summarize bibliography insights, and leverage dynamic AI assistants to discover unresolved thesis literature gaps.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-900 bg-slate-900/20 backdrop-blur-sm">
              <div className="w-10 h-10 rounded-xl bg-pink-500/10 border border-pink-500/20 flex items-center justify-center mb-4">
                <Cpu className="w-5 h-5 text-pink-400" />
              </div>
              <h4 className="text-white font-semibold text-lg">Document Builder</h4>
              <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                Instantly generate tailored ATS-friendly Academic CVs, scholarship-ready Personal Statements, or Motivation Letters matching target requirements.
              </p>
            </div>

          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-8 px-6 text-slate-500 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex flex-col space-y-1 text-center md:text-left">
            <span>© 2026 FutureOS Inc. Built securely in Cloud Workspace for scholars worldwide.</span>
            <span className="text-slate-400 text-[11px] font-mono">
              Developed by <span className="text-cyan-400 font-semibold">Munem Shahriar Onim</span>
            </span>
          </div>
          <div className="flex space-x-6">
            <span className="hover:text-slate-300 cursor-pointer">Security Standards</span>
            <span className="hover:text-slate-300 cursor-pointer">Terms of Service</span>
            <span className="hover:text-slate-300 cursor-pointer">Privacy Charter</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
