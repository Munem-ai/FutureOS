/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { UserProfile } from "../types";
import { 
  FileText, Sparkles, Loader2, PlayCircle, CheckCircle, 
  AlertTriangle, ArrowUpRight, Award, Clipboard 
} from "lucide-react";

interface DocumentGenProps {
  profile: UserProfile;
  initialScholarshipName?: string;
}

export default function DocumentGen({ profile, initialScholarshipName = "" }: DocumentGenProps) {
  const [activeTab, setActiveTab] = useState<"sop" | "ats">("sop");
  
  // Document compiler form
  const [docType, setDocType] = useState<any>("sop");
  const [scholarshipName, setScholarshipName] = useState(initialScholarshipName || "Fulbright Foreign Student Program");
  const [additionalDetails, setAdditionalDetails] = useState("");
  const [loadingDoc, setLoadingDoc] = useState(false);
  const [docContent, setDocContent] = useState("");
  const [errorHeader, setErrorHeader] = useState("");

  // ATS resume scanner form
  const [resumeText, setResumeText] = useState(`SUMMARY
EE student focused on Embedded Microcontrollers and FreeRTOS task schedules. 

EDUCATION
B.Sc in Electrical Engineering, CGPA: 3.84, Expected 2027

EXPERIENCE
- Configured microcontroller SPI buses for telemetry capturing.
- Designed high frequency PCB layouts with KiCad boards.`);
  const [atsScore, setAtsScore] = useState<number | null>(null);
  const [scanResults, setScanResults] = useState<any>(null);

  const startAtsAudit = () => {
    if (!resumeText) return;
    
    // Evaluate ATS rules dynamically
    const lowerText = resumeText.toLowerCase();
    
    // Check key heading formats
    const hasEducation = lowerText.includes("education");
    const hasExperience = lowerText.includes("experience") || lowerText.includes("projects");
    const hasSkills = lowerText.includes("skills") || lowerText.includes("competencies");

    // Power words checking
    const powerWords = ["configured", "designed", "engineered", "guided", "implemented", "synthesized", "mitigated", "analyzed", "profiled"];
    const foundPowerWords = powerWords.filter(word => lowerText.includes(word));

    // Calculate score
    let score = 30;
    if (hasEducation) score += 15;
    if (hasExperience) score += 15;
    if (hasSkills) score += 15;
    score += (foundPowerWords.length * 4); // Max 36 points
    if (resumeText.length > 300) score += 5; // density bonus

    score = Math.min(score, 100);

    setAtsScore(score);
    setScanResults({
      hasEducation,
      hasExperience,
      hasSkills,
      powerWordsCount: foundPowerWords.length,
      foundPowerWords,
      length: resumeText.length
    });
  };

  const handleGenerateDoc = async () => {
    setLoadingDoc(true);
    setDocContent("");
    setErrorHeader("");

    try {
      const response = await fetch("/api/ai/document-generator", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profile,
          documentType: docType,
          specificProgram: scholarshipName,
          customInstruction: additionalDetails
        })
      });

      if (!response.ok) {
        throw new Error("Doc generation failed at high-load system corridors.");
      }

      const data = await response.json();
      setDocContent(data.content);
    } catch (err: any) {
      console.error(err);
      setErrorHeader("Operational boundary. Presenting fallback boilerplate statement of purpose.");
      setDocContent(getFallbackDocument(docType, scholarshipName, profile));
    } finally {
      setLoadingDoc(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-900 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-400" />
            <span>Academic Paperwork & ATS Scanners</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Compile SOPs, edit LOR frameworks, and execute instant parsing scans on your CV.</p>
        </div>

        {/* Tab switcher */}
        <div className="flex p-0.5 bg-slate-1000 border border-slate-900 rounded-xl">
          <button
            onClick={() => setActiveTab("sop")}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
              activeTab === "sop" ? "bg-slate-900 text-indigo-400 border border-slate-800" : "text-slate-500 hover:text-slate-350"
            }`}
          >
            AI Document Compiler
          </button>
          <button
            onClick={() => setActiveTab("ats")}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all flex items-center space-x-1.5 ${
              activeTab === "ats" ? "bg-slate-900 text-indigo-400 border border-slate-800" : "text-slate-500 hover:text-slate-350"
            }`}
          >
            <Award className="w-3.5 h-3.5 text-indigo-400" />
            <span>ATS Resume Auditor</span>
          </button>
        </div>
      </div>

      {activeTab === "sop" ? (
        // AI DOCUMENT COMPILER TAB
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Document compiler configuration sidebar */}
          <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 h-fit space-y-4">
            <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-1.5">
              Configure Document Metadata
            </h3>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">DOCUMENT BLUEPRINT</label>
                <select
                  value={docType}
                  onChange={(e) => setDocType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-2.5 py-2 text-xs text-slate-300 focus:outline-none"
                >
                  <option value="sop">Statement of Purpose (SOP)</option>
                  <option value="lor">Letter of Recommendation (Academic LOR)</option>
                  <option value="cv">Academic CV Outline</option>
                  <option value="cover_letter">Sponsor Cover Letter</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">TARGET PROGRAM / SCHOLARSHIP</label>
                <input 
                  type="text" 
                  value={scholarshipName}
                  onChange={(e) => setScholarshipName(e.target.value)}
                  placeholder="e.g. MEXT Research Scholars Japan"
                  className="w-full bg-slate-950 border border-slate-850 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">ADDITIONAL MOTIVATION DETAILS (PROMPTING)</label>
                <textarea 
                  value={additionalDetails}
                  onChange={(e) => setAdditionalDetails(e.target.value)}
                  placeholder="State specific research interests, professors, or laboratory equipment you wish targeted..."
                  className="w-full bg-slate-950 border border-slate-850 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white h-28 resize-none focus:outline-none"
                />
              </div>

              <button
                onClick={handleGenerateDoc}
                disabled={loadingDoc}
                className="w-full bg-indigo-600 hover:bg-indigo-500 py-3 rounded-xl text-white font-mono text-xs font-bold uppercase tracking-wider flex justify-center items-center space-x-1.5 shadow"
              >
                {loadingDoc ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>Compiling Statement...</span>
                  </>
                ) : (
                  <>
                    <PlayCircle className="w-4 h-4 text-indigo-300" />
                    <span>Generate AI Document</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Document visual viewer pane */}
          <div className="lg:col-span-2">
            <div className="p-6 rounded-2xl border border-slate-900 bg-slate-900/10 min-h-[22rem] flex flex-col justify-between relative relative shadow-lg">
              
              <span className="absolute top-4 right-4 text-[9px] bg-slate-950 border border-slate-900 text-slate-550 rounded font-mono p-1">Completed Document</span>
              
              {loadingDoc ? (
                <div className="flex flex-col items-center justify-center py-20 flex-grow space-y-4">
                  <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
                  <span className="text-xs text-slate-500 font-mono">Invoking Gemini model to synthesize customized candidate letter...</span>
                </div>
              ) : docContent ? (
                <div className="flex flex-col justify-between h-full flex-grow space-y-6">
                  <div className="prose prose-xs prose-invert text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap flex-grow mt-3">
                    {errorHeader && <p className="text-amber-550 font-mono text-[10px] mb-2">{errorHeader}</p>}
                    {docContent}
                  </div>
                  <div className="pt-4 border-t border-slate-900 flex justify-end">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(docContent);
                        alert("Document content copied to clipboard standard workspace!");
                      }}
                      className="px-3 py-1.5 bg-slate-900 text-slate-350 border border-slate-800 hover:text-white rounded-lg text-[10px] font-mono flex items-center space-x-1.5"
                    >
                      <Clipboard className="w-3.5 h-3.5" />
                      <span>Copy to Clipboard</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-20 text-center flex-grow">
                  <FileText className="w-10 h-10 text-slate-650 mb-3 animate-pulse" />
                  <h4 className="text-white text-xs font-bold leading-tight uppercase font-mono">AI Canvas</h4>
                  <p className="text-slate-500 text-xs mt-1.5 max-w-sm">
                    Review and configure specifications on the left, then trigger compiler pipeline. Your advisor statements will render directly in this viewport.
                  </p>
                </div>
              )}

            </div>
          </div>

        </div>
      ) : (
        // ATS RESUME AUDITOR TAB
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Markdown input text for Resume code */}
          <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 space-y-3.5">
            <span className="block text-[10px] font-mono text-slate-400 uppercase tracking-widest border-b border-slate-900 pb-1.5">Paste Resume Raw CV Text</span>
            
            <textarea
              value={resumeText}
              onChange={(e) => setResumeText(e.target.value)}
              placeholder="Paste Markdown or plain text from your resume here..."
              className="w-full bg-slate-950 border border-slate-850 rounded-xl p-4 text-xs font-mono text-slate-300 h-96 resize-none focus:outline-none focus:border-indigo-500"
            />

            <button
              onClick={startAtsAudit}
              className="w-full bg-indigo-600 hover:bg-indigo-500 py-3 rounded-xl text-white font-mono text-xs font-bold uppercase tracking-wider flex justify-center items-center space-x-1.5 shadow"
            >
              <Award className="w-4 h-4 text-indigo-300" />
              <span>Analyze Resume for ATS</span>
            </button>
          </div>

          {/* Scan Results Panel */}
          <div className="lg:col-span-2">
            
            {atsScore !== null ? (
              <div className="space-y-6">
                
                {/* Score Indicators card */}
                <div className="p-5 rounded-xl border border-slate-900 bg-slate-900/20 backdrop-blur-sm flex justify-between items-center">
                  <div>
                    <span className="text-[10px] font-mono text-indigo-400 uppercase tracking-widest">Calculated ATS Density Rating</span>
                    <h2 className="text-white text-3xl font-black mt-1 leading-none">{atsScore}% Score</h2>
                    <p className="text-xs text-slate-400 mt-2 max-w-md">Your resume structure was simulated across parser benchmarks under machine reading specifications.</p>
                  </div>

                  <div className="relative flex items-center justify-center">
                    <svg width="84" height="84">
                      <circle cx="42" cy="42" r="35" stroke="#10b981" strokeWidth="6" fill="transparent" strokeDasharray="220" strokeDashoffset={220 - (220 * atsScore) / 100} className="rotate-[-90deg] origin-center" />
                    </svg>
                    <span className="absolute text-sm font-bold text-slate-200">{atsScore}%</span>
                  </div>
                </div>

                {/* Checklist evaluation details */}
                <div className="p-5 rounded-xl border border-slate-900 bg-slate-900/10 space-y-4">
                  <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-1.5">Structured Verification Check</h3>

                  <div className="space-y-3 pt-2 text-xs text-slate-300">
                    <div className="flex items-center justify-between">
                      <span>Header Tag: "EDUCATION" Presence</span>
                      <span className={`px-2 py-0.5 rounded font-mono text-[10px] ${scanResults?.hasEducation ? "text-emerald-400 bg-emerald-950/20 border border-emerald-900" : "text-amber-500 bg-amber-950/20"}`}>
                        {scanResults?.hasEducation ? "Found ✔" : "Missing ✘"}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>Header Tag: "EXPERIENCE" / "PROJECTS" Presence</span>
                      <span className={`px-2 py-0.5 rounded font-mono text-[10px] ${scanResults?.hasExperience ? "text-emerald-400 bg-emerald-950/20 border border-emerald-900" : "text-amber-500 bg-amber-950/20"}`}>
                        {scanResults?.hasExperience ? "Found ✔" : "Missing ✘"}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>Competency Checklist header</span>
                      <span className={`px-2 py-0.5 rounded font-mono text-[10px] ${scanResults?.hasSkills ? "text-emerald-400 bg-emerald-950/20 border border-emerald-900" : "text-amber-500 bg-amber-955/20"}`}>
                        {scanResults?.hasSkills ? "Found ✔" : "Suggested (Add Skills Block)"}
                      </span>
                    </div>

                    <div className="pt-3 border-t border-slate-900 flex justify-between">
                      <span>ATS Power Verbs Detected</span>
                      <span className="font-mono font-bold text-indigo-400">{scanResults?.powerWordsCount} Active Word(s)</span>
                    </div>

                    {scanResults?.foundPowerWords.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1.5">
                        {scanResults.foundPowerWords.map((word: string, index: number) => (
                          <span key={index} className="px-2 py-0.5 bg-slate-950 text-indigo-300 text-[9px] font-mono border border-indigo-950 rounded">
                            {word}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

              </div>
            ) : (
              <div className="p-12 rounded-2xl border border-dashed border-slate-800 text-center text-slate-500 flex flex-col justify-center items-center h-full min-h-[22rem]">
                <FileText className="w-10 h-10 text-slate-650 mb-3" />
                <h3 className="text-slate-300 font-bold text-sm">Awaiting Active CV Text</h3>
                <p className="text-slate-550 text-xs mt-1.5 max-w-sm">Paste your Resume markdown plain on the left panel and click Audit scan to retrieve calculations.</p>
              </div>
            )}

          </div>

        </div>
      )}

    </div>
  );
}

// Fallback boilerplate builders
function getFallbackDocument(type: string, program: string, profile: any): string {
  const name = profile.name || "Academic Candidate";
  const uni = profile.academic?.university || "Elite Technology Institute";
  const gpa = profile.academic?.cgpa || "3.84";

  if (type === "sop") {
    return `### STATEMENT OF PURPOSE FOR ${program.toUpperCase()}
  
To the Distinguished Selection Committee,

I am writing to formally declare my candidature for the ${program}. As a student of Electrical Engineering at ${uni} maintaining a cumulative CGPA of ${gpa}/4.0, my academic objectives align directly with the groundbreaking hardware-software co-design research that your sponsor foundations support.

Throughout my undergraduate journey, I have prioritized rigorous development of embedded firmware and bare-metal STM32 configurations. Specifically, my project work on priority-driven FreeRTOS tasks demonstrates my commitment to pushing technical bounds. Engaging with the advanced coursework in your target graduate department will allow me to transition these methodologies into real-world, high-impact industrial solutions.

I plan to focus my graduate thesis on Edge AI architectures, investigating post-training INT8 quantization to lessen power grid dependency. The competitive fellowships provided under ${program} would afford me the dedicated resources to pursue this research under elite academic mentorship.

Thank you for your time and serious consideration of my candidacy.

Sincerely,
${name}
${uni}`;
  } else if (type === "lor") {
    return `### LETTER OF RECOMMENDATION (ACADEMIC LOR)

To whom it may concern,

It is with great pleasure that I recommend ${name}, a top-tier student in the Electrical Engineering department at ${uni}, for admission to the ${program}. I have known ${name} for over two years as their primary academic advisor and laboratory supervisor.

In my advanced systems classes, ${name} has demonstrated exceptional theoretical clarity and execution speed, maintaining a CGPA of ${gpa}. They engineered several impressive real-time controllers on STM32 microprocessors, showcasing outstanding command of low-level task prioritization and firmware safety.

Beyond their technical capacity, they possess the collaborative drive and research agility required of scholars in prestigious global programs. I strongly recommend ${name} for selection.

Sincerely,
Distinguished Faculty Advisor
Director, Systems Research Lab`;
  } else {
    return `### COMPREHENSIVE ACADEMIC COVER LETTER
  
Subject: Intent to Apply for ${program} fellowship

Dear Director of Admissions,

I am writing to express my eager interest in security-aligned fellowship research streams funded under the prestigious ${program}. Having established a solid academic foundation in Electrical Engineering at ${uni} with a CGPA of ${gpa}, I am ready to specialize in high-frequency hardware verification and signal analysis.

As noted in my enclosed curriculum vitae, my focus borders the integration of real-time scheduler tasks with PCB trace modeling. 

I look forward to discussing how my systems skills align with your program's core laboratories.

Sincerely,
${name}`;
  }
}
