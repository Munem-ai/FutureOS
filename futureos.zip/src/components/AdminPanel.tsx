/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Scholarship, University, UserRole } from "../types";
import { 
  ShieldAlert, Database, Plus, RefreshCcw, 
  Trash2, Terminal, CheckCircle 
} from "lucide-react";

interface AdminPanelProps {
  scholarships: Scholarship[];
  universities: University[];
  onAddScholarship: (newSchol: Scholarship) => void;
  onAddUniversity: (newUni: University) => void;
}

export default function AdminPanel({
  scholarships,
  universities,
  onAddScholarship,
  onAddUniversity
}: AdminPanelProps) {
  
  // Temporary forms for database injectors
  const [schName, setSchName] = useState("");
  const [schCountry, setSchCountry] = useState("Germany");
  const [schGpa, setSchGpa] = useState(3.5);
  const [schIelts, setSchIelts] = useState(6.5);
  const [schFunding, setSchFunding] = useState("Full Tuition + stipend");

  // Telemetry indicators
  const [telemetry, setTelemetry] = useState([
    { path: "GET /api/scholarships", status: 200, latency: "14ms", client: "127.0.0.1" },
    { path: "POST /api/ai/career-advisor", status: 200, latency: "1140ms", client: "127.0.0.1" },
    { path: "POST /api/ai/research-generator", status: 200, latency: "982ms", client: "127.0.0.1" }
  ]);

  const [activeSubTab, setActiveSubTab] = useState<"database" | "logs">("database");

  const sendScholarship = (e: React.FormEvent) => {
    e.preventDefault();
    if (!schName) return;

    const added: Scholarship = {
      id: "sch_" + Date.now(),
      name: schName,
      country: schCountry,
      degreeLevel: "Master's and PhD programs",
      funding: schFunding,
      deadline: "Oct 15, 2026",
      minCgpa: Number(schGpa),
      ieltsRequirement: Number(schIelts),
      researchRequirement: false,
      publicationRequirement: false,
      sopRequired: true,
      recommendationLetters: 2,
      officialWebsite: "#"
    };

    onAddScholarship(added);
    setSchName("");
    setSchFunding("Full Tuition + stipend");

    // Push fake API call trace
    setTelemetry([
      { path: "POST /api/admin/inject-scholarship", status: 201, latency: "8ms", client: "10.0.1.4" },
      ...telemetry
    ]);
  };

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-900 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-indigo-400" />
            <span>SaaS Admin Control Panel</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Manage global scholarship entries, inspect system database rows, and query telemetry traces.</p>
        </div>

        {/* View selections */}
        <div className="flex p-0.5 bg-slate-950 border border-slate-900 rounded-xl">
          <button
            onClick={() => setActiveSubTab("database")}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
              activeSubTab === "database" ? "bg-slate-900 text-indigo-400 border border-slate-800" : "text-slate-500 hover:text-slate-350"
            }`}
          >
            DB Injectors
          </button>
          <button
            onClick={() => setActiveSubTab("logs")}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all flex items-center space-x-1.5 ${
              activeSubTab === "logs" ? "bg-slate-900 text-indigo-400 border border-slate-800" : "text-slate-500 hover:text-slate-350"
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-indigo-400" />
            <span>Service logs</span>
          </button>
        </div>
      </div>

      {activeSubTab === "database" ? (
        // DB INJECTORS VIEW
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Create scholarship data row */}
          <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 h-fit space-y-4">
            <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-1.5">
              Inject Scholarship Row
            </h3>

            <form onSubmit={sendScholarship} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">SCHOLARSHIP TITLE</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. MEXT Postgrad Award"
                  value={schName}
                  onChange={(e) => setSchName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">DESTINATION NATION</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Japan"
                    value={schCountry}
                    onChange={(e) => setSchCountry(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">FUNDING AMOUNT</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Full Stipend"
                    value={schFunding}
                    onChange={(e) => setSchFunding(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">MIN CGPA REQUIRED</label>
                  <input 
                    type="number" step="0.1" min="0" max="4.0"
                    value={schGpa}
                    onChange={(e) => setSchGpa(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400">MIN IELTS REQUIRED</label>
                  <input 
                    type="number" step="0.5" min="0" max="9.0"
                    value={schIelts}
                    onChange={(e) => setSchIelts(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <button 
                type="submit"
                className="w-full bg-indigo-650 hover:bg-indigo-600 border border-indigo-900/60 py-2.5 rounded-xl text-white text-xs font-semibold font-mono uppercase tracking-wider flex justify-center items-center space-x-1.5 shadow"
              >
                <Plus className="w-4 h-4 text-indigo-300" />
                <span>Inject Row</span>
              </button>
            </form>
          </div>

          {/* Quick Database view summary cards */}
          <div className="lg:col-span-2 space-y-4">
            <div className="p-4 rounded-xl border border-slate-900 bg-slate-900/10">
              <span className="block text-[10px] font-mono text-slate-400 uppercase tracking-widest border-b border-slate-900 pb-1.5 mb-3 flex items-center gap-2">
                <Database className="w-4 h-4 text-indigo-400" />
                <span>Active Scholarships Database Row</span>
              </span>

              <div className="space-y-2 max-h-[22rem] overflow-y-auto pr-1">
                {scholarships.map(s => (
                  <div key={s.id} className="p-3 border border-slate-900 bg-slate-950/40 rounded-xl flex items-center justify-between text-xs font-mono">
                    <div>
                      <span className="text-white font-bold block">{s.name}</span>
                      <span className="text-[10px] text-slate-500 block">Location: {s.country} • GPA Minimum: {s.minCgpa}</span>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-400 border border-indigo-900 border-[1px] text-[10px]">
                      {s.id}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick university stats */}
            <div className="p-4 rounded-xl border border-slate-900 bg-slate-900/10">
              <span className="block text-[10px] font-mono text-slate-400 uppercase tracking-widest border-b border-slate-900 pb-1.5 mb-2">Ivy Programs Tracked ({universities.length})</span>
              <div className="flex flex-wrap gap-2 pt-2">
                {universities.map(u => (
                  <span key={u.id} className="px-2.5 py-1 rounded bg-slate-950/60 text-slate-300 text-[10px] border border-slate-900">
                    Rank #{u.ranking} • {u.name}
                  </span>
                ))}
              </div>
            </div>
          </div>

        </div>
      ) : (
        // SERVICE LOGS TELEMETRY VIEW
        <div className="space-y-4">
          <div className="p-5 rounded-2xl border border-slate-900 bg-slate-1000 font-mono text-xs text-slate-300 space-y-3 shadow-lg">
            
            <div className="flex justify-between items-center border-b border-slate-900 pb-3">
              <span className="text-indigo-400 font-bold block flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                <span>Live Container Service Logging Telemetry</span>
              </span>
              <button 
                onClick={() => {
                  setTelemetry([
                    { path: `GET /api/scholarships-db`, status: 200, latency: "21ms", client: "127.0.0.1" },
                    ...telemetry
                  ]);
                }}
                className="text-slate-500 hover:text-white flex items-center space-x-1"
              >
                <RefreshCcw className="w-3.5 h-3.5" />
                <span>Flush Logs</span>
              </button>
            </div>

            <div className="space-y-1.5 pt-2 max-h-[22rem] overflow-y-auto pr-1">
              {telemetry.map((log, idx) => (
                <div key={idx} className="flex justify-between p-2 rounded-lg bg-slate-950/80 border border-slate-900 text-[11px]">
                  <div className="flex space-x-3.5">
                    <span className="text-emerald-500">[200OK]</span>
                    <span className="text-slate-350">{log.path}</span>
                  </div>
                  <div className="space-x-4 text-slate-500">
                    <span>Latency: {log.latency}</span>
                    <span>Src IP: {log.client}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-3 bg-indigo-950/20 border border-indigo-900/40 rounded-xl flex items-center space-x-2 text-[10px] text-slate-400 leading-relaxed max-w-lg">
              <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>Container is running normally. CPU utilization: 4.8%, RAM allocated: 112MB of 512MB available.</span>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
