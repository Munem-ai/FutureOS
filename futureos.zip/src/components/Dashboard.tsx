/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { UserProfile, DreamGoal, Scholarship, University } from "../types";
import { 
  Sparkles, Award, TrendingUp, Calendar, AlertCircle, 
  Map, Compass, ArrowUpRight, GraduationCap, Clock, Download
} from "lucide-react";

interface DashboardProps {
  profile: UserProfile;
  goals: DreamGoal[];
  scholarships: Scholarship[];
  universities: University[];
  onChangeTab: (tab: any) => void;
}

export default function Dashboard({ 
  profile, 
  goals, 
  scholarships, 
  universities,
  onChangeTab 
}: DashboardProps) {
  
  // Custom CV Export Event handler
  const handleExportCV = () => {
    const skillsString = profile.skills.map(s => `- **${s.name}**: ${s.level} Level (${s.progress}% progress)`).join("\n");
    const publicationsString = profile.research?.publications?.map(p => `- *${p.title}*, published in ${p.publishedIn || "Scholarly Proceeding"} (${p.year})`).join("\n") || "No publications logged yet.";
    const projectsString = profile.projects.map(p => `- **${p.title}**: ${p.description}`).join("\n");
    const experiencesString = profile.experiences.map(e => `- **${e.title}** at ${e.organization} (${e.duration}): ${e.description}`).join("\n");

    const cvMarkdown = `# ACADEMIC CURRICULUM VITAE
**Name**: ${profile.name}
**Contact**: ${profile.email || "student@futureos.net"}
**Affiliation**: ${profile.academic?.university || "National Technological Institute"}

---

## ACADEMIC SUMMARY
- **Department**: ${profile.academic?.department || "N/A"}
- **CGPA**: ${profile.academic?.cgpa || "0.0"} / 4.00
- **Expected Graduation**: ${profile.academic?.expectedGraduationYear || "N/A"}

## STANDARDIZED TEST SCORES
- **IELTS**: ${profile.languages?.ielts || "N/A"}
- **TOEFL**: ${profile.languages?.toefl || "N/A"}
- **GRE Score**: ${profile.languages?.gre || "N/A"}
- **GMAT**: ${profile.languages?.gmat || "N/A"}

---

## CORE SKILLS & EXPERTISE
${skillsString}

---

## PUBLICATIONS & ACADEMIC REVIEWS
${publicationsString}

---

## SELECTED SCHOLARLY PROJECTS
${projectsString}

---

## RESEARCH & TECHNICAL EXPERIENCES
${experiencesString}

---
*Exported securely via FutureOS Academic Control Center on ${new Date().toISOString().split("T")[0]}*`;

    const dataStr = "data:text/markdown;charset=utf-8," + encodeURIComponent(cvMarkdown);
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `${profile.name.toLowerCase().replace(/ /g, "_")}_academic_cv.md`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Calculate Readiness scores on the fly based on student credentials
  const calculateScores = () => {
    const gpaVal = profile.academic?.cgpa || 3.0;
    const skillsCount = profile.skills?.length || 2;
    const researchCount = profile.research?.publications?.length || 0;
    const experienceCount = profile.experiences?.length || 0;
    const projectsCount = profile.projects?.length || 1;

    // Career Readiness
    const career = Math.min(Math.round((gpaVal / 4.0) * 35 + (skillsCount * 5) + (experienceCount * 12) + (projectsCount * 8)), 95);
    // Scholarship Readiness
    const scholarship = Math.min(Math.round((gpaVal / 4.0) * 45 + (researchCount * 15) + (profile.languages?.ielts ? (profile.languages.ielts / 9 * 20) : 0)), 97);
    // Research Readiness
    const research = Math.min(Math.round((researchCount * 25) + (profile.research?.experience ? 30 : 10) + (gpaVal * 8)), 95);
    // Skill Readiness
    const skillScore = Math.min(Math.round(profile.skills?.reduce((acc, curr) => {
      const multiplier = curr.level === "Expert" ? 25 : curr.level === "Advanced" ? 20 : curr.level === "Intermediate" ? 15 : 8;
      return acc + multiplier;
    }, 0) || 30), 98);
    // Productivity Score
    const productivity = Math.min(Math.round(30 + (skillsCount * 4) + (projectsCount * 5) + (researchCount * 8)), 99);

    return {
      career: Math.max(career, 45),
      scholarship: Math.max(scholarship, 40),
      research: Math.max(research, 30),
      skill: Math.max(skillScore, 35),
      productivity: Math.max(productivity, 50)
    };
  };

  const scores = calculateScores();

  // Find eligible scholarships based on user gpa and ielts
  const eligibleScholarships = scholarships.filter(s => {
    const userGpa = profile.academic?.cgpa || 0;
    const userIelts = profile.languages?.ielts || 0;
    return userGpa >= s.minCgpa && (userIelts >= s.ieltsRequirement || !s.ieltsRequirement);
  });

  return (
    <div className="space-y-8 p-1 sm:p-3 relative">
      
      {/* Title & Static Context Info */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-5">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-white flex items-center gap-3 font-display">
            <span>Core Control Center</span>
            <span className="text-[10px] uppercase bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2.5 py-0.5 rounded-full font-mono font-bold animate-pulse">Live Session</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1 font-sans">Hello, {profile.name}. Explore career readiness metrics and plan milestones aligned with your goals.</p>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <button
            onClick={handleExportCV}
            className="cursor-pointer bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white border border-transparent text-xs font-mono font-bold px-3.5 py-2.5 rounded-xl transition-all shadow-[0_0_10px_rgba(6,182,212,0.3)] flex items-center justify-center space-x-1.5"
            title="Download formatted academic Curriculum Vitae (CV) portfolio"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CV Portfolio</span>
          </button>
          
          <div className="flex items-center space-x-3 text-xs text-slate-400 font-mono bg-white/4 px-3.5 py-2.5 rounded-xl border border-white/5 shadow-sm justify-center">
            <Clock className="w-4 h-4 text-cyan-400" />
            <span>System Standard UTC Time</span>
          </div>
        </div>
      </div>

      {/* 1. Readiness Scores Bento Grid */}
      <section className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          { title: "Career Index", score: scores.career, color: "from-cyan-500 to-blue-500 shadow-[0_0_15px_rgba(6,182,212,0.4)]" },
          { title: "Scholarship Index", score: scores.scholarship, color: "from-emerald-500 to-cyan-400" },
          { title: "Research Index", score: scores.research, color: "from-indigo-500 to-cyan-500" },
          { title: "Skill Level %", score: scores.skill, color: "from-blue-500 to-cyan-500" },
          { title: "Productivity", score: scores.productivity, color: "from-cyan-500 to-purple-500" }
        ].map((item, idx) => (
          <div key={idx} className="p-5 rounded-3xl border border-white/5 bg-white/4 backdrop-blur-2xl shadow-lg flex flex-col justify-between group relative overflow-hidden transition-all hover:bg-white/8 hover:translate-y-[-2px]">
            <div className="absolute -right-8 -top-8 w-20 h-20 bg-cyan-500/10 blur-xl rounded-full opacity-40 group-hover:opacity-80 transition-opacity" />
            <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">{item.title}</span>
            <div className="my-4 flex items-end justify-between">
              <span className="text-3xl font-extrabold text-white leading-none font-display tracking-tight text-glow-cyan">{item.score}%</span>
              <span className="text-[9px] text-cyan-400 font-mono font-bold">+4.2%</span>
            </div>
            <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
              <div className={`bg-gradient-to-r ${item.color} h-1.5 rounded-full`} style={{ width: `${item.score}%` }} />
            </div>
          </div>
        ))}
      </section>

      {/* 2. Visual Charts Container (GPA Growth and Productivity Shares) */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* GPA Semester Progress (Line Chart Simulator via pristine SVG) */}
        <div className="lg:col-span-2 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl p-6 flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute -right-20 -top-20 w-80 h-80 bg-cyan-500/5 blur-[80px] rounded-full pointer-events-none" />
          <div>
            <div className="flex justify-between items-center">
              <h3 className="text-base font-semibold text-white tracking-tight flex items-center gap-2 font-display">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <span>CGPA Academic Performance</span>
              </h3>
              <span className="text-[10px] text-slate-500 font-mono font-medium">GPA Limit = 4.00</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">Growth progression recorded through high semester averages.</p>
          </div>

          {/* Clean, high contrast Line Chart SVG representing GPA History */}
          <div className="h-56 w-full mt-6 relative flex items-center justify-center">
            <svg viewBox="0 0 500 200" className="w-full h-full overflow-visible">
              <defs>
                <linearGradient id="chart-grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              {/* Grid Lines */}
              <line x1="40" y1="20" x2="480" y2="20" stroke="rgba(255, 255, 255, 0.05)" strokeDasharray="3" />
              <line x1="40" y1="65" x2="480" y2="65" stroke="rgba(255, 255, 255, 0.05)" strokeDasharray="3" />
              <line x1="40" y1="110" x2="480" y2="110" stroke="rgba(255, 255, 255, 0.05)" strokeDasharray="3" />
              <line x1="40" y1="155" x2="480" y2="155" stroke="rgba(255, 255, 255, 0.05)" strokeDasharray="3" />
              
              {/* Axes Labels */}
              <text x="15" y="25" fill="#64748b" className="text-[9px] font-mono font-semibold">4.0</text>
              <text x="15" y="70" fill="#64748b" className="text-[9px] font-mono font-semibold">3.5</text>
              <text x="15" y="115" fill="#64748b" className="text-[9px] font-mono font-semibold">3.0</text>
              <text x="15" y="160" fill="#64748b" className="text-[9px] font-mono font-semibold">2.5</text>

              {/* Chart Line Path based on actual profile history */}
              <path
                d="M 60 110 L 160 92 L 260 56 L 360 45 L 460 30"
                fill="none"
                stroke="#06b6d4"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="drop-shadow-[0_4px_12px_rgba(6,182,212,0.4)]"
              />

              {/* Shaded Area Under Line */}
              <path
                d="M 60 110 L 160 92 L 260 56 L 360 45 L 460 30 L 460 155 L 60 155 Z"
                fill="url(#chart-grad)"
              />

              {/* Line Nodes */}
              <circle cx="60" cy="110" r="5" fill="#2563eb" stroke="#020408" strokeWidth="2" />
              <circle cx="160" cy="92" r="5" fill="#2563eb" stroke="#020408" strokeWidth="2" />
              <circle cx="260" cy="56" r="5" fill="#06b6d4" stroke="#020408" strokeWidth="2" />
              <circle cx="360" cy="45" r="5" fill="#2563eb" stroke="#020408" strokeWidth="2" />
              <circle cx="460" cy="30" r="6" fill="#10b981" stroke="#020408" strokeWidth="2" className="animate-pulse" />

              {/* Column labels */}
              <text x="60" y="180" fill="#64748b" className="text-[9px] font-mono font-bold text-center" textAnchor="middle">Sem 1</text>
              <text x="160" y="180" fill="#64748b" className="text-[9px] font-mono font-bold text-center" textAnchor="middle">Sem 2</text>
              <text x="260" y="180" fill="#64748b" className="text-[9px] font-mono font-bold text-center" textAnchor="middle">Sem 3</text>
              <text x="360" y="180" fill="#64748b" className="text-[9px] font-mono font-bold text-center" textAnchor="middle">Sem 4</text>
              <text x="460" y="180" fill="#64748b" className="text-[9px] font-mono font-bold text-center" textAnchor="middle">Current</text>

              {/* Dynamic current score popover tooltips */}
              <g transform="translate(440, -10)">
                <rect width="40" height="18" rx="6" fill="#020408" stroke="#10b981" strokeWidth="1" />
                <text x="20" y="12" fill="#10b981" className="text-[10px] font-black font-mono" textAnchor="middle">{profile.academic?.cgpa || "3.82"}</text>
              </g>
            </svg>
          </div>
        </div>

        {/* Goal Matching & Readiness Rates (Circle Progress Meter) */}
        <div className="rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl p-6 flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-blue-500/5 blur-[85px] rounded-full pointer-events-none" />
          <div>
            <h3 className="text-base font-semibold text-white tracking-tight flex items-center gap-2 font-display">
              <Award className="w-4 h-4 text-cyan-400" />
              <span>Target Goal Match Rate</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">Calculated fit probability based on academic records.</p>
          </div>

          <div className="relative flex flex-col items-center justify-center my-6">
            <svg width="160" height="160" className="rotate-[-90deg]">
              <circle cx="80" cy="80" r="65" stroke="rgba(255, 255, 255, 0.05)" strokeWidth="11" fill="transparent" />
              <circle
                cx="80"
                cy="80"
                r="65"
                stroke="url(#radial-gradient-cyan)"
                strokeWidth="11"
                fill="transparent"
                strokeDasharray="408.4"
                strokeDashoffset={408.4 - (408.4 * (goals[0]?.probabilityScore || 75)) / 100}
                strokeLinecap="round"
                className="drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]"
              />
              <defs>
                <linearGradient id="radial-gradient-cyan" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#06b6d4" />
                  <stop offset="100%" stopColor="#2563eb" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute text-center">
              <span className="block text-4xl font-black text-white font-display text-glow-cyan">{goals[0]?.probabilityScore || 75}<span className="text-xs text-slate-450">%</span></span>
              <span className="text-[8px] font-mono tracking-widest font-bold bg-[#020408]/60 border border-white/5 text-cyan-400 px-2 py-0.5 rounded-full mt-2.5 inline-block uppercase">PROBABILITY</span>
            </div>
          </div>

          <div className="text-center font-mono text-xs border-t border-white/5 pt-3">
            <p className="text-slate-300">Goal: <span className="text-white font-bold">{goals[0]?.title || "MIT PhD Candidates"}</span></p>
            <span className="text-[10px] text-slate-500 mt-1 block">Readiness Index: {goals[0]?.readinessScore || 78}/100</span>
          </div>
        </div>

      </section>

      {/* 3. Global Databases Stat Summaries (Scholarships & Top Universities) */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Scholarship eligibility dashboard */}
        <div className="p-6 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl">
          <div className="flex justify-between items-center mb-4 pb-2 border-b border-white/5">
            <h4 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2 font-display">
              <GraduationCap className="w-4 h-4 text-cyan-400" />
              <span>Available Matching Scholarships</span>
            </h4>
            <span className="text-[9px] uppercase font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2.5 py-0.5 rounded-xl font-mono animate-pulse">
              {eligibleScholarships.length} Eligible
            </span>
          </div>

          <div className="space-y-3">
            {scholarships.slice(0, 3).map((s) => {
              const eligible = (profile.academic?.cgpa || 0) >= s.minCgpa;
              return (
                <div key={s.id} className="p-3.5 rounded-2xl border border-white/5 bg-white/4 flex items-center justify-between hover:bg-white/8 transition-colors">
                  <div>
                    <span className="block text-xs font-semibold text-white">{s.name}</span>
                    <div className="flex gap-2.5 mt-1 font-mono text-[9px] text-slate-400">
                      <span>Country: {s.country}</span>
                      <span>•</span>
                      <span>Min GPA: {s.minCgpa}</span>
                    </div>
                  </div>
                  <span className={`px-2.5 py-0.5 text-[9px] font-bold rounded-lg font-mono tracking-wide ${
                    eligible ? "text-cyan-400 bg-cyan-950/20 border border-cyan-500/25" : "text-amber-500 bg-amber-950/20 border border-amber-900/40"
                  }`}>
                    {eligible ? "Match Ready" : `Need CGPA ${s.minCgpa}`}
                  </span>
                </div>
              );
            })}
          </div>

          <button 
            onClick={() => onChangeTab("scholarships")}
            className="w-full mt-4 text-center py-2.5 border border-white/5 hover:bg-white/8 rounded-2xl text-xs font-bold font-mono tracking-widest text-cyan-400 uppercase transition-all flex items-center justify-center space-x-1.5 cursor-pointer box-glow-cyan"
          >
            <span>Scan Complete Database</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-cyan-500" />
          </button>
        </div>

        {/* Top University Recommendations */}
        <div className="p-6 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl">
          <div className="flex justify-between items-center mb-4 pb-2 border-b border-white/5">
            <h4 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2 font-display">
              <Compass className="w-4 h-4 text-blue-400" />
              <span>Matching Ivy Programs</span>
            </h4>
            <span className="text-[9px] uppercase font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2.5 py-0.5 rounded-xl font-mono">
              {universities.length} Tracked
            </span>
          </div>

          <div className="space-y-3">
            {universities.slice(0, 3).map((uni) => {
              const userGpa = profile.academic?.cgpa || 0;
              const qualifies = userGpa >= uni.gpaRequirement;
              return (
                <div key={uni.id} className="p-3.5 rounded-2xl border border-white/5 bg-white/4 flex items-center justify-between hover:bg-white/8 transition-colors">
                  <div>
                    <span className="block text-xs font-semibold text-white">{uni.name}</span>
                    <div className="flex gap-2.5 mt-1 font-mono text-[9px] text-slate-400">
                      <span>Rank #{uni.ranking}</span>
                      <span>•</span>
                      <span>Avg GPA: {uni.gpaRequirement}</span>
                    </div>
                  </div>
                  <span className={`px-2.5 py-0.5 text-[9px] font-bold rounded-lg font-mono tracking-wide ${
                    qualifies ? "text-cyan-400 bg-cyan-950/20 border border-cyan-500/25" : "text-pink-500 bg-pink-950/20 border border-pink-900/40"
                  }`}>
                    {qualifies ? "Admissible" : `Target ${uni.gpaRequirement}`}
                  </span>
                </div>
              );
            })}
          </div>

          <button 
            onClick={() => onChangeTab("universities")}
            className="w-full mt-4 text-center py-2.5 border border-white/5 hover:bg-white/8 rounded-2xl text-xs font-bold font-mono tracking-widest text-cyan-400 uppercase transition-all flex items-center justify-center space-x-1.5 cursor-pointer box-glow-cyan"
          >
            <span>Scan Target Academic Labs</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-cyan-500" />
          </button>
        </div>

      </section>

      {/* 4. Active Roadmap targets */}
      <section className="p-6 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl">
        <h3 className="text-sm font-semibold text-white tracking-tight mb-4 flex items-center gap-2 font-display uppercase tracking-widest">
          <Calendar className="w-4 h-4 text-cyan-400 text-glow-cyan" />
          <span>Active Roadmap Milestones for Today</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl bg-white/4 border border-white/5 flex flex-col justify-between hover:bg-white/8 transition-all">
            <div className="flex justify-between text-[8px] font-mono tracking-widest font-bold text-slate-500 uppercase">
              <span>Metric Boost</span>
              <span className="text-cyan-400 font-bold">In Progress</span>
            </div>
            <h5 className="text-slate-200 text-xs font-bold mt-2.5 leading-relaxed">Mock exam sheets IELTS preparation - Read writing templates</h5>
            <span className="text-[10px] text-cyan-400/80 font-mono mt-4 block font-medium">Target Time: 1 hour daily</span>
          </div>

          <div className="p-5 rounded-2xl bg-white/4 border border-white/5 flex flex-col justify-between hover:bg-white/8 transition-all">
            <div className="flex justify-between text-[8px] font-mono tracking-widest font-bold text-slate-500 uppercase">
              <span>Publications</span>
              <span className="text-cyan-400 font-bold">Assigned</span>
            </div>
            <h5 className="text-slate-200 text-xs font-bold mt-2.5 leading-relaxed">Synthesize 5 state-of-the-art literature review notes</h5>
            <span className="text-[10px] text-cyan-400/80 font-mono mt-4 block font-medium">Target Time: Due this Thursday</span>
          </div>

          <div className="p-5 rounded-2xl bg-white/4 border border-white/5 flex flex-col justify-between hover:bg-white/8 transition-all">
            <div className="flex justify-between text-[8px] font-mono tracking-widest font-bold text-slate-500 uppercase">
              <span>Skill acceleration</span>
              <span className="text-emerald-400 font-bold">Complete</span>
            </div>
            <h5 className="text-slate-450 text-xs font-medium mt-2.5 line-through decoration-cyan-500/40 leading-relaxed">Configure STM32 FreeRTOS priority scheduling triggers</h5>
            <span className="text-[10px] text-slate-500 font-mono mt-4 block font-medium">Completed on Monday (Yesterday)</span>
          </div>
        </div>
      </section>

    </div>
  );
}
