/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from "react";
import { UserProfile, ProductivityLog } from "../types";
import { 
  FileBarChart, CheckSquare, Plus, Zap, 
  Layers, Smile, Clock, Target, Calendar 
} from "lucide-react";

interface ProductivityHubProps {
  profile: UserProfile;
}

export default function ProductivityHub({ profile }: ProductivityHubProps) {
  const [logs, setLogs] = useState<ProductivityLog[]>([
    { date: "2026-06-07", studyHours: 6.5, codingHours: 4.5, researchHours: 3.0, readingHours: 1.0, exerciseHours: 1.5, personalDevHours: 2.0 },
    { date: "2026-06-06", studyHours: 5.0, codingHours: 5.0, researchHours: 4.0, readingHours: 0.5, exerciseHours: 1.0, personalDevHours: 1.5 },
    { date: "2026-06-05", studyHours: 8.0, codingHours: 3.5, researchHours: 2.5, readingHours: 1.5, exerciseHours: 1.0, personalDevHours: 2.5 }
  ]);

  // Form states to log a new hours block
  const [study, setStudy] = useState(6.0);
  const [coding, setCoding] = useState(4.0);
  const [research, setResearch] = useState(3.0);
  const [reading, setReading] = useState(1.0);
  const [exercise, setExercise] = useState(1.0);
  const [devHours, setDevHours] = useState(2.0);

  const handleLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newLog: ProductivityLog = {
      date: new Date().toISOString().split("T")[0],
      studyHours: Number(study),
      codingHours: Number(coding),
      researchHours: Number(research),
      readingHours: Number(reading),
      exerciseHours: Number(exercise),
      personalDevHours: Number(devHours)
    };

    // Filter out duplicates for same day if logging again
    const filtered = logs.filter(l => l.date !== newLog.date);
    setLogs([newLog, ...filtered]);
  };

  // Compute total aggregates for charts
  const activeLog = logs[0] || { studyHours: 6, codingHours: 4, researchHours: 3, readingHours: 1, exerciseHours: 1, personalDevHours: 2 };
  const getTotals = () => {
    const activeSum = activeLog.studyHours + activeLog.codingHours + activeLog.researchHours + activeLog.readingHours + activeLog.exerciseHours + activeLog.personalDevHours;
    return {
      activeSum,
      averages: {
        study: Number(((logs.reduce((acc, l) => acc + l.studyHours, 0)) / logs.length).toFixed(1)),
        coding: Number(((logs.reduce((acc, l) => acc + l.codingHours, 0)) / logs.length).toFixed(1)),
        research: Number(((logs.reduce((acc, l) => acc + l.researchHours, 0)) / logs.length).toFixed(1)),
        reading: Number(((logs.reduce((acc, l) => acc + l.readingHours, 0)) / logs.length).toFixed(1)),
        exercise: Number(((logs.reduce((acc, l) => acc + l.exerciseHours, 0)) / logs.length).toFixed(1)),
        dev: Number(((logs.reduce((acc, l) => acc + l.personalDevHours, 0)) / logs.length).toFixed(1))
      }
    };
  };

  const totals = getTotals();

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-900 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <FileBarChart className="w-5 h-5 text-indigo-400" />
            <span>Productivity Metrics & Target Logs</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Grid out your active focus hours daily, logging splits to verify compliance with your dream milestone sprints.</p>
        </div>

        {/* Aggregate sum indicator badge */}
        <div className="p-2 bg-slate-900/40 rounded-xl border border-slate-900 flex items-center space-x-2 text-xs font-mono">
          <Clock className="w-4 h-4 text-emerald-400" />
          <span>Active Average focus: {(totals.averages.coding + totals.averages.research + totals.averages.study).toFixed(1)} hrs/day</span>
        </div>
      </div>

      {/* Main split log panel layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Left Column: Quick logger forms entry */}
        <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 h-fit space-y-4">
          <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-1.5 flex items-center gap-2">
            <Zap className="w-3.5 h-3.5 text-indigo-400" />
            <span>Log Custom Hours Sprinted</span>
          </h3>

          <form onSubmit={handleLogSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">STUDY HRS</label>
                <input 
                  type="number" step="0.5" min="0" max="24"
                  value={study} onChange={(e) => setStudy(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">CODING / PROJECTS</label>
                <input 
                  type="number" step="0.5" min="0" max="24"
                  value={coding} onChange={(e) => setCoding(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">RESEARCH PAPER DRAFTS</label>
                <input 
                  type="number" step="0.5" min="0" max="24"
                  value={research} onChange={(e) => setResearch(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">TECHNICAL READING</label>
                <input 
                  type="number" step="0.5" min="0" max="24"
                  value={reading} onChange={(e) => setReading(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">EXERCISE / WELLNESS</label>
                <input 
                  type="number" step="0.5" min="0" max="24"
                  value={exercise} onChange={(e) => setExercise(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400">PERSONAL DEVELOPMENT</label>
                <input 
                  type="number" step="0.5" min="0" max="24"
                  value={devHours} onChange={(e) => setDevHours(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 py-2.5 rounded-xl text-white font-semibold text-xs font-mono uppercase tracking-wider flex justify-center items-center space-x-1.5 shadow"
            >
              <Plus className="w-4 h-4 text-indigo-300" />
              <span>Log Hours splits</span>
            </button>
          </form>
        </div>

        {/* Right Columns: Focus hours visual metrics distribution (SaaS Horizontal graphs) */}
        <div className="lg:col-span-2 space-y-6">

          {/* Hour splits visual list */}
          <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10 space-y-4">
            <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest border-b border-slate-900 pb-1.5 flex items-center justify-between">
              <span>Focus Distribution Dashboard (Daily splits metrics)</span>
              <span className="text-[10px] text-slate-500 font-mono">Date: {activeLog.date}</span>
            </h3>

            {/* List horizontal meters */}
            <div className="space-y-4 pt-2">
              {[
                { label: "Study & University Homework", value: activeLog.studyHours, color: "bg-indigo-500", avg: totals.averages.study },
                { label: "Software coding & hardware prototypes", value: activeLog.codingHours, color: "bg-cyan-400", avg: totals.averages.coding },
                { label: "Research bibliography drafts", value: activeLog.researchHours, color: "bg-emerald-500", avg: totals.averages.research },
                { label: "Technical reading expansion", value: activeLog.readingHours, color: "bg-pink-500", avg: totals.averages.reading },
                { label: "Wellness exercises and runs", value: activeLog.exerciseHours, color: "bg-amber-500", avg: totals.averages.exercise },
                { label: "Personal credentials drafting", value: activeLog.personalDevHours, color: "bg-indigo-400", avg: totals.averages.dev }
              ].map((item, idx) => {
                const percent = Math.min(Math.round((item.value / 12) * 100), 100);
                return (
                  <div key={idx} className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-300 font-semibold">{item.label}</span>
                      <div className="font-mono text-[10px] text-slate-400 space-x-2">
                        <span>Today: <strong className="text-white">{item.value}h</strong></span>
                        <span className="text-slate-500">|</span>
                        <span>Avg: {item.avg}h</span>
                      </div>
                    </div>
                    
                    <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden flex pl-0.5">
                      <div className={`${item.color} h-2 rounded-full transition-all duration-500`} style={{ width: `${percent}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Historical Logs summary list */}
          <div className="p-5 rounded-2xl border border-slate-900 bg-slate-900/10">
            <span className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-3">Historical Logs History</span>
            
            <div className="space-y-2 max-h-[14rem] overflow-y-auto pr-1">
              {logs.map((log, index) => {
                const totalDailySum = log.studyHours + log.codingHours + log.researchHours + log.readingHours + log.exerciseHours + log.personalDevHours;
                return (
                  <div key={index} className="p-3 border border-slate-900 bg-slate-950/40 rounded-xl flex items-center justify-between text-xs">
                    <div className="flex items-center space-x-3.5">
                      <Calendar className="w-4 h-4 text-slate-500" />
                      <div>
                        <span className="block text-slate-200 font-semibold">{log.date}</span>
                        <div className="font-mono text-[10px] text-slate-500 flex gap-2 mt-1">
                          <span>Study: {log.studyHours}h</span>
                          <span>•</span>
                          <span>Code: {log.codingHours}h</span>
                          <span>•</span>
                          <span>Research: {log.researchHours}h</span>
                        </div>
                      </div>
                    </div>

                    <span className="px-2 py-0.5 rounded bg-indigo-950/30 text-indigo-400 border border-indigo-900/60 font-mono text-[10px] font-bold">
                      {totalDailySum.toFixed(1)} Focus Hrs
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
