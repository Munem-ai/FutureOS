/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  Cpu, LayoutDashboard, User, Award, FolderGit2, BookOpen, 
  GraduationCap, Target, Map, FileBarChart, Settings, 
  ShieldCheck, LogOut, Menu, X, Bell, Compass, Layers
} from "lucide-react";
import { UserRole } from "../types";

export type NavTab = 
  | "dashboard" 
  | "profile" 
  | "academic-studio"
  | "skills" 
  | "projects" 
  | "research" 
  | "scholarships" 
  | "universities" 
  | "dream-goals" 
  | "roadmap" 
  | "reports" 
  | "settings" 
  | "admin";

interface NavigationProps {
  currentTab: NavTab;
  onChangeTab: (tab: NavTab) => void;
  userRole: UserRole;
  userName: string;
  onLogout: () => void;
  notificationCount: number;
  onOpenNotifications: () => void;
}

export default function Navigation({ 
  currentTab, 
  onChangeTab, 
  userRole, 
  userName, 
  onLogout,
  notificationCount,
  onOpenNotifications
}: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false);

  const menuItems = [
    { id: "dashboard" as NavTab, label: "Overview", icon: LayoutDashboard, roles: [UserRole.Student, UserRole.Mentor, UserRole.Admin] },
    { id: "profile" as NavTab, label: "My Credentials", icon: User, roles: [UserRole.Student, UserRole.Mentor, UserRole.Admin] },
    { id: "academic-studio" as NavTab, label: "Academic Studio", icon: Layers, roles: [UserRole.Student, UserRole.Mentor, UserRole.Admin] },
    { id: "skills" as NavTab, label: "Skill Accelerator", icon: Award, roles: [UserRole.Student, UserRole.Mentor, UserRole.Admin] },
    { id: "projects" as NavTab, label: "Project Portfolio", icon: FolderGit2, roles: [UserRole.Student, UserRole.Mentor, UserRole.Admin] },
    { id: "research" as NavTab, label: "Research Studio", icon: BookOpen, roles: [UserRole.Student, UserRole.Mentor, UserRole.Admin] },
    { id: "scholarships" as NavTab, label: "Scholarships", icon: GraduationCap, roles: [UserRole.Student, UserRole.Mentor, UserRole.Admin] },
    { id: "universities" as NavTab, label: "Universities", icon: Compass, roles: [UserRole.Student, UserRole.Mentor, UserRole.Admin] },
    { id: "dream-goals" as NavTab, label: "Dream Goals", icon: Target, roles: [UserRole.Student] },
    { id: "roadmap" as NavTab, label: "AI Roadmap", icon: Map, roles: [UserRole.Student, UserRole.Mentor] },
    { id: "reports" as NavTab, label: "Productivity Logs", icon: FileBarChart, roles: [UserRole.Student, UserRole.Mentor, UserRole.Admin] },
    { id: "settings" as NavTab, label: "System Config", icon: Settings, roles: [UserRole.Student, UserRole.Mentor, UserRole.Admin] },
    { id: "admin" as NavTab, label: "Admin Core", icon: ShieldCheck, roles: [UserRole.Admin] }
  ];

  // Colors based on roles
  const roleColors = {
    [UserRole.Student]: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    [UserRole.Mentor]: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
    [UserRole.Admin]: "bg-pink-500/10 text-pink-400 border-pink-500/20"
  };

  return (
    <>
      {/* Mobile Top Bar */}
      <div className="md:hidden flex items-center justify-between px-5 py-4 border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
            <Cpu className="w-4 h-4 text-white" />
          </div>
          <span className="text-lg font-bold text-white tracking-tight">FutureOS</span>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            onClick={onOpenNotifications}
            className="p-1.5 rounded-lg border border-slate-800 bg-slate-900 text-slate-400 relative"
          >
            <Bell className="w-4 h-4" />
            {notificationCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[9px] font-bold flex items-center justify-center text-white">
                {notificationCount}
              </span>
            )}
          </button>
          <button 
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 border border-slate-800 bg-slate-900 text-slate-300 rounded-lg"
          >
            {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Navigation Drawer Container / Sidebar */}
      <aside className={`
        fixed md:sticky top-0 left-0 h-full w-64 border-r border-white/5 bg-white/5 backdrop-blur-2xl p-5 flex flex-col justify-between z-40 transform transition-transform duration-300 md:translate-x-0
        ${isOpen ? "translate-x-0" : "-translate-x-full md:block"}
      `}>
        
        <div className="space-y-6 flex flex-col h-full overflow-hidden">
          {/* Logo Heading */}
          <div className="flex items-center space-x-3 pb-4 border-b border-white/5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.5)]">
              <Cpu className="w-5 h-5 text-white animate-pulse" />
            </div>
            <div>
              <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400 font-display tracking-tight">FutureOS</span>
              <span className="block text-[8px] text-cyan-400 font-mono tracking-widest mt-0.5 font-bold">ACADEMIC SHELL</span>
            </div>
          </div>

          {/* User Profile Summary */}
          <div className="p-3 bg-white/4 border border-white/8 rounded-2xl flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-white uppercase text-sm shadow-sm">
              {userName.substring(0, 2)}
            </div>
            <div className="overflow-hidden">
              <span className="block text-xs font-semibold text-slate-200 truncate">{userName}</span>
              <div className="flex items-center space-x-1.5 mt-1">
                <span className={`px-1.5 py-0.5 text-[8px] font-mono border rounded uppercase font-semibold ${roleColors[userRole]}`}>
                  {userRole}
                </span>
                {userRole === UserRole.Student && (
                  <span className="text-[9px] text-slate-500 font-mono font-medium">Core Host</span>
                )}
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 space-y-1 overflow-y-auto pr-1 scrollbar-thin">
            {menuItems.map((item) => {
              if (!item.roles.includes(userRole)) return null;
              const IconComp = item.icon;
              const isActive = currentTab === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onChangeTab(item.id);
                    setIsOpen(false);
                  }}
                  id={`nav-item-${item.id}`}
                  className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-xl text-xs font-mono font-medium transition-all ${
                    isActive
                      ? "bg-white/10 border border-white/10 text-white shadow-[0_0_15px_rgba(255,255,255,0.05)]"
                      : "text-slate-400 hover:text-white border border-transparent hover:bg-white/4 hover:border-white/4"
                  }`}
                >
                  <IconComp className={`w-4 h-4 flex-shrink-0 ${isActive ? "text-cyan-400 text-glow-cyan" : "text-slate-500"}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* AI Mentor Sticky Card (Immersive UI element) */}
          <div className="pt-2">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-500/10 to-cyan-500/10 border border-indigo-500/20 box-glow-cyan">
              <p className="text-[10px] text-cyan-400 uppercase tracking-widest font-bold mb-1.5">AI Mentor Live</p>
              <p className="text-[11px] text-slate-350 italic leading-relaxed">
                "Your engineering profile aligns 92% with Stanford graduate criteria."
              </p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-white/5 space-y-2">
          {/* Notifications Button */}
          <button 
            onClick={onOpenNotifications}
            className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-white/4 rounded-xl text-slate-400 hover:text-white text-xs font-mono transition-colors"
          >
            <div className="flex items-center space-x-3">
              <Bell className="w-4 h-4 text-slate-500" />
              <span>Notifications</span>
            </div>
            {notificationCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-cyan-600/20 text-cyan-400 border border-cyan-500/30 text-[9px] font-bold">
                {notificationCount}
              </span>
            )}
          </button>

          {/* Logout Action */}
          <button 
            onClick={onLogout}
            className="w-full flex items-center space-x-3 px-3.5 py-2 rounded-xl text-slate-450 hover:text-rose-400 hover:bg-rose-950/10 text-xs font-mono transition-all"
          >
            <LogOut className="w-4 h-4 text-slate-500 hover:text-rose-400" />
            <span>Terminate Session</span>
          </button>

          {/* Developer Credit */}
          <div className="pt-2.5 border-t border-white/5 text-center">
            <span className="block text-[9px] text-slate-500 font-mono tracking-wider uppercase font-semibold">System Artifact</span>
            <span className="text-[10px] text-slate-400 font-mono">
              Dev: <span className="text-cyan-400 font-semibold hover:text-white transition-colors">Munem Shahriar Onim</span>
            </span>
          </div>
        </div>

      </aside>

      {/* Backdrop for Mobile Menu */}
      {isOpen && (
        <div 
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-35 md:hidden"
        />
      )}
    </>
  );
}
