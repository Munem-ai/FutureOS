/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect, useRef } from "react";
import { UserProfile } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { 
  GraduationCap, 
  Calendar, 
  Plus, 
  Trash2, 
  Upload, 
  Download, 
  FileText, 
  ChevronDown, 
  ChevronUp, 
  CheckCircle2, 
  BookOpen, 
  Activity, 
  Info, 
  AlertCircle,
  Percent,
  CheckCircle,
  Pencil,
  Save,
  X,
  File,
  Sparkles,
  Book,
  ClipboardList,
  Loader2
} from "lucide-react";

interface UploadDropZoneProps {
  courseId: string;
  category: "notes" | "book" | "report" | "manual";
  placeholderText: string;
  isDragging: { courseId: string; category: string } | null;
  onDragOver: (e: React.DragEvent, courseId: string, category: string) => void;
  onDragLeave: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, courseId: string, category: "notes" | "book" | "report" | "manual") => void;
  onManualFileChange: (e: React.ChangeEvent<HTMLInputElement>, courseId: string, category: "notes" | "book" | "report" | "manual") => void;
}

function UploadDropZone({
  courseId,
  category,
  placeholderText,
  isDragging,
  onDragOver,
  onDragLeave,
  onDrop,
  onManualFileChange
}: UploadDropZoneProps) {
  const isThisDragging = isDragging?.courseId === courseId && isDragging?.category === category;
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div
      onDragOver={(e) => onDragOver(e, courseId, category)}
      onDragLeave={onDragLeave}
      onDrop={(e) => onDrop(e, courseId, category)}
      onClick={() => fileRef.current?.click()}
      className={`p-4 text-center rounded-2xl border border-dashed text-[11px] cursor-pointer transition-all flex flex-col items-center justify-center space-y-1.5 group relative ${
        isThisDragging
          ? "border-cyan-500/50 bg-cyan-950/10"
          : "border-white/10 bg-[#020408]/30 hover:bg-[#020408]/50 hover:border-white/15"
      }`}
    >
      <input
        type="file"
        multiple
        ref={fileRef}
        onChange={(e) => onManualFileChange(e, courseId, category)}
        className="hidden"
      />

      <div className="p-2 rounded-xl bg-white/4 group-hover:bg-cyan-500/10 transition-colors">
        <Upload className="w-4 h-4 text-slate-450 group-hover:text-cyan-400 transition-colors" />
      </div>
      <div>
        <span className="block text-slate-300 font-semibold uppercase text-[10px]">Upload {placeholderText}</span>
        <span className="block text-[8px] text-slate-500 font-mono">Drag here or click</span>
      </div>
    </div>
  );
}

interface AcademicStudioProps {
  profile: UserProfile;
  onUpdateCgpa?: (newCgpa: number) => void;
}

interface NoteFile {
  id: string;
  name: string;
  size: string;
  uploadedAt: string;
  type: string;
  category: "notes" | "book" | "report" | "manual";
}

interface Assessment {
  id: string;
  name: string;
  weight: number; // e.g. 30 for 30%
  score: number; // e.g. 85 marks
  total: number; // e.g. 100 marks
}

interface Course {
  id: string;
  name: string;
  code: string;
  type: "theory" | "lab";
  credits: number;
  assessments: Assessment[];
  files: NoteFile[];
}

interface SemesterData {
  id: string;
  name: string; // e.g. "1-1", "1-2", "2-1"
  courses: Course[];
}

export default function AcademicStudio({ profile, onUpdateCgpa }: AcademicStudioProps) {
  // Try loading from localStorage first, fallback to structured pre-populations
  const [semesters, setSemesters] = useState<SemesterData[]>(() => {
    const saved = localStorage.getItem("futureos_semesters");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {
        console.error("Failed to parse saved semesters, loading default", e);
      }
    }

    // Default pre-populated list using standard "1-1", "1-2" Bangladeshi/Global semesters
    return [
      {
        id: "sem_1_1",
        name: "1-1",
        courses: [
          {
            id: "c_111",
            name: "Structured Programming Language",
            code: "CSE-1101",
            type: "theory",
            credits: 3.0,
            assessments: [
              { id: "a_111_1", name: "Theory Quiz 1", weight: 20, score: 18, total: 20 },
              { id: "a_111_2", name: "Midterm Exam", weight: 30, score: 27, total: 30 },
              { id: "a_111_3", name: "Semester Final", weight: 50, score: 45, total: 50 }
            ],
            files: [
              { id: "f_111_1", name: "c_programming_ansi_standard.pdf", size: "3.2 MB", uploadedAt: "2024-02-15", type: "application/pdf", category: "book" },
              { id: "f_111_2", name: "pointers_and_memory_allocations.txt", size: "18 KB", uploadedAt: "2024-03-01", type: "text/plain", category: "notes" }
            ]
          },
          {
            id: "c_112",
            name: "Structured Programming Lab",
            code: "CSE-1102",
            type: "lab",
            credits: 1.5,
            assessments: [
              { id: "a_112_1", name: "Online Lab Exam 1", weight: 50, score: 48, total: 50 },
              { id: "a_112_2", name: "Lab Report Submissions", weight: 50, score: 47, total: 50 }
            ],
            files: [
              { id: "f_112_1", name: "final_project_pointer_allocator.cpp", size: "12 KB", uploadedAt: "2024-04-20", type: "text/plain", category: "report" },
              { id: "f_112_2", name: "lab_manual_pointer_structures.pdf", size: "1.4 MB", uploadedAt: "2024-02-18", type: "application/pdf", category: "manual" }
            ]
          }
        ]
      },
      {
        id: "sem_1_2",
        name: "1-2",
        courses: [
          {
            id: "c_121",
            name: "Object Oriented Programming",
            code: "CSE-1201",
            type: "theory",
            credits: 3.0,
            assessments: [
              { id: "a_121_1", name: "OOP Principles Test", weight: 30, score: 25, total: 30 },
              { id: "a_121_2", name: "Final Examination", weight: 70, score: 62, total: 70 }
            ],
            files: [
              { id: "f_121_1", name: "java_complete_reference.pdf", size: "8.5 MB", uploadedAt: "2024-08-10", type: "application/pdf", category: "book" }
            ]
          },
          {
            id: "c_122",
            name: "Object Oriented Programming Lab",
            code: "CSE-1202",
            type: "lab",
            credits: 1.5,
            assessments: [
              { id: "a_122_1", name: "Design Patterns Project", weight: 60, score: 55, total: 60 },
              { id: "a_122_2", name: "Interactive GUI Lab Report", weight: 40, score: 38, total: 40 }
            ],
            files: [
              { id: "f_122_1", name: "singleton_and_factory_demos.zip", size: "2.1 MB", uploadedAt: "2024-09-30", type: "application/zip", category: "report" }
            ]
          }
        ]
      },
      {
        id: "sem_3_1",
        name: "3-1 (Current)",
        courses: [
          {
            id: "c_311",
            name: "Embedded Systems & RISC Architecture",
            code: "CSE-3101",
            type: "theory",
            credits: 3.0,
            assessments: [
              { id: "a_311_1", name: "Midterm Evaluation", weight: 30, score: 26, total: 30 },
              { id: "a_311_2", name: "Instruction Pipestage Quiz", weight: 20, score: 18, total: 20 }
            ],
            files: [
              { id: "f_311_1", name: "riscv_instruction_set_spec.pdf", size: "1.8 MB", uploadedAt: "2026-05-12", type: "application/pdf", category: "notes" },
              { id: "f_311_2", name: "patterson_computer_org_design.pdf", size: "11.2 MB", uploadedAt: "2026-05-15", type: "application/pdf", category: "book" }
            ]
          },
          {
            id: "c_312",
            name: "Embedded Systems Laboratory",
            code: "CSE-3102",
            type: "lab",
            credits: 1.5,
            assessments: [
              { id: "a_312_1", name: "KiCad Probe Practicum", weight: 40, score: 38, total: 40 },
              { id: "a_312_2", name: "Assembler Link Report", weight: 30, score: 28, total: 30 }
            ],
            files: [
              { id: "f_312_1", name: "riscv_pipelining_simulation_report.docx", size: "850 KB", uploadedAt: "2026-06-02", type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", category: "report" },
              { id: "f_312_2", name: "lab_manual_esp32_interface.pdf", size: "4.1 MB", uploadedAt: "2026-05-10", type: "application/pdf", category: "manual" }
            ]
          }
        ]
      }
    ];
  });

  const [activeSemId, setActiveSemId] = useState<string>("sem_3_1");
  const [isChangingSemester, setIsChangingSemester] = useState<boolean>(false);
  const [expandedCourseId, setExpandedCourseId] = useState<string | null>("c_311");

  // Save changes to localStorage on any state modification
  useEffect(() => {
    localStorage.setItem("futureos_semesters", JSON.stringify(semesters));
  }, [semesters]);

  const activeSemester = semesters.find(s => s.id === activeSemId) || semesters[0] || null;

  // New Course additions inputs
  const [courseNameInput, setCourseNameInput] = useState("");
  const [courseCodeInput, setCourseCodeInput] = useState("");
  const [courseTypeInput, setCourseTypeInput] = useState<"theory" | "lab">("theory");
  const [courseCreditsInput, setCourseCreditsInput] = useState<number>(3.0);
  const [showAddCourse, setShowAddCourse] = useState(false);

  // New Semester additions inputs
  const [newSemNameInput, setNewSemNameInput] = useState("1-1");
  const [showAddSem, setShowAddSem] = useState(false);

  // New Assessment inputs
  const [assessNameInput, setAssessNameInput] = useState("");
  const [assessWeightInput, setAssessWeightInput] = useState<number>(20);
  const [assessScoreInput, setAssessScoreInput] = useState<number>(17);
  const [assessTotalInput, setAssessTotalInput] = useState<number>(20);

  // DRAG & DROP & Upload Tracking
  const [isDragging, setIsDragging] = useState<{ courseId: string; category: string } | null>(null);

  // EDIT ENGINE STATES
  // 1. Semester Editing
  const [editingSemId, setEditingSemId] = useState<string | null>(null);
  const [editingSemName, setEditingSemName] = useState("");

  // 2. Course Editing
  const [editingCourseId, setEditingCourseId] = useState<string | null>(null);
  const [editingCourseName, setEditingCourseName] = useState("");
  const [editingCourseCode, setEditingCourseCode] = useState("");
  const [editingCourseCredits, setEditingCourseCredits] = useState<number>(3.0);
  const [editingCourseType, setEditingCourseType] = useState<"theory" | "lab">("theory");

  // 3. Assessment Editing
  const [editingAssessId, setEditingAssessId] = useState<string | null>(null);
  const [editingAssessCourseId, setEditingAssessCourseId] = useState<string | null>(null);
  const [editingAssessName, setEditingAssessName] = useState("");
  const [editingAssessWeight, setEditingAssessWeight] = useState<number>(20);
  const [editingAssessScore, setEditingAssessScore] = useState<number>(80);
  const [editingAssessTotal, setEditingAssessTotal] = useState<number>(100);

  // 4. File Renaming
  const [editingFileId, setEditingFileId] = useState<string | null>(null);
  const [editingFileCourseId, setEditingFileCourseId] = useState<string | null>(null);
  const [editingFileName, setEditingFileName] = useState("");

  // 5. Uploading simulation states for animations
  const [uploadingFiles, setUploadingFiles] = useState<{
    id: string;
    courseId: string;
    category: "notes" | "book" | "report" | "manual";
    name: string;
    size: string;
    progress: number;
  }[]>([]);

  // Helper formula of weighted course calculation
  const getCourseProgressDetails = (course: Course) => {
    if (course.assessments.length === 0) {
      return { scoreSoFar: 0, totalWeightInterpreted: 0, projectedPercentage: 0, calculatedGrade: "N/A", gpa: 4.0 };
    }

    let totalWeightInterpreted = 0;
    let totalScoreObtainedNormalized = 0;

    course.assessments.forEach(a => {
      const percentageScore = a.total > 0 ? (a.score / a.total) * 100 : 0;
      const contribution = (percentageScore * a.weight) / 100;
      
      totalScoreObtainedNormalized += contribution;
      totalWeightInterpreted += a.weight;
    });

    // If total weight represents < 100%, project the percentage based on graded components
    const projectedPercentage = totalWeightInterpreted > 0 
      ? (totalScoreObtainedNormalized / totalWeightInterpreted) * 100 
      : 0;

    let calculatedGrade = "A+";
    let gpa = 4.0;

    if (projectedPercentage >= 80) { calculatedGrade = "A+"; gpa = 4.0; }
    else if (projectedPercentage >= 75) { calculatedGrade = "A"; gpa = 3.75; }
    else if (projectedPercentage >= 70) { calculatedGrade = "A-"; gpa = 3.5; }
    else if (projectedPercentage >= 65) { calculatedGrade = "B+"; gpa = 3.25; }
    else if (projectedPercentage >= 60) { calculatedGrade = "B"; gpa = 3.0; }
    else if (projectedPercentage >= 55) { calculatedGrade = "B-"; gpa = 2.75; }
    else if (projectedPercentage >= 50) { calculatedGrade = "C+"; gpa = 2.5; }
    else if (projectedPercentage >= 45) { calculatedGrade = "C"; gpa = 2.25; }
    else if (projectedPercentage >= 40) { calculatedGrade = "D"; gpa = 2.00; }
    else { calculatedGrade = "F"; gpa = 0.0; }

    return {
      scoreSoFar: Math.round(totalScoreObtainedNormalized * 100) / 100,
      totalWeightInterpreted,
      projectedPercentage: Math.round(projectedPercentage * 10) / 10,
      calculatedGrade,
      gpa
    };
  };

  // Compute Active Semester GPA on-the-fly
  const calculateSemesterGpa = (semester: SemesterData) => {
    if (!semester || semester.courses.length === 0) return 3.75;
    
    let totalCredits = 0;
    let weightedGpaSum = 0;

    semester.courses.forEach(c => {
      const stats = getCourseProgressDetails(c);
      if (stats.totalWeightInterpreted > 0) {
        weightedGpaSum += stats.gpa * c.credits;
        totalCredits += c.credits;
      }
    });

    return totalCredits > 0 
      ? Math.round((weightedGpaSum / totalCredits) * 100) / 100 
      : 3.75;
  };

  // Compute Overall Cumulative CGPA across all loaded semesters in state
  const calculateOverallCgpa = () => {
    let totalCredits = 0;
    let weightedGpaSum = 0;

    semesters.forEach(sem => {
      sem.courses.forEach(c => {
        const stats = getCourseProgressDetails(c);
        if (stats.totalWeightInterpreted > 0) {
          weightedGpaSum += stats.gpa * c.credits;
          totalCredits += c.credits;
        }
      });
    });

    return totalCredits > 0 
      ? Math.round((weightedGpaSum / totalCredits) * 100) / 100 
      : profile.academic?.cgpa || 3.75;
  };

  const currentOverallCgpa = calculateOverallCgpa();
  
  // Sync CGPA back to outer profile
  useEffect(() => {
    if (onUpdateCgpa) {
      onUpdateCgpa(currentOverallCgpa);
    }
  }, [currentOverallCgpa, onUpdateCgpa]);

  // Semester Management
  const handleAddSemester = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSemNameInput.trim()) return;

    // Check if it already exists
    if (semesters.some(s => s.name.toLowerCase() === newSemNameInput.trim().toLowerCase())) {
      alert(`Semester ${newSemNameInput} already exists.`);
      return;
    }

    const newSem: SemesterData = {
      id: "sem_" + Date.now(),
      name: newSemNameInput.trim(),
      courses: []
    };

    setSemesters([...semesters, newSem]);
    setActiveSemId(newSem.id);
    setShowAddSem(false);
  };

  const handleStartRenameSem = (sem: SemesterData) => {
    setEditingSemId(sem.id);
    setEditingSemName(sem.name);
  };

  const handleSaveRenameSem = () => {
    if (!editingSemName.trim() || !editingSemId) return;

    setSemesters(semesters.map(s => {
      if (s.id === editingSemId) {
        return { ...s, name: editingSemName.trim() };
      }
      return s;
    }));

    setEditingSemId(null);
  };

  const handleRemoveSemester = (semId: string) => {
    if (semesters.length <= 1) {
      alert("At least one semester terminal is required to compile your scholar tracker.");
      return;
    }
    if (confirm("Are you sure you want to completely delete this semester and all enrolled courses/records?")) {
      const nextSemesters = semesters.filter(s => s.id !== semId);
      setSemesters(nextSemesters);
      if (activeSemId === semId) {
        setActiveSemId(nextSemesters[0].id);
      }
    }
  };

  // Course Management
  const handleAddCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseNameInput.trim()) return;

    const newCourse: Course = {
      id: "course_" + Date.now(),
      name: courseNameInput.trim(),
      code: courseCodeInput.trim() || `CSE-${Math.floor(Math.random() * 300 + 3100)}`,
      type: courseTypeInput,
      credits: Number(courseCreditsInput) || 3.0,
      assessments: [],
      files: []
    };

    setSemesters(semesters.map(sem => {
      if (sem.id === activeSemId) {
        return {
          ...sem,
          courses: [...sem.courses, newCourse]
        };
      }
      return sem;
    }));

    setCourseNameInput("");
    setCourseCodeInput("");
    setCourseCreditsInput(3.0);
    setShowAddCourse(false);
    setExpandedCourseId(newCourse.id);
  };

  const handleStartEditCourse = (course: Course) => {
    setEditingCourseId(course.id);
    setEditingCourseName(course.name);
    setEditingCourseCode(course.code);
    setEditingCourseCredits(course.credits);
    setEditingCourseType(course.type);
  };

  const handleSaveEditCourse = () => {
    if (!editingCourseName.trim() || !editingCourseId) return;

    setSemesters(semesters.map(sem => {
      return {
        ...sem,
        courses: sem.courses.map(c => {
          if (c.id === editingCourseId) {
            // If the course type changes, dynamically adapt existing files' categories if needed
            const updatedFiles = c.files.map(f => {
              if (editingCourseType === "theory" && (f.category === "report" || f.category === "manual")) {
                return { ...f, category: "notes" as const };
              }
              if (editingCourseType === "lab" && (f.category === "notes" || f.category === "book")) {
                return { ...f, category: "report" as const };
              }
              return f;
            });

            return {
              ...c,
              name: editingCourseName.trim(),
              code: editingCourseCode.trim(),
              credits: Number(editingCourseCredits) || 3.0,
              type: editingCourseType,
              files: updatedFiles
            };
          }
          return c;
        })
      };
    }));

    setEditingCourseId(null);
  };

  const handleRemoveCourse = (courseId: string) => {
    if (confirm("Permanently archive and delete this course syllabus?")) {
      setSemesters(semesters.map(sem => {
        if (sem.id === activeSemId) {
          return {
            ...sem,
            courses: sem.courses.filter(c => c.id !== courseId)
          };
        }
        return sem;
      }));
      if (expandedCourseId === courseId) {
        setExpandedCourseId(null);
      }
    }
  };

  // Assessment Operations
  const handleAddAssessment = (courseId: string) => {
    if (!assessNameInput.trim() || assessWeightInput <= 0 || assessTotalInput <= 0) return;

    const newAssess: Assessment = {
      id: "assess_" + Date.now(),
      name: assessNameInput.trim(),
      weight: Number(assessWeightInput) || 10,
      score: Number(assessScoreInput) || 0,
      total: Number(assessTotalInput) || 100
    };

    setSemesters(semesters.map(sem => {
      return {
        ...sem,
        courses: sem.courses.map(c => {
          if (c.id === courseId) {
            return {
              ...c,
              assessments: [...c.assessments, newAssess]
            };
          }
          return c;
        })
      };
    }));

    setAssessNameInput("");
    setAssessWeightInput(20);
    setAssessScoreInput(17);
    setAssessTotalInput(20);
  };

  const handleStartEditAssess = (courseId: string, assess: Assessment) => {
    setEditingAssessCourseId(courseId);
    setEditingAssessId(assess.id);
    setEditingAssessName(assess.name);
    setEditingAssessWeight(assess.weight);
    setEditingAssessScore(assess.score);
    setEditingAssessTotal(assess.total);
  };

  const handleSaveEditAssess = () => {
    if (!editingAssessId || !editingAssessCourseId || !editingAssessName.trim()) return;

    setSemesters(semesters.map(sem => {
      return {
        ...sem,
        courses: sem.courses.map(c => {
          if (c.id === editingAssessCourseId) {
            return {
              ...c,
              assessments: c.assessments.map(a => {
                if (a.id === editingAssessId) {
                  return {
                    ...a,
                    name: editingAssessName.trim(),
                    weight: Number(editingAssessWeight) || 0,
                    score: Number(editingAssessScore) || 0,
                    total: Number(editingAssessTotal) || 100
                  };
                }
                return a;
              })
            };
          }
          return c;
        })
      };
    }));

    setEditingAssessId(null);
    setEditingAssessCourseId(null);
  };

  const handleRemoveAssessment = (courseId: string, assessId: string) => {
    setSemesters(semesters.map(sem => {
      return {
        ...sem,
        courses: sem.courses.map(c => {
          if (c.id === courseId) {
            return {
              ...c,
              assessments: c.assessments.filter(a => a.id !== assessId)
            };
          }
          return c;
        })
      };
    }));
  };

  // Upload/Drop File Processing
  const processUploadedFiles = (courseId: string, fileList: FileList, category: "notes" | "book" | "report" | "manual") => {
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      const sizeFormatted = file.size > 1024 * 1024
        ? `${(file.size / (1024 * 1024)).toFixed(1)} MB`
        : `${Math.round(file.size / 1024)} KB`;

      const uploadId = "upload_" + Date.now() + "_" + i + "_" + Math.floor(Math.random() * 1000);

      // Add to uploading queue
      setUploadingFiles(prev => [...prev, {
        id: uploadId,
        courseId,
        category,
        name: file.name,
        size: sizeFormatted,
        progress: 10
      }]);

      let currentProgress = 10;
      const interval = setInterval(() => {
        currentProgress += Math.floor(Math.random() * 15) + 12;

        if (currentProgress >= 100) {
          currentProgress = 100;
          clearInterval(interval);

          const finalFile: NoteFile = {
            id: "file_" + Date.now() + "_" + i + "_" + Math.floor(Math.random() * 1000),
            name: file.name,
            size: sizeFormatted,
            uploadedAt: new Date().toISOString().split("T")[0],
            type: file.type || "text/plain",
            category
          };

          // Append to permanent semesters DB
          setSemesters(current => current.map(sem => {
            return {
              ...sem,
              courses: sem.courses.map(c => {
                if (c.id === courseId) {
                  return {
                    ...c,
                    files: [...c.files, finalFile]
                  };
                }
                return c;
              })
            };
          }));

          // Remove from uploading simulation queue
          setUploadingFiles(prev => prev.filter(uf => uf.id !== uploadId));
        } else {
          // Increment progress bar
          setUploadingFiles(prev => prev.map(uf => {
            if (uf.id === uploadId) {
              return { ...uf, progress: currentProgress };
            }
            return uf;
          }));
        }
      }, 150);
    }
  };

  const handleDragOver = (e: React.DragEvent, courseId: string, category: string) => {
    e.preventDefault();
    setIsDragging({ courseId, category });
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(null);
  };

  const handleDrop = (e: React.DragEvent, courseId: string, category: "notes" | "book" | "report" | "manual") => {
    e.preventDefault();
    setIsDragging(null);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processUploadedFiles(courseId, e.dataTransfer.files, category);
    }
  };

  const handleManualFileChange = (e: React.ChangeEvent<HTMLInputElement>, courseId: string, category: "notes" | "book" | "report" | "manual") => {
    if (e.target.files && e.target.files.length > 0) {
      processUploadedFiles(courseId, e.target.files, category);
    }
  };

  const handleMockDownloadFile = (noteFile: NoteFile) => {
    const mockContent = `FutureOS Secure Academic Storage Vault\n\nFile Name: ${noteFile.name}\nCategory: ${noteFile.category.toUpperCase()}\nSize: ${noteFile.size}\nUploaded Date: ${noteFile.uploadedAt}\nFile MimeType: ${noteFile.type}\nStatus: VERIFIED SAFE ENCRYPTED REPOSITORY\n\n[ This is a simulated retrieval for scholar profile. ]`;
    const dataStr = "data:text/plain;charset=utf-8," + encodeURIComponent(mockContent);
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", noteFile.name);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleRemoveFile = (courseId: string, fileId: string) => {
    setSemesters(semesters.map(sem => {
      return {
        ...sem,
        courses: sem.courses.map(c => {
          if (c.id === courseId) {
            return {
              ...c,
              files: c.files.filter(f => f.id !== fileId)
            };
          }
          return c;
        })
      };
    }));
  };

  // Live file rename methods
  const handleStartRenameFile = (courseId: string, file: NoteFile) => {
    setEditingFileCourseId(courseId);
    setEditingFileId(file.id);
    setEditingFileName(file.name);
  };

  const handleSaveRenameFile = () => {
    if (!editingFileId || !editingFileCourseId || !editingFileName.trim()) return;

    setSemesters(semesters.map(sem => {
      return {
        ...sem,
        courses: sem.courses.map(c => {
          if (c.id === editingFileCourseId) {
            return {
              ...c,
              files: c.files.map(f => {
                if (f.id === editingFileId) {
                  return { ...f, name: editingFileName.trim() };
                }
                return f;
              })
            };
          }
          return c;
        })
      };
    }));

    setEditingFileId(null);
    setEditingFileCourseId(null);
  };

  const theoryCourses = activeSemester?.courses.filter(c => c.type === "theory") || [];
  const labCourses = activeSemester?.courses.filter(c => c.type === "lab") || [];

  return (
    <div className="space-y-6" id="academic_studio_container">
      
      {/* Dynamic Header Metrics Dashboard */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-5" id="academic_header_banner">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5 font-display" id="academic_title">
            <GraduationCap className="w-7 h-7 text-cyan-400 text-glow-cyan" />
            <span>Academic Studio & Grade Track</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1 pb-1 flex items-center gap-1.5 font-sans" id="academic_sub_desc">
            <CheckCircle2 className="w-3.5 h-3.5 text-cyan-500" />
            Designed in chronological "1-1, 1-2" term format. Organize theory materials (Notes & Books) v.s. labs (Reports & Manuals) with full online editing tools.
          </p>
        </div>

        {/* Realtime CGPA Counter Panel */}
        <div className="flex flex-wrap items-center gap-2.5 bg-[#020408]/65 p-3 rounded-2xl border border-white/10 shadow-lg" id="academic_metrics_summary">
          <div className="px-3 border-r border-white/5 text-center">
            <span className="block text-[8px] text-slate-500 font-mono font-bold uppercase tracking-wider">TERM {activeSemester?.name || "N/A"} GPA</span>
            <span className="text-sm font-bold text-cyan-400 font-mono">
              {activeSemester ? calculateSemesterGpa(activeSemester).toFixed(2) : "0.00"}
            </span>
          </div>
          <div className="px-3 border-r border-white/5 text-center">
            <span className="block text-[8px] text-slate-500 font-mono font-bold uppercase tracking-wider">TOTAL CGPA (GRADE-POINT)</span>
            <span className="text-sm font-bold text-white font-mono text-glow-white">
              {currentOverallCgpa.toFixed(2)}
            </span>
          </div>
          <div className="px-3 text-center">
            <span className="block text-[8px] text-slate-500 font-mono font-bold uppercase tracking-wider">ENROLLED Hrs</span>
            <span className="text-sm font-bold text-emerald-400 font-mono">
              {activeSemester?.courses.reduce((sum, c) => sum + c.credits, 0) || 0} Credits
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start" id="academic_grid_layout">
        
        {/* Left Column (col-span-4): Semester selector tabs with rename & adds */}
        <div className="lg:col-span-4 space-y-4" id="academic_left_column">
          
          <div className="p-4.5 rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl space-y-4" id="academic_semesters_panel">
            <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
              <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-cyan-400" />
                <span>Academic Semesters (1-1 to 4-2)</span>
              </span>
              
              <button
                id="add_semester_trigger"
                onClick={() => setShowAddSem(!showAddSem)}
                className="cursor-pointer text-[10px] items-center text-cyan-400 hover:text-white flex gap-1 font-mono hover:bg-cyan-500/10 px-2.5 py-1 rounded-lg border border-cyan-500/20 transition-all font-semibold"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Term</span>
              </button>
            </div>

            {/* Semester addition mini-sheet */}
            {showAddSem && (
              <form onSubmit={handleAddSemester} className="bg-[#020408]/90 p-3.5 rounded-xl border border-white/10 space-y-3 animate-fadeIn" id="add_semester_form">
                <div className="space-y-1">
                  <label className="text-[9px] font-mono text-slate-400 font-bold uppercase block">Term Blueprint Selection</label>
                  <select
                    value={newSemNameInput}
                    onChange={(e) => setNewSemNameInput(e.target.value)}
                    className="w-full bg-[#020408] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer font-mono"
                  >
                    <option value="1-1">1-1 (Year 1 Semester 1)</option>
                    <option value="1-2">1-2 (Year 1 Semester 2)</option>
                    <option value="2-1">2-1 (Year 2 Semester 1)</option>
                    <option value="2-2">2-2 (Year 2 Semester 2)</option>
                    <option value="3-1">3-1 (Year 3 Semester 1)</option>
                    <option value="3-2">3-2 (Year 3 Semester 2)</option>
                    <option value="4-1">4-1 (Year 4 Semester 1)</option>
                    <option value="4-2">4-2 (Year 4 Semester 2)</option>
                  </select>
                </div>
                <div className="flex gap-2 text-xs">
                  <button
                    type="submit"
                    className="cursor-pointer font-mono font-bold uppercase bg-cyan-600 hover:bg-cyan-500 px-3 py-1.5 text-white rounded-lg flex-1 transition-all"
                  >
                    Compile Term
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAddSem(false)}
                    className="cursor-pointer font-mono font-bold bg-white/5 hover:bg-white/10 px-3 py-1.5 text-slate-300 rounded-lg transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}

            {/* Lists semesters */}
            <div className="space-y-2" id="semester_cards_list">
              {semesters.map((sem) => {
                const isActive = sem.id === activeSemId;
                const semGpa = calculateSemesterGpa(sem);
                const isRenaming = editingSemId === sem.id;
                const totalCreds = sem.courses.reduce((acc, cr) => acc + cr.credits, 0);

                return (
                  <div
                    key={sem.id}
                    className={`p-3 rounded-2xl border transition-all relative group flex flex-col justify-between ${
                      isActive 
                        ? "bg-gradient-to-r from-cyan-950/20 to-blue-950/10 border-cyan-500/30 shadow-[0_0_12px_rgba(6,182,212,0.05)]" 
                        : "bg-white/4 border-white/5 hover:border-white/10 hover:bg-white/6"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      {isRenaming ? (
                        <div className="flex items-center gap-1.5 w-full mt-1">
                          <input
                            type="text"
                            value={editingSemName}
                            onChange={(e) => setEditingSemName(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") handleSaveRenameSem();
                              if (e.key === "Escape") setEditingSemId(null);
                            }}
                            className="bg-[#020408] border border-cyan-500/40 rounded-md px-2 py-1 text-xs text-white placeholder-slate-700 font-mono w-full focus:outline-none"
                            autoFocus
                          />
                          <button
                            onClick={handleSaveRenameSem}
                            className="p-1 rounded bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 cursor-pointer"
                            title="Save"
                          >
                            <Save className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingSemId(null)}
                            className="p-1 rounded bg-white/5 text-slate-450 hover:bg-white/10 cursor-pointer"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            if (activeSemId === sem.id) return;
                            setIsChangingSemester(true);
                            setTimeout(() => {
                              setActiveSemId(sem.id);
                              if (sem.courses.length > 0) {
                                setExpandedCourseId(sem.courses[0].id);
                              } else {
                                setExpandedCourseId(null);
                              }
                              setIsChangingSemester(false);
                            }, 500);
                          }}
                          disabled={isChangingSemester}
                          className={`flex-1 text-left ${isChangingSemester ? "cursor-not-allowed opacity-60" : "cursor-pointer"}`}
                        >
                          <span className={`block text-sm font-semibold font-mono tracking-wide ${isActive ? "text-cyan-400" : "text-slate-200"}`}>
                            Semester {sem.name}
                          </span>
                          <span className="block text-[10px] text-slate-500 font-mono mt-1 font-medium">
                            Term GPA: <strong className={semGpa >= 3.5 ? "text-emerald-450" : "text-slate-350"}>{semGpa.toFixed(2)}</strong> &bull; {totalCreds} credits &bull; {sem.courses.length} courses
                          </span>
                        </button>
                      )}

                      {!isRenaming && (
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                          <button
                            onClick={() => handleStartRenameSem(sem)}
                            className="p-1 text-slate-400 hover:text-cyan-400 rounded cursor-pointer transition-colors hover:bg-white/5"
                            title="Rename Term"
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                          <button
                            onClick={() => handleRemoveSemester(sem.id)}
                            className="p-1 text-slate-500 hover:text-rose-400 rounded cursor-pointer transition-colors hover:bg-white/5"
                            title="Delete Term"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

          </div>

          {/* Guidelines Box */}
          <div className="p-4 rounded-3xl border border-white/5 bg-gradient-to-b from-white/4 to-[#020408]/30 space-y-3" id="academic_guidelines_box">
            <h3 className="text-xs font-mono font-bold text-slate-350 uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
              <span>FutureOS Archival Guide</span>
            </h3>
            <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
              To update your grades or syllabus details, click the <Pencil className="w-2.5 h-2.5 inline-block text-cyan-400" /> pencil icon next to semesters, courses, or assessments. Live calculation is triggered instantly to ensure clean visual CGPA syncing back to your profile.
            </p>
            <div className="text-[10px] bg-cyan-950/10 border border-cyan-500/15 text-cyan-400/80 p-2 rounded-xl italic">
              Courses are segmented parallelly into Theory (Notes & Books) or Labs (Reports & Manuals) structure.
            </div>
          </div>

        </div>

        {/* Right Column (col-span-8): Active term syllabus boards divided in 2 categories */}
        <div className="lg:col-span-8 space-y-5" id="academic_right_column">
          
          <div className="rounded-3xl border border-white/10 bg-white/4 backdrop-blur-2xl p-5 space-y-5" id="active_syllabus_dashboard">
            
            {/* Enrollment and Selector Row */}
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-cyan-950/20 text-cyan-400 px-2.5 py-1 rounded-lg border border-cyan-500/20">
                  Semester {activeSemester?.name || "NONE"} Active
                </span>
                <span className="h-4 w-[1px] bg-white/5" />
                <h2 className="text-sm font-bold text-white tracking-tight">Theory & Laboratory Segregations</h2>
              </div>

              <button
                id="enroll_course_trigger"
                onClick={() => setShowAddCourse(!showAddCourse)}
                className="cursor-pointer inline-flex items-center space-x-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white text-[10px] font-mono font-bold px-3 py-1.5 rounded-xl transition-all shadow-md border border-transparent hover:shadow-cyan-500/20"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Enroll Course</span>
              </button>
            </div>

            {/* Course Enrollment Sheet */}
            {showAddCourse && (
              <form onSubmit={handleAddCourse} className="bg-[#020408]/90 border border-white/10 p-4 rounded-2xl gap-3 grid grid-cols-1 md:grid-cols-12 items-end animate-fadeIn" id="course_enrollment_form">
                <div className="md:col-span-4 space-y-1">
                  <label className="text-[9px] font-mono text-slate-450 font-bold uppercase">Course Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Artificial Intelligence"
                    value={courseNameInput}
                    onChange={(e) => setCourseNameInput(e.target.value)}
                    className="w-full bg-[#020408] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none placeholder-slate-700 font-sans"
                  />
                </div>

                <div className="md:col-span-2 space-y-1">
                  <label className="text-[9px] font-mono text-slate-450 font-bold uppercase">Code</label>
                  <input
                    type="text"
                    placeholder="e.g. CSE-3103"
                    value={courseCodeInput}
                    onChange={(e) => setCourseCodeInput(e.target.value)}
                    className="w-full bg-[#020408] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none placeholder-slate-700 uppercase font-mono"
                  />
                </div>

                <div className="md:col-span-2 space-y-1">
                  <label className="text-[9px] font-mono text-slate-450 font-bold uppercase">Course Type</label>
                  <select
                    value={courseTypeInput}
                    onChange={(e) => setCourseTypeInput(e.target.value as any)}
                    className="w-full bg-[#020408] border border-white/10 rounded-lg px-2 py-1.5 text-xs text-slate-300 focus:outline-none cursor-pointer font-mono"
                  >
                    <option value="theory">Theory</option>
                    <option value="lab">Laboratory</option>
                  </select>
                </div>

                <div className="md:col-span-2 space-y-1">
                  <label className="text-[9px] font-mono text-slate-450 font-bold uppercase">Credit Hours</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0.5"
                    max="6.0"
                    required
                    value={courseCreditsInput}
                    onChange={(e) => setCourseCreditsInput(Number(e.target.value))}
                    className="w-full bg-[#020408] border border-white/10 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none font-mono"
                  />
                </div>

                <div className="md:col-span-2 flex gap-1.5 text-xs">
                  <button
                    type="submit"
                    className="cursor-pointer bg-cyan-600 hover:bg-cyan-500 font-mono py-1.5 rounded-lg text-white font-bold text-center flex-1 transition-all"
                  >
                    Enroll
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAddCourse(false)}
                    className="cursor-pointer bg-white/5 hover:bg-white/10 font-mono py-1.5 rounded-lg text-slate-350 px-2 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}

            <AnimatePresence mode="wait">
              {isChangingSemester ? (
                <motion.div
                  key="loading-semester-shimmer"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-4"
                >
                  <div className="flex items-center gap-2 p-3 bg-cyan-950/15 border border-cyan-500/20 rounded-2xl animate-pulse text-[11px] font-mono text-cyan-400">
                    <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
                    <span>SYNCHRONIZING SYLLABUS INDEX & GPA MODELS...</span>
                  </div>
                  
                  {/* Beautiful skeletons with shimmer sweep effect */}
                  <div className="space-y-3">
                    {[1, 2].map((id) => (
                      <div key={id} className="p-4 rounded-3xl border border-white/5 bg-[#020408]/40 space-y-3 relative overflow-hidden">
                        <div className="absolute inset-x-0 top-0 bottom-0 overflow-hidden">
                          <motion.div 
                            className="w-full h-full bg-gradient-to-r from-transparent via-cyan-400/5 to-transparent"
                            initial={{ x: "-100%" }}
                            animate={{ x: "100%" }}
                            transition={{ repeat: Infinity, duration: 1.6, ease: "linear" }}
                          />
                        </div>
                        <div className="flex items-center justify-between relative z-10">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-xl bg-white/5 animate-pulse" />
                            <div className="space-y-1.5">
                              <div className="w-36 h-3 bg-white/10 rounded-md animate-pulse" />
                              <div className="w-20 h-2 bg-white/5 rounded-md animate-pulse" />
                            </div>
                          </div>
                          <div className="w-12 h-3.5 bg-white/5 rounded-md animate-pulse" />
                        </div>
                        <div className="h-1 bg-white/5 rounded-full overflow-hidden relative z-10">
                          <div className="h-full w-1/4 bg-cyan-500/20 rounded-full animate-pulse" />
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key={activeSemId}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.35, ease: "easeOut" }}
                  className="space-y-4"
                >
                  {/* Check empty states */}
                  {(!activeSemester || activeSemester.courses.length === 0) && (
                    <div className="p-12 text-center rounded-2xl border border-dashed border-white/5 bg-[#020408]/30" id="empty_term_alert">
                      <AlertCircle className="w-8 h-8 text-slate-650 mx-auto mb-2" />
                      <span className="text-xs text-slate-450 font-mono block font-bold">NO COURSES ENROLLED IN {activeSemester?.name || "THIS TERM"}</span>
                      <span className="text-[10px] text-slate-500 block mt-1">Enroll custom theory and lab syllabus modules using the enroll trigger.</span>
                    </div>
                  )}

                  {/* SECTION 1: THEORY SYLLABUS SECTION */}
                  {activeSemester && theoryCourses.length > 0 && (
                    <div className="space-y-3" id="theory_syllabus_block">
                      <div className="flex items-center space-x-2 text-[10px] font-mono font-bold text-slate-500 tracking-wider">
                        <BookOpen className="w-4 h-4 text-cyan-400 shrink-0" />
                        <span>THEORY COURSES SYLLABUS ({theoryCourses.length} ACTIVE)</span>
                      </div>

                      <div className="space-y-3">
                        {theoryCourses.map((course) => renderCollapsibleCourseNode(course))}
                      </div>
                    </div>
                  )}

                  {/* SECTION 2: LABORATORY SYLLABUS SECTION */}
                  {activeSemester && labCourses.length > 0 && (
                    <div className="space-y-3 pt-4 border-t border-white/5" id="lab_syllabus_block">
                      <div className="flex items-center space-x-2 text-[10px] font-mono font-bold text-slate-500 tracking-wider">
                        <Activity className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>LABORATORY & PRACTICUM SYLLABUS ({labCourses.length} ACTIVE)</span>
                      </div>

                      <div className="space-y-3">
                        {labCourses.map((course) => renderCollapsibleCourseNode(course))}
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

          </div>

        </div>

      </div>

    </div>
  );

  // COLLAPSIBLE COURSE CARD INTERFACE RENDERER
  function renderCollapsibleCourseNode(course: Course) {
    const isExpanded = expandedCourseId === course.id;
    const stats = getCourseProgressDetails(course);
    const isEditing = editingCourseId === course.id;

    const accentColor = course.type === "theory" ? "cyan" : "emerald";
    const headerBorderClass = isExpanded 
      ? `border-${accentColor}-500/25 bg-white/4` 
      : "border-white/5 bg-white/2 hover:border-white/10 hover:bg-white/4";

    return (
      <div 
        key={course.id} 
        className={`rounded-2xl border transition-all overflow-hidden ${headerBorderClass}`}
        id={`course_card_${course.id}`}
      >
        {/* Course Card Top Header and quick summary metrics */}
        <div className="p-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 text-sm select-none">
          
          {isEditing ? (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-2 w-full p-1 bg-[#020408]/80 rounded-xl border border-white/5">
              <div className="md:col-span-4 space-y-0.5">
                <label className="text-[8px] font-mono text-slate-500 uppercase block pl-1">Course Title</label>
                <input
                  type="text"
                  value={editingCourseName}
                  onChange={(e) => setEditingCourseName(e.target.value)}
                  className="bg-[#020408] border border-white/15 rounded px-2 py-1 text-xs text-white placeholder-slate-700 w-full focus:outline-none"
                />
              </div>
              <div className="md:col-span-2 space-y-0.5">
                <label className="text-[8px] font-mono text-slate-500 uppercase block pl-1">Code</label>
                <input
                  type="text"
                  value={editingCourseCode}
                  onChange={(e) => setEditingCourseCode(e.target.value)}
                  className="bg-[#020408] border border-white/15 rounded px-2 py-1 text-xs text-white placeholder-slate-700 font-mono w-full focus:outline-none"
                />
              </div>
              <div className="md:col-span-2 space-y-0.5">
                <label className="text-[8px] font-mono text-slate-500 uppercase block pl-1">Credits</label>
                <input
                  type="number"
                  step="0.5"
                  value={editingCourseCredits}
                  onChange={(e) => setEditingCourseCredits(Number(e.target.value))}
                  className="bg-[#020408] border border-white/15 rounded px-2 py-1 text-xs text-white placeholder-slate-700 font-mono w-full focus:outline-none"
                />
              </div>
              <div className="md:col-span-2 space-y-0.5">
                <label className="text-[8px] font-mono text-slate-500 uppercase block pl-1">Type</label>
                <select
                  value={editingCourseType}
                  onChange={(e) => setEditingCourseType(e.target.value as any)}
                  className="bg-[#020408] border border-white/15 rounded px-2 py-1 text-xs text-slate-300 w-full focus:outline-none font-mono cursor-pointer"
                >
                  <option value="theory">Theory</option>
                  <option value="lab">Lab</option>
                </select>
              </div>
              <div className="md:col-span-2 flex items-end gap-1 pb-0.5">
                <button
                  type="button"
                  onClick={handleSaveEditCourse}
                  className="bg-cyan-600 hover:bg-cyan-500 text-white rounded text-[10px] font-bold p-2 flex-1 text-center cursor-pointer font-mono"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={() => setEditingCourseId(null)}
                  className="bg-white/5 hover:bg-white/10 text-slate-300 rounded text-[10px] font-bold p-2 cursor-pointer font-mono"
                >
                  X
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setExpandedCourseId(isExpanded ? null : course.id)}
              className="cursor-pointer flex-1 flex items-start space-x-3 text-left"
            >
              <div className={`mt-1.5 w-2.5 h-2.5 rounded-full ${
                course.type === "theory" ? "bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.6)]" : "bg-emerald-450 bg-emerald-450 bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.25)]"
              }`} />
              
              <div className="overflow-hidden">
                <div className="flex items-center space-x-1.5">
                  <span className="text-xs font-bold text-white tracking-wide truncate">{course.name}</span>
                  <span className="text-[9px] text-slate-500 font-mono font-bold uppercase tracking-wider">[{course.code}]</span>
                </div>
                <span className="block text-[10px] text-slate-500 font-mono mt-1 font-semibold uppercase">
                  {course.type} Syllabus &bull; <strong className="text-slate-450">{course.credits} Credits</strong> &bull; {course.assessments.length} Marks parameters &bull; {course.files.length} Document items
                </span>
              </div>
            </button>
          )}

          {/* Quick Stats of the Course */}
          {!isEditing && (
            <div className="flex items-center gap-4.5 justify-between md:justify-end shrink-0">
              <div className="text-right">
                <span className="block text-[8px] text-slate-550 font-mono font-bold uppercase">GRADE ESTIMATE</span>
                <span className={`text-[11px] font-bold font-mono tracking-wider ${
                  stats.calculatedGrade === "F" ? "text-rose-400" : "text-cyan-400 text-glow-cyan"
                }`}>
                  {stats.calculatedGrade} ({stats.projectedPercentage}%)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setExpandedCourseId(isExpanded ? null : course.id)}
                  className="cursor-pointer p-1.5 rounded-xl border border-white/5 bg-[#020408]/30 hover:bg-[#020408]/60 text-slate-400 hover:text-white transition-colors"
                >
                  {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => handleStartEditCourse(course)}
                  className="cursor-pointer p-1.5 rounded-xl border border-white/5 bg-[#020408]/30 hover:bg-cyan-950/20 text-slate-400 hover:text-cyan-400 transition-colors"
                  title="Edit Course Credentials"
                >
                  <Pencil className="w-4 h-4" />
                </button>

                <button
                  onClick={() => handleRemoveCourse(course.id)}
                  className="cursor-pointer p-1.5 rounded-xl border border-white/5 bg-[#020408]/30 hover:bg-rose-950/20 text-slate-500 hover:text-rose-400 transition-colors"
                  title="Archive Course"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Collapsible Expanded panel (Weighted grades & divided files buckets) */}
        <AnimatePresence initial={false}>
          {isExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: "easeInOut" }}
              className="overflow-hidden border-t border-white/5 bg-[#020408]/40"
            >
              <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* LEFT AREA (lg:col-span-5): Assessments Grade parameters */}
            <div className="lg:col-span-5 space-y-4 border-r border-white/5 pr-0 lg:pr-5">
              <div className="flex items-center justify-between border-b border-white/5 pb-2">
                <span className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-widest flex items-center gap-1">
                  <Percent className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Weighted Grades Tracker</span>
                </span>
                
                <span className="text-[9px] text-slate-500 font-mono font-bold">
                  Sum: <strong className={stats.totalWeightInterpreted === 100 ? "text-emerald-400" : "text-amber-400 font-extrabold"}>{stats.totalWeightInterpreted}% / 100%</strong>
                </span>
              </div>

              {/* Assessment card listings */}
              {course.assessments.length === 0 ? (
                <div className="p-5 text-center bg-[#020408]/40 rounded-xl border border-white/5">
                  <Info className="w-4 h-4 text-slate-650 mx-auto mb-1.5" />
                  <span className="text-[10px] text-slate-500 font-mono font-medium block">NO WEIGHTED EVALUATIONS</span>
                  <span className="text-[8px] text-slate-600 block mt-0.5">Use the quick add module below to populate parameters.</span>
                </div>
              ) : (
                <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1 scrollbar-thin">
                  {course.assessments.map(a => {
                    const pct = Math.round((a.score / a.total) * 100);
                    const isEditingAssess = editingAssessId === a.id && editingAssessCourseId === course.id;

                    return (
                      <div key={a.id} className="p-2 bg-[#020408]/85 border border-white/5 rounded-xl flex flex-col gap-1.5 text-xs">
                        {isEditingAssess ? (
                          <div className="space-y-2 p-1 font-mono">
                            <input
                              type="text"
                              value={editingAssessName}
                              onChange={(e) => setEditingAssessName(e.target.value)}
                              className="bg-[#020408] border border-cyan-500/30 text-white rounded px-2 py-1 text-xs w-full focus:outline-none"
                              placeholder="Assessment Title"
                            />
                            <div className="grid grid-cols-3 gap-1.5 text-center">
                              <div>
                                <label className="text-[8px] text-slate-500">Weight%</label>
                                <input
                                  type="number"
                                  value={editingAssessWeight}
                                  onChange={(e) => setEditingAssessWeight(Number(e.target.value))}
                                  className="bg-[#020408] border border-white/10 text-white rounded px-1.5 py-0.5 text-xs text-center w-full focus:outline-none"
                                />
                              </div>
                              <div>
                                <label className="text-[8px] text-slate-500">Score</label>
                                <input
                                  type="number"
                                  step="0.5"
                                  value={editingAssessScore}
                                  onChange={(e) => setEditingAssessScore(Number(e.target.value))}
                                  className="bg-[#020408] border border-white/10 text-white rounded px-1.5 py-0.5 text-xs text-center w-full focus:outline-none"
                                />
                              </div>
                              <div>
                                <label className="text-[8px] text-slate-500">Total Poss.</label>
                                <input
                                  type="number"
                                  value={editingAssessTotal}
                                  onChange={(e) => setEditingAssessTotal(Number(e.target.value))}
                                  className="bg-[#020408] border border-white/10 text-white rounded px-1.5 py-0.5 text-xs text-center w-full focus:outline-none"
                                />
                              </div>
                            </div>
                            <div className="flex gap-1">
                              <button
                                onClick={handleSaveEditAssess}
                                className="bg-cyan-600 hover:bg-cyan-500 text-white rounded text-[9px] font-bold uppercase tracking-wider py-1 px-2.5 flex-1 cursor-pointer"
                              >
                                Save
                              </button>
                              <button
                                onClick={() => {
                                  setEditingAssessId(null);
                                  setEditingAssessCourseId(null);
                                }}
                                className="bg-white/5 hover:bg-white/10 text-slate-350 rounded text-[9px] py-1 px-1.5 cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex-1 truncate">
                              <span className="block font-semibold text-slate-200 truncate">{a.name}</span>
                              <span className="block text-[9px] text-slate-500 font-mono mt-0.5 font-bold uppercase">
                                Weight: {a.weight}% &bull; Score: <strong className="text-slate-300">{a.score} / {a.total}</strong> ({pct}%)
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              <div className="w-14 bg-slate-900 rounded-full h-1 border border-white/5 overflow-hidden">
                                <div 
                                  className={`h-full rounded-full ${pct >= 80 ? "bg-cyan-400" : pct >= 65 ? "bg-blue-400" : pct >= 40 ? "bg-amber-400" : "bg-red-400"}`}
                                  style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
                                />
                              </div>

                              <button
                                onClick={() => handleStartEditAssess(course.id, a)}
                                className="p-0.5 text-slate-500 hover:text-cyan-400 transition-colors cursor-pointer"
                                title="Edit Assessment Score"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => handleRemoveAssessment(course.id, a.id)}
                                className="p-0.5 text-slate-500 hover:text-rose-450 transition-colors cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Quickly Enrolling Custom parameters Form */}
              <div className="bg-[#020408]/60 p-2.5 rounded-2xl border border-white/5 space-y-2 text-xs font-mono">
                <span className="block text-[8px] text-slate-500 font-extrabold uppercase pl-1">Enroll New Mark Component</span>
                
                <div className="grid grid-cols-12 gap-1.5">
                  <input
                    type="text"
                    placeholder="Quiz 1 / Midterm..."
                    value={assessNameInput}
                    onChange={(e) => setAssessNameInput(e.target.value)}
                    className="col-span-12 md:col-span-5 bg-[#020408] border border-white/10 rounded-lg px-2.5 py-1 text-[11px] text-white placeholder-slate-700 focus:outline-none focus:border-cyan-500 font-sans"
                  />
                  <input
                    type="number"
                    placeholder="W%"
                    min="1"
                    max="100"
                    value={assessWeightInput || ""}
                    onChange={(e) => setAssessWeightInput(Number(e.target.value))}
                    className="col-span-4 md:col-span-2 bg-[#020408] border border-white/10 rounded-lg px-1.5 py-1 text-[11px] text-white text-center focus:outline-none"
                    title="Weight percentage"
                  />
                  <input
                    type="number"
                    placeholder="Score"
                    step="0.5"
                    value={assessScoreInput || ""}
                    onChange={(e) => setAssessScoreInput(Number(e.target.value))}
                    className="col-span-4 md:col-span-2 bg-[#020408] border border-white/10 rounded-lg px-1.5 py-1 text-[11px] text-white text-center focus:outline-none"
                    title="Score obtained"
                  />
                  <input
                    type="number"
                    placeholder="Total"
                    value={assessTotalInput || ""}
                    onChange={(e) => setAssessTotalInput(Number(e.target.value))}
                    className="col-span-4 md:col-span-1 bg-[#020408] border border-white/10 rounded-lg px-1 py-1 text-[11px] text-white text-center focus:outline-none"
                    title="Total marks possible"
                  />
                  
                  <button
                    type="button"
                    onClick={() => handleAddAssessment(course.id)}
                    className="cursor-pointer col-span-12 md:col-span-2 bg-gradient-to-r from-cyan-950 to-blue-950 hover:from-cyan-900 border border-cyan-500/20 text-[10px] font-bold uppercase transition-all py-1.5 rounded-lg text-center text-cyan-400"
                  >
                    + Add
                  </button>
                </div>
              </div>

            </div>

            {/* RIGHT AREA (lg:col-span-7): Uploading files separated in 2 target categories */}
            <div className="lg:col-span-7 space-y-4">
              
              {course.type === "theory" ? (
                // THEORY COURSE FILES INTERFACE (Lecture Notes / Reference Books)
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* CATEGORY A: LECTURE NOTES */}
                  <div className="space-y-2.5">
                    <span className="text-[10px] font-mono font-bold text-slate-350 uppercase tracking-wider flex items-center gap-1 border-b border-white/5 pb-1 block">
                      <FileText className="w-3.5 h-3.5 text-cyan-400" />
                      <span>1. Lecture Notes / Slides</span>
                    </span>

                    <UploadDropZone
                      courseId={course.id}
                      category="notes"
                      placeholderText="notes"
                      isDragging={isDragging}
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onManualFileChange={handleManualFileChange}
                    />

                    <div className="space-y-1 my-2">
                      {renderFileList(course.id, "notes")}
                    </div>
                  </div>

                  {/* CATEGORY B: REFERENCE BOOKS */}
                  <div className="space-y-2.5">
                    <span className="text-[10px] font-mono font-bold text-slate-350 uppercase tracking-wider flex items-center gap-1 border-b border-white/5 pb-1 block">
                      <Book className="w-3.5 h-3.5 text-purple-400" />
                      <span>2. Textbooks & Books</span>
                    </span>

                    <UploadDropZone
                      courseId={course.id}
                      category="book"
                      placeholderText="book"
                      isDragging={isDragging}
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onManualFileChange={handleManualFileChange}
                    />

                    <div className="space-y-1 my-2">
                      {renderFileList(course.id, "book")}
                    </div>
                  </div>

                </div>
              ) : (
                // LAB COURSE FILES INTERFACE (Lab Reports / Lab Manuals)
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* CATEGORY A: LAB REPORTS */}
                  <div className="space-y-2.5">
                    <span className="text-[10px] font-mono font-bold text-slate-350 uppercase tracking-wider flex items-center gap-1 border-b border-white/5 pb-1 block">
                      <ClipboardList className="w-3.5 h-3.5 text-emerald-400" />
                      <span>1. Lab Reports & Code</span>
                    </span>

                    <UploadDropZone
                      courseId={course.id}
                      category="report"
                      placeholderText="lab report"
                      isDragging={isDragging}
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onManualFileChange={handleManualFileChange}
                    />

                    <div className="space-y-1 my-2">
                      {renderFileList(course.id, "report")}
                    </div>
                  </div>

                  {/* CATEGORY B: LAB MANUALS */}
                  <div className="space-y-2.5">
                    <span className="text-[10px] font-mono font-bold text-slate-350 uppercase tracking-wider flex items-center gap-1 border-b border-white/5 pb-1 block">
                      <File className="w-3.5 h-3.5 text-teal-400" />
                      <span>2. Lab Manuals & Sheets</span>
                    </span>

                    <UploadDropZone
                      courseId={course.id}
                      category="manual"
                      placeholderText="lab manual"
                      isDragging={isDragging}
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onManualFileChange={handleManualFileChange}
                    />

                    <div className="space-y-1 my-2">
                      {renderFileList(course.id, "manual")}
                    </div>
                  </div>

                </div>
              )}

            </div>

          </div>

          </motion.div>
        )}
      </AnimatePresence>

      </div>
    );
  }

  // GENERAL REUSABLE FILE LIST COMPONENT WITH LIVE WEBSITE RENAMING
  function renderFileList(courseId: string, category: "notes" | "book" | "report" | "manual") {
    const activeCourse = semesters
      .flatMap(s => s.courses)
      .find(c => c.id === courseId);

    if (!activeCourse) return null;
    const categoryFiles = activeCourse.files.filter(f => f.category === category);
    const activeUploading = uploadingFiles.filter(uf => uf.courseId === courseId && uf.category === category);

    if (categoryFiles.length === 0 && activeUploading.length === 0) {
      return (
        <span className="block text-[9px] text-slate-600 font-mono italic p-2 bg-[#020408]/30 rounded-xl border border-white/5 text-center">
          No items uploaded
        </span>
      );
    }

    return (
      <div className="space-y-1 max-h-48 overflow-y-auto pr-1 scrollbar-thin">
        {/* Render uploading states first with animations */}
        {activeUploading.map(uf => (
          <div key={uf.id} className="p-2 bg-cyan-950/20 border border-cyan-500/20 rounded-xl space-y-1 text-[10px] font-mono relative overflow-hidden animate-pulse">
            <div 
              className="absolute left-0 top-0 bottom-0 bg-cyan-500/5 transition-all duration-150"
              style={{ width: `${uf.progress}%` }}
            />
            <div className="flex items-center justify-between relative z-10">
              <div className="flex items-center space-x-1.5 truncate">
                <Loader2 className="w-3 h-3 text-cyan-400 animate-spin shrink-0" />
                <span className="text-slate-300 font-sans text-[11px] truncate" title={uf.name}>{uf.name}</span>
              </div>
              <span className="text-cyan-400 font-semibold shrink-0 ml-1.5 font-mono">{uf.progress}%</span>
            </div>
            
            <div className="h-1 bg-white/5 rounded-full overflow-hidden relative z-10">
              <div 
                className="h-full bg-cyan-500 rounded-full transition-all duration-150"
                style={{ width: `${uf.progress}%` }}
              />
            </div>
          </div>
        ))}

        {categoryFiles.map(f => {
          const isRenamingFile = editingFileId === f.id && editingFileCourseId === courseId;

          return (
            <div key={f.id} className="p-1.5 bg-[#020408]/85 border border-white/5 rounded-xl flex items-center justify-between text-[11px] font-mono">
              
              {isRenamingFile ? (
                <div className="flex items-center gap-1 w-full pl-0.5 pr-0.5">
                  <input
                    type="text"
                    value={editingFileName}
                    onChange={(e) => setEditingFileName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleSaveRenameFile();
                      if (e.key === "Escape") setEditingFileId(null);
                    }}
                    className="bg-[#020408] border border-cyan-500/40 rounded-md px-1 py-0.5 text-xs text-white placeholder-slate-700 w-full focus:outline-none"
                    autoFocus
                  />
                  <button
                    onClick={handleSaveRenameFile}
                    className="p-1 rounded bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20 cursor-pointer"
                  >
                    <Save className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => {
                      setEditingFileId(null);
                      setEditingFileCourseId(null);
                    }}
                    className="p-1 rounded bg-white/5 text-slate-350 cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex items-center space-x-1.5 truncate">
                    <FileText className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <div className="truncate">
                      <span className="text-slate-300 block truncate font-sans text-xs" title={f.name}>{f.name}</span>
                      <span className="text-[8px] text-slate-500 block font-normal">{f.size} &bull; {f.uploadedAt}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-1.5 shrink-0 ml-2">
                    <button
                      onClick={() => handleStartRenameFile(courseId, f)}
                      className="p-0.5 text-slate-450 hover:text-cyan-400 cursor-pointer transition-colors"
                      title="Rename document file"
                    >
                      <Pencil className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => handleMockDownloadFile(f)}
                      className="p-0.5 text-slate-450 hover:text-cyan-400 cursor-pointer transition-colors"
                      title="Download Notes File"
                    >
                      <Download className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => handleRemoveFile(courseId, f.id)}
                      className="p-0.5 text-slate-450 hover:text-rose-400 cursor-pointer transition-colors"
                      title="Delete notes file"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>
    );
  }
}
