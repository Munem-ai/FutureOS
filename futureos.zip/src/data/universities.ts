/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { University } from "../types";

export const initialUniversities: University[] = [
  {
    id: "mit",
    name: "Massachusetts Institute of Technology (MIT)",
    ranking: 1,
    country: "USA",
    degreePrograms: ["MS in EECS", "PhD in EECS", "MS in Mechanical Engineering", "PhD in Physics"],
    gpaRequirement: 3.8,
    ieltsRequirement: 7.5,
    greRequirement: 325,
    researchAreas: ["Quantum Computing", "Deep Learning", "Embedded Systems", "Robotics", "Bioinformatics"],
    fundingOptions: "Fully funded research/teaching assistantships (RA/TA) for most PhD and some MS candidates.",
    facultyProfiles: ["Prof. Anantha Chandrakasan (EECS)", "Prof. Dina Katabi (AI/IoT)", "Prof. Daniela Rus (Robotics)"]
  },
  {
    id: "stanford",
    name: "Stanford University",
    ranking: 2,
    country: "USA",
    degreePrograms: ["MS in Computer Science", "PhD in AI", "MS in Electrical Engineering", "MBA"],
    gpaRequirement: 3.8,
    ieltsRequirement: 7.5,
    greRequirement: 320,
    researchAreas: ["Generative AI", "Human-Computer Interaction", "Smart Grid Systems", "Biomedical Hardware"],
    fundingOptions: "Fellowships, Knight-Hennessy Scholars program, and RA/TA research positions.",
    facultyProfiles: ["Prof. Fei-Fei Li (Vision)", "Prof. Andrew Ng (Machine Learning)", "Prof. Subhasish Mitra (EE/Hardware)"]
  },
  {
    id: "eth-zurich",
    name: "ETH Zurich",
    ranking: 7,
    country: "Switzerland",
    degreePrograms: ["MSc in Computer Science", "MSc in Robotics Systems", "PhD in Electrical Engineering"],
    gpaRequirement: 3.6,
    ieltsRequirement: 7.0,
    greRequirement: 315,
    researchAreas: ["Embedded Hardware", "Edge Devices", "VLSI Design", "Autonomous Vehicles", "Energy Systems"],
    fundingOptions: "ETH Excellence Scholarship, direct assistantships during PhD programs with highly competitive salaries.",
    facultyProfiles: ["Prof. Luca Benini (Digital Microelectronics)", "Prof. Marco Hutter (Robotic Systems)"]
  },
  {
    id: "cambridge",
    name: "University of Cambridge",
    ranking: 3,
    country: "UK",
    degreePrograms: ["MPhil in Advanced Computer Science", "PhD in Engineering", "Masters in Public Policy"],
    gpaRequirement: 3.75,
    ieltsRequirement: 7.5,
    greRequirement: 320,
    researchAreas: ["System Hardware Architecture", "NLP", "Theoretical Computer Science", "Semiconductors"],
    fundingOptions: "Gates Cambridge Trust, Cambridge Commonwealth/European Trust scholarship pools.",
    facultyProfiles: ["Prof. Ted Briscoe (NLP)", "Prof. Robert Mullins (Computer Architecture)"]
  },
  {
    id: "oxford",
    name: "University of Oxford",
    ranking: 4,
    country: "UK",
    degreePrograms: ["MSc in Advanced Computer Science", "DPhil in Autonomous Systems", "MBA"],
    gpaRequirement: 3.75,
    ieltsRequirement: 7.5,
    greRequirement: 322,
    researchAreas: ["Machine Learning Theory", "Hardware Verification", "Cybersecurity", "Embedded Software"],
    fundingOptions: "Clarendon Fund, Oxford Graduate Scholarships, Departmental research grants.",
    facultyProfiles: ["Prof. Marta Kwiatkowska (Quantitative Software Verification)", "Prof. Michael Wooldridge (AI)"]
  },
  {
    id: "tum",
    name: "Technical University of Munich (TUM)",
    ranking: 28,
    country: "Germany",
    degreePrograms: ["MSc in Informatics", "MSc in Power Engineering", "PhD in Embedded Systems"],
    gpaRequirement: 3.3,
    ieltsRequirement: 6.5,
    greRequirement: 310,
    researchAreas: ["Automotive Control Systems", "Renewable Power Grids", "Edge AI", "Mechatronics"],
    fundingOptions: "DAAD EPOS Program, local German fellowships, low tuition fees with paid academic student jobs.",
    facultyProfiles: ["Prof. Alois Knoll (Robotics)", "Prof. Thomas Hamacher (Energy Systems)"]
  },
  {
    id: "nus",
    name: "National University of Singapore (NUS)",
    ranking: 8,
    country: "Singapore",
    degreePrograms: ["MComp in Computer Science", "PhD in Computer Science", "MS in Electrical Engineering"],
    gpaRequirement: 3.6,
    ieltsRequirement: 7.0,
    greRequirement: 320,
    researchAreas: ["Hardware Accelerators", "Machine Learning Security", "Smart Mobility", "Power Electronics"],
    fundingOptions: "Singapore International Graduate Award (SINGA), NUS Research Scholarships.",
    facultyProfiles: ["Prof. Mohan Kankanhalli (Information Systems)", "Prof. Tulika Mitra (Compiler/EECS)"]
  }
];
