/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Scholarship } from "../types";

export const initialScholarships: Scholarship[] = [
  {
    id: "fulbright",
    name: "Fulbright Foreign Student Program",
    country: "USA",
    degreeLevel: "Master's & PhD",
    funding: "Fully Funded (Tuition, Airfare, Living Stipend, Health Insurance)",
    minCgpa: 3.5,
    ieltsRequirement: 7.0,
    researchRequirement: false,
    publicationRequirement: false,
    sopRequired: true,
    recommendationLetters: 3,
    deadline: "2026-10-15",
    officialWebsite: "https://foreign.fulbrightonline.org/"
  },
  {
    id: "erasmus",
    name: "Erasmus Mundus Joint Masters Scholarship",
    country: "Europe (Multiple)",
    degreeLevel: "Master's",
    funding: "Fully Funded (Tuition fees, Travel allowance, Monthly allowance)",
    minCgpa: 3.2,
    ieltsRequirement: 6.5,
    researchRequirement: false,
    publicationRequirement: false,
    sopRequired: true,
    recommendationLetters: 2,
    deadline: "2027-01-30",
    officialWebsite: "https://ec.europa.eu/programmes/erasmus-plus/"
  },
  {
    id: "daad",
    name: "DAAD EPOS Scholarship Program",
    country: "Germany",
    degreeLevel: "Master's & PhD",
    funding: "Fully Funded (Monthly stipend, Travel subsidy, Health insurance)",
    minCgpa: 3.0,
    ieltsRequirement: 6.5,
    researchRequirement: true,
    publicationRequirement: false,
    sopRequired: true,
    recommendationLetters: 2,
    deadline: "2026-11-30",
    officialWebsite: "https://www.daad.de/en/"
  },
  {
    id: "mext",
    name: "MEXT Japanese Government Scholarship",
    country: "Japan",
    degreeLevel: "Undergraduate & Graduate",
    funding: "Fully Funded (Tuition, Airfare, Monthly allowance, Prep course)",
    minCgpa: 3.4,
    ieltsRequirement: 6.5,
    researchRequirement: true,
    publicationRequirement: false,
    sopRequired: true,
    recommendationLetters: 2,
    deadline: "2026-09-10",
    officialWebsite: "https://www.mext.go.jp/en/"
  },
  {
    id: "chevening",
    name: "Chevening Scholarship",
    country: "UK",
    degreeLevel: "Master's",
    funding: "Fully Funded (University tuition, Monthly stipend, Flights, Visas)",
    minCgpa: 3.3,
    ieltsRequirement: 7.0,
    researchRequirement: false,
    publicationRequirement: false,
    sopRequired: true,
    recommendationLetters: 2,
    deadline: "2026-11-05",
    officialWebsite: "https://www.chevening.org/"
  },
  {
    id: "gates-cambridge",
    name: "Gates Cambridge Scholarship",
    country: "UK",
    degreeLevel: "Master's & PhD",
    funding: "Fully Funded (University composition fee, Maintenance allowance, Airfare)",
    minCgpa: 3.8,
    ieltsRequirement: 7.5,
    researchRequirement: true,
    publicationRequirement: true,
    sopRequired: true,
    recommendationLetters: 3,
    deadline: "2026-12-05",
    officialWebsite: "https://www.gatescambridge.org/"
  },
  {
    id: "knight-hennessy",
    name: "Knight-Hennessy Scholars at Stanford",
    country: "USA",
    degreeLevel: "Master's & PhD",
    funding: "Fully Funded (Tuition, Living stipend, Academic expenses, Travel grant)",
    minCgpa: 3.8,
    ieltsRequirement: 7.5,
    researchRequirement: true,
    publicationRequirement: true,
    sopRequired: true,
    recommendationLetters: 3,
    deadline: "2026-10-12",
    officialWebsite: "https://knight-hennessy.stanford.edu/"
  },
  {
    id: "eth-excellence",
    name: "ETH Excellence Scholarship & Opportunity",
    country: "Switzerland",
    degreeLevel: "Master's",
    funding: "Partial to Full (Stipend for living/study costs, Tuition fee waiver)",
    minCgpa: 3.7,
    ieltsRequirement: 7.0,
    researchRequirement: true,
    publicationRequirement: false,
    sopRequired: true,
    recommendationLetters: 2,
    deadline: "2026-12-15",
    officialWebsite: "https://ethz.ch/students/en/studies/financial/scholarships/excellencescholarship.html"
  },
  {
    id: "swedish-institute",
    name: "Swedish Institute Scholarships for Global Professionals",
    country: "Sweden",
    degreeLevel: "Master's",
    funding: "Fully Funded (Tuition, Living costs, Travel grant, Insurance)",
    minCgpa: 3.2,
    ieltsRequirement: 6.5,
    researchRequirement: false,
    publicationRequirement: false,
    sopRequired: true,
    recommendationLetters: 2,
    deadline: "2027-02-15",
    officialWebsite: "https://si.se/en/"
  }
];
